import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import AIChatbot from "@/components/AIChatbot";
import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  ClipboardList,
  MessageSquare,
  Users,
  CheckCircle,
  Clock,
  AlertCircle,
  LogOut,
  Paintbrush2,
  Calendar,
  Phone,
  Mail,
  Send,
} from "lucide-react";

export default function EmployeeDashboard() {
  const { user, logout } = useAuth();
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (user.role !== "employee") {
    return <Navigate to="/login" replace />;
  }

  const myTasks = [
    {
      id: "1",
      title: "Tư vấn sơn cho khách hàng ABC",
      description: "Liên hệ và tư vấn loại sơn phù hợp cho dự án nhà máy ABC",
      status: "Đang thực hiện",
      priority: "Cao",
      deadline: "2024-01-15",
      assignedBy: "Tuấn Anh - Admin",
    },
    {
      id: "2",
      title: "Cập nhật th��ng tin khách hàng XYZ",
      description:
        "Cập nhật thông tin liên hệ và yêu cầu mới của khách hàng XYZ",
      status: "Chờ xử lý",
      priority: "Trung bình",
      deadline: "2024-01-20",
      assignedBy: "Tuấn Anh - Admin",
    },
    {
      id: "3",
      title: "Báo cáo tiến độ dự án DEF",
      description: "Soạn báo cáo tiến độ thực hiện dự án sơn cho công ty DEF",
      status: "Hoàn thành",
      priority: "Thấp",
      deadline: "2024-01-10",
      assignedBy: "Tuấn Anh - Admin",
    },
  ];

  const recentMessages = [
    {
      id: "1",
      from: "Trần Thị Lan",
      message: "Chào anh, em cần hỗ trợ về dự án ABC...",
      time: "10:30",
    },
    {
      id: "2",
      from: "Lê Văn Phong",
      message: "Khách hàng XYZ có yêu cầu thay đổi màu sơn",
      time: "09:15",
    },
    {
      id: "3",
      from: "Tuấn Anh - Admin",
      message: "Vui lòng cập nhật báo cáo tuần này",
      time: "08:45",
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Hoàn thành":
        return "default";
      case "Đang thực hiện":
        return "secondary";
      case "Chờ xử lý":
        return "outline";
      default:
        return "outline";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Cao":
        return "destructive";
      case "Trung bình":
        return "secondary";
      case "Thấp":
        return "outline";
      default:
        return "outline";
    }
  };

  const completedTasks = myTasks.filter(
    (task) => task.status === "Hoàn thành",
  ).length;
  const pendingTasks = myTasks.filter(
    (task) => task.status !== "Hoàn thành",
  ).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2Fa0178697b81a454483dcf391dc368cc9%2Fb3b4f2316e6b4f0cbaff901a9272dd93?format=webp&width=800"
                alt="Lavis Holding Logo"
                className="h-10 w-auto object-contain"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  Lavis Holding CRM
                </h1>
                <p className="text-sm text-gray-600">Workspace cá nhân</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <Badge variant="secondary" className="text-xs">
                  {user.department || "Nhân viên"}
                </Badge>
              </div>
              <Avatar>
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <Button
                variant="outline"
                size="sm"
                onClick={logout}
                className="hover:bg-red-50 hover:border-red-300 hover:text-red-600"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Đăng xuất
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Chào {user.name}! 👋
          </h2>
          <p className="text-gray-600">
            Bạn có {pendingTasks} công việc đang chờ xử lý và {completedTasks}{" "}
            công việc đã hoàn thành.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Công việc đang làm
                  </p>
                  <p className="text-2xl font-bold text-blue-600">
                    {pendingTasks}
                  </p>
                </div>
                <div className="p-3 rounded-full bg-blue-100">
                  <ClipboardList className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Đã hoàn thành
                  </p>
                  <p className="text-2xl font-bold text-green-600">
                    {completedTasks}
                  </p>
                </div>
                <div className="p-3 rounded-full bg-green-100">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Tin nhắn mới
                  </p>
                  <p className="text-2xl font-bold text-purple-600">
                    {recentMessages.length}
                  </p>
                </div>
                <div className="p-3 rounded-full bg-purple-100">
                  <MessageSquare className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="tasks" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-fit">
            <TabsTrigger value="tasks">Công việc của tôi</TabsTrigger>
            <TabsTrigger value="chat">Tin nhắn</TabsTrigger>
            <TabsTrigger value="customers">Khách hàng</TabsTrigger>
            <TabsTrigger value="profile">Thông tin cá nhân</TabsTrigger>
          </TabsList>

          {/* Tasks Tab */}
          <TabsContent value="tasks" className="space-y-6">
            <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ClipboardList className="h-5 w-5 text-blue-600" />
                  Danh sách công việc được giao
                </CardTitle>
                <CardDescription>
                  Quản lý và cập nhật trạng thái công việc của bạn
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {myTasks.map((task) => (
                    <div
                      key={task.id}
                      className="p-4 bg-white/50 rounded-lg border border-gray-100"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-medium text-gray-900">
                          {task.title}
                        </h3>
                        <div className="flex items-center gap-2">
                          <Badge
                            variant={getPriorityColor(task.priority)}
                            className="text-xs"
                          >
                            {task.priority}
                          </Badge>
                          <Badge variant={getStatusColor(task.status)}>
                            {task.status}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">
                        {task.description}
                      </p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center gap-4">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Hạn: {task.deadline}
                          </span>
                          <span>Giao bởi: {task.assignedBy}</span>
                        </div>
                        {task.status !== "Hoàn thành" && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs"
                          >
                            Cập nhật trạng thái
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Chat Tab */}
          <TabsContent value="chat" className="space-y-6">
            <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-purple-600" />
                  Tin nhắn nhóm
                </CardTitle>
                <CardDescription>Trò chuyện với đồng nghiệp</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 mb-4">
                  {recentMessages.map((message) => (
                    <div
                      key={message.id}
                      className="flex items-start gap-3 p-3 bg-white/50 rounded-lg"
                    >
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-xs">
                          {message.from.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium text-gray-900">
                            {message.from}
                          </span>
                          <span className="text-xs text-gray-500">
                            {message.time}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">
                          {message.message}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Nhập tin nhắn..."
                    className="flex-1 px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <Button size="sm">
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Customers Tab */}
          <TabsContent value="customers">
            <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-green-600" />
                  Khách hàng được phân công
                </CardTitle>
                <CardDescription>
                  Danh sách khách hàng bạn đang phụ trách
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center py-8">
                  Danh sách khách hàng được phân công sẽ hiển thị ở đây...
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Thông tin cá nhân</CardTitle>
                <CardDescription>
                  Quản lý thông tin tài khoản của bạn
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback className="text-xl">
                        {user.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">
                        {user.name}
                      </h3>
                      <p className="text-gray-600">
                        {user.department || "Nhân viên"}
                      </p>
                      <Badge variant="secondary" className="mt-1">
                        Nhân viên
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Email
                      </label>
                      <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                        <Mail className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">{user.email}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Tên đăng nhập
                      </label>
                      <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                        <Users className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">{user.username}</span>
                      </div>
                    </div>
                  </div>

                  <Button variant="outline" className="w-full md:w-auto">
                    Cập nhật thông tin
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* AI Chatbot */}
      <AIChatbot
        isOpen={isChatbotOpen}
        onToggle={() => setIsChatbotOpen(!isChatbotOpen)}
        context="general"
      />
    </div>
  );
}
