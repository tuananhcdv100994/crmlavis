import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Users,
  UserPlus,
  Trash2,
  Edit,
  Phone,
  Mail,
  Building2,
  Shield,
  Activity,
  Search,
  Filter,
  MoreVertical,
  Calendar,
  MapPin,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface UserData {
  id: string;
  username: string;
  email: string;
  name: string;
  role: "admin" | "employee";
  department: string;
  position: string;
  phone: string;
  avatar?: string;
  status: "active" | "inactive";
  lastLogin?: string;
  permissions: string[];
  createdAt: string;
}

export default function UserManagement() {
  const { user } = useAuth();
  const [users, setUsers] = useState<UserData[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDepartment, setFilterDepartment] = useState("all");
  const [onlineUsers, setOnlineUsers] = useState(new Set(["admin-1", "emp-1"]));

  // Load users from localStorage or use mock data
  useEffect(() => {
    const savedUsers = localStorage.getItem("crm_users");
    if (savedUsers) {
      try {
        setUsers(JSON.parse(savedUsers));
        return;
      } catch (error) {
        console.error("Error loading saved users:", error);
      }
    }

    const mockUsers: UserData[] = [
      {
        id: "admin-1",
        username: "tuananhcdv",
        email: "admin@lavisholding.com",
        name: "Tuấn Anh - Admin",
        role: "admin",
        department: "Quản trị",
        position: "Giám đốc điều hành",
        phone: "0901234567",
        avatar: "/placeholder.svg",
        status: "active",
        lastLogin: "2024-01-15 09:30",
        permissions: ["all"],
        createdAt: "2023-01-01",
      },
      {
        id: "emp-1",
        username: "employee1",
        email: "nam.nguyen@lavisholding.com",
        name: "Nguyễn Văn Nam",
        role: "employee",
        department: "Kinh doanh",
        position: "Trưởng phòng Sales",
        phone: "0907654321",
        status: "active",
        lastLogin: "2024-01-15 08:45",
        permissions: ["tasks", "customers", "chat"],
        createdAt: "2023-02-15",
      },
      {
        id: "emp-2",
        username: "employee2",
        email: "lan.tran@lavisholding.com",
        name: "Trần Thị Lan",
        role: "employee",
        department: "Marketing",
        position: "Chuyên viên Marketing",
        phone: "0912345678",
        status: "active",
        lastLogin: "2024-01-14 17:20",
        permissions: ["tasks", "chat"],
        createdAt: "2023-03-10",
      },
      {
        id: "emp-3",
        username: "employee3",
        email: "phong.le@lavisholding.com",
        name: "Lê Văn Phong",
        role: "employee",
        department: "Kỹ thuật",
        position: "Kỹ sư",
        phone: "0923456789",
        status: "inactive",
        lastLogin: "2024-01-12 15:30",
        permissions: ["tasks"],
        createdAt: "2023-04-20",
      },
    ];
    setUsers(mockUsers);
    localStorage.setItem("crm_users", JSON.stringify(mockUsers));
  }, []);

  // Save users to localStorage whenever users state changes
  useEffect(() => {
    if (users.length > 0) {
      localStorage.setItem("crm_users", JSON.stringify(users));
    }
  }, [users]);

  if (!user || user.role !== "admin") {
    return <Navigate to="/login" replace />;
  }

  const departments = [
    "Quản trị",
    "Kinh doanh",
    "Marketing",
    "Kỹ thuật",
    "Nhân sự",
    "Kế toán",
  ];
  const positions = [
    "Giám đốc",
    "Trưởng phòng",
    "Chuyên viên",
    "Nhân viên",
    "Thực tập sinh",
  ];
  const permissions = ["tasks", "customers", "chat", "reports", "settings"];

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.department.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment =
      filterDepartment === "all" || u.department === filterDepartment;
    return matchesSearch && matchesDepartment;
  });

  const stats = {
    total: users.length,
    active: users.filter((u) => u.status === "active").length,
    online: onlineUsers.size,
    admins: users.filter((u) => u.role === "admin").length,
  };

  const CreateUserForm = () => {
    const [formData, setFormData] = useState({
      username: "",
      email: "",
      name: "",
      department: "",
      position: "",
      phone: "",
      role: "employee",
      permissions: [] as string[],
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();

      // Validation
      if (
        !formData.name.trim() ||
        !formData.username.trim() ||
        !formData.email.trim()
      ) {
        toast({
          title: "Lỗi validation",
          description: "Vui lòng điền đầy đủ thông tin bắt buộc",
          variant: "destructive",
        });
        return;
      }

      if (!formData.department || !formData.position) {
        toast({
          title: "Lỗi validation",
          description: "Vui lòng chọn phòng ban và chức vụ",
          variant: "destructive",
        });
        return;
      }

      try {
        const newUser: UserData = {
          id: `user-${Date.now()}`,
          ...formData,
          role: formData.role as "admin" | "employee",
          avatar: "/placeholder.svg",
          status: "active",
          createdAt: new Date().toISOString().split("T")[0],
          lastLogin: undefined,
        };

        console.log("Adding new user:", newUser);
        setUsers((prev) => {
          const updated = [...prev, newUser];
          console.log("Updated users list:", updated);
          return updated;
        });

        setIsCreateDialogOpen(false);
        setFormData({
          username: "",
          email: "",
          name: "",
          department: "",
          position: "",
          phone: "",
          role: "employee",
          permissions: [],
        });

        toast({
          title: "Tạo tài khoản thành công",
          description: `Đã tạo tài khoản cho ${newUser.name}`,
        });
      } catch (error) {
        console.error("Error creating user:", error);
        toast({
          title: "Lỗi tạo tài khoản",
          description: "Có lỗi xảy ra khi tạo tài khoản",
          variant: "destructive",
        });
      }
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Họ và tên *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, name: e.target.value }))
              }
              placeholder="Nhập họ và tên"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="username">Tên đăng nhập *</Label>
            <Input
              id="username"
              value={formData.username}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, username: e.target.value }))
              }
              placeholder="Nhập tên đăng nhập"
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, email: e.target.value }))
              }
              placeholder="Nhập email"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Số điện thoại *</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, phone: e.target.value }))
              }
              placeholder="Nhập số điện thoại"
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="department">Phòng ban *</Label>
            <Select
              value={formData.department}
              onValueChange={(value) =>
                setFormData((prev) => ({ ...prev, department: value }))
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Chọn phòng ban" />
              </SelectTrigger>
              <SelectContent>
                {departments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="position">Chức vụ *</Label>
            <Select
              value={formData.position}
              onValueChange={(value) =>
                setFormData((prev) => ({ ...prev, position: value }))
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Chọn chức vụ" />
              </SelectTrigger>
              <SelectContent>
                {positions.map((pos) => (
                  <SelectItem key={pos} value={pos}>
                    {pos}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="role">Vai trò</Label>
          <Select
            value={formData.role}
            onValueChange={(value) =>
              setFormData((prev) => ({ ...prev, role: value }))
            }
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="employee">Nhân viên</SelectItem>
              <SelectItem value="admin">Quản trị viên</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Quyền hạn</Label>
          <div className="flex flex-wrap gap-2">
            {permissions.map((perm) => (
              <label
                key={perm}
                className="flex items-center space-x-2 cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={formData.permissions.includes(perm)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setFormData((prev) => ({
                        ...prev,
                        permissions: [...prev.permissions, perm],
                      }));
                    } else {
                      setFormData((prev) => ({
                        ...prev,
                        permissions: prev.permissions.filter((p) => p !== perm),
                      }));
                    }
                  }}
                  className="rounded"
                />
                <span className="text-sm capitalize">{perm}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => setIsCreateDialogOpen(false)}
          >
            Hủy
          </Button>
          <Button type="submit">Tạo tài khoản</Button>
        </div>
      </form>
    );
  };

  const deleteUser = (userId: string) => {
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    toast({
      title: "Xóa tài khoản thành công",
      description: "Tài khoản đã được xóa khỏi hệ thống",
    });
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tổng người dùng</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Đang hoạt động</p>
                <p className="text-2xl font-bold text-green-600">
                  {stats.active}
                </p>
              </div>
              <Activity className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Đang trực tuyến</p>
                <p className="text-2xl font-bold text-purple-600">
                  {stats.online}
                </p>
              </div>
              <div className="h-3 w-3 bg-green-500 rounded-full animate-pulse" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Quản trị viên</p>
                <p className="text-2xl font-bold text-orange-600">
                  {stats.admins}
                </p>
              </div>
              <Shield className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Quản lý người dùng</CardTitle>
              <CardDescription>
                Tạo, chỉnh sửa và quản lý tài khoản người dùng
              </CardDescription>
            </div>
            <Dialog
              open={isCreateDialogOpen}
              onOpenChange={setIsCreateDialogOpen}
            >
              <DialogTrigger asChild>
                <Button>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Tạo tài khoản
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Tạo tài khoản mới</DialogTitle>
                  <DialogDescription>
                    Điền thông tin để tạo tài khoản cho nhân viên mới
                  </DialogDescription>
                </DialogHeader>
                <CreateUserForm />
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Tìm kiếm theo tên, email, phòng ban..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select
              value={filterDepartment}
              onValueChange={setFilterDepartment}
            >
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả phòng ban</SelectItem>
                {departments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Users Table */}
          <div className="space-y-4">
            {filteredUsers.map((userData) => (
              <div
                key={userData.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center space-x-4 flex-1">
                  <div className="relative">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={userData.avatar} alt={userData.name} />
                      <AvatarFallback>{userData.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    {onlineUsers.has(userData.id) && (
                      <div className="absolute -bottom-1 -right-1 h-4 w-4 bg-green-500 border-2 border-white rounded-full" />
                    )}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium">{userData.name}</h3>
                      <Badge
                        variant={
                          userData.role === "admin" ? "default" : "secondary"
                        }
                      >
                        {userData.role === "admin" ? "Admin" : "Nhân viên"}
                      </Badge>
                      <Badge
                        variant={
                          userData.status === "active" ? "default" : "outline"
                        }
                      >
                        {userData.status === "active"
                          ? "Hoạt động"
                          : "Không hoạt động"}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1">
                          <Mail className="h-3 w-3" />
                          {userData.email}
                        </span>
                        <span className="flex items-center gap-1">
                          <Phone className="h-3 w-3" />
                          {userData.phone}
                        </span>
                        <span className="flex items-center gap-1">
                          <Building2 className="h-3 w-3" />
                          {userData.department} - {userData.position}
                        </span>
                      </div>
                      {userData.lastLogin && (
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <Calendar className="h-3 w-3" />
                          Đăng nhập lần cuối: {userData.lastLogin}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4" />
                  </Button>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="hover:bg-red-50 hover:border-red-300"
                      >
                        <Trash2 className="h-4 w-4 text-red-600" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          Xác nhận xóa tài khoản
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          Bạn có chắc chắn mu���n xóa tài khoản của{" "}
                          {userData.name}? Hành động này không thể hoàn tác.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Hủy</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => deleteUser(userData.id)}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          Xóa tài khoản
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))}
          </div>

          {filteredUsers.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              Không tìm thấy người dùng nào phù hợp với tiêu chí tìm kiếm.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
