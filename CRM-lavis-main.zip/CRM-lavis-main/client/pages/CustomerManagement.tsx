import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Users,
  UserPlus,
  Building2,
  Phone,
  Mail,
  MapPin,
  Calendar,
  DollarSign,
  Star,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  Search,
  Filter,
  Edit,
  Trash2,
  Bot,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { AIService } from "@/services/aiService";

export interface Customer {
  id: string;
  name: string;
  industry: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  status: "potential" | "non-potential" | "consulting" | "customer";
  assignedTo?: string;
  assignedToName?: string;
  estimatedValue?: number;
  notes: string;
  createdAt: string;
  lastContact?: string;
  source: string;
  priority: "high" | "medium" | "low";
}

export default function CustomerManagement() {
  const { user } = useAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterAssignee, setFilterAssignee] = useState("all");
  const [aiInsights, setAiInsights] = useState<{ [key: string]: string }>({});

  // Check if user can add customers (only sales and marketing)
  const canAddCustomers =
    user?.role === "admin" ||
    ["Kinh doanh", "Marketing"].includes(user?.department || "");

  // Debug logging
  useEffect(() => {
    console.log("Current user:", user);
    console.log("Can add customers:", canAddCustomers);
    console.log("User department:", user?.department);
    console.log("User role:", user?.role);
  }, [user, canAddCustomers]);

  useEffect(() => {
    // Load customers from localStorage or use mock data
    const savedCustomers = localStorage.getItem("crm_customers");
    if (savedCustomers) {
      try {
        setCustomers(JSON.parse(savedCustomers));
        return;
      } catch (error) {
        console.error("Error loading saved customers:", error);
      }
    }

    // Mock customer data
    const mockCustomers: Customer[] = [
      {
        id: "cust-1",
        name: "Công ty TNHH ABC Paint",
        industry: "Sản xuất",
        contactPerson: "Nguyễn Văn A",
        email: "contact@abcpaint.com",
        phone: "0901234567",
        address: "Hà Nội",
        status: "potential",
        assignedTo: "emp-1",
        assignedToName: "Nguyễn Văn Nam",
        estimatedValue: 500000000,
        notes: "Khách hàng quan tâm đến sơn công nghiệp",
        createdAt: "2024-01-10",
        lastContact: "2024-01-15",
        source: "Website",
        priority: "high",
      },
      {
        id: "cust-2",
        name: "Khách sạn XYZ Resort",
        industry: "Du lịch",
        contactPerson: "Trần Thị B",
        email: "manager@xyzresort.com",
        phone: "0907654321",
        address: "Đà Nẵng",
        status: "consulting",
        assignedTo: "emp-2",
        assignedToName: "Trần Thị Lan",
        estimatedValue: 800000000,
        notes: "Đang tư vấn sơn cho dự án mở rộng",
        createdAt: "2024-01-05",
        lastContact: "2024-01-14",
        source: "Giới thiệu",
        priority: "high",
      },
      {
        id: "cust-3",
        name: "Nhà máy DEF Industries",
        industry: "Công nghiệp",
        contactPerson: "Lê Văn C",
        email: "purchasing@defindustries.com",
        phone: "0912345678",
        address: "TP.HCM",
        status: "customer",
        assignedTo: "emp-1",
        assignedToName: "Nguyễn Văn Nam",
        estimatedValue: 1200000000,
        notes: "Khách hàng đã ký hợp đồng, đang trong giai đoạn thực hiện",
        createdAt: "2023-12-20",
        lastContact: "2024-01-12",
        source: "Cold Call",
        priority: "medium",
      },
      {
        id: "cust-4",
        name: "Văn phòng GHI Corp",
        industry: "Dịch vụ",
        contactPerson: "Phạm Thị D",
        email: "admin@ghicorp.com",
        phone: "0923456789",
        address: "Hà Nội",
        status: "non-potential",
        notes: "Không có nhu cầu trong thời gian gần",
        createdAt: "2024-01-08",
        lastContact: "2024-01-10",
        source: "Email Marketing",
        priority: "low",
      },
    ];
    setCustomers(mockCustomers);
    localStorage.setItem("crm_customers", JSON.stringify(mockCustomers));
  }, []);

  // Save customers to localStorage whenever customers state changes
  useEffect(() => {
    if (customers.length > 0) {
      localStorage.setItem("crm_customers", JSON.stringify(customers));
    }
  }, [customers]);

  const getStatusColor = (status: Customer["status"]) => {
    switch (status) {
      case "potential":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "consulting":
        return "bg-blue-100 text-blue-800 border-blue-300";
      case "customer":
        return "bg-green-100 text-green-800 border-green-300";
      case "non-potential":
        return "bg-gray-100 text-gray-800 border-gray-300";
      default:
        return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  const getStatusIcon = (status: Customer["status"]) => {
    switch (status) {
      case "potential":
        return <Star className="h-4 w-4" />;
      case "consulting":
        return <Clock className="h-4 w-4" />;
      case "customer":
        return <CheckCircle className="h-4 w-4" />;
      case "non-potential":
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  const getStatusText = (status: Customer["status"]) => {
    switch (status) {
      case "potential":
        return "Tiềm năng";
      case "consulting":
        return "Đang tư vấn";
      case "customer":
        return "Khách hàng";
      case "non-potential":
        return "Không tiềm năng";
      default:
        return "Không xác định";
    }
  };

  const employees = [
    { id: "emp-1", name: "Nguyễn Văn Nam", department: "Kinh doanh" },
    { id: "emp-2", name: "Trần Thị Lan", department: "Marketing" },
    { id: "emp-3", name: "Lê Văn Phong", department: "Kỹ thuật" },
  ];

  const filteredCustomers = customers.filter((customer) => {
    const matchesSearch =
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.contactPerson.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.industry.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      filterStatus === "all" || customer.status === filterStatus;
    const matchesAssignee =
      filterAssignee === "all" || customer.assignedTo === filterAssignee;
    return matchesSearch && matchesStatus && matchesAssignee;
  });

  const stats = {
    total: customers.length,
    potential: customers.filter((c) => c.status === "potential").length,
    consulting: customers.filter((c) => c.status === "consulting").length,
    customers: customers.filter((c) => c.status === "customer").length,
  };

  const generateAIInsights = async (customer: Customer) => {
    const response = await AIService.generateCustomerInsights(
      customer.name,
      customer.industry,
      getStatusText(customer.status),
    );

    if (response.success) {
      setAiInsights((prev) => ({ ...prev, [customer.id]: response.text }));
      toast({
        title: "AI Insights được tạo",
        description: `Đã phân tích khách hàng ${customer.name}`,
      });
    } else {
      toast({
        title: "Lỗi AI",
        description: response.error || "Không thể tạo insights",
        variant: "destructive",
      });
    }
  };

  const changeCustomerStatus = (
    customerId: string,
    newStatus: Customer["status"],
  ) => {
    const customer = customers.find((c) => c.id === customerId);
    setCustomers((prev) =>
      prev.map((customer) =>
        customer.id === customerId
          ? { ...customer, status: newStatus }
          : customer,
      ),
    );

    toast({
      title: "✅ Cập nhật trạng thái thành công",
      description: `Đã chuyển trạng thái "${customer?.name}" thành ${getStatusText(newStatus)}`,
    });
  };

  const assignEmployee = (customerId: string, employeeId: string) => {
    const employee = employees.find((emp) => emp.id === employeeId);
    const customer = customers.find((c) => c.id === customerId);
    setCustomers((prev) =>
      prev.map((customer) =>
        customer.id === customerId
          ? {
              ...customer,
              assignedTo: employeeId,
              assignedToName: employee?.name,
            }
          : customer,
      ),
    );

    toast({
      title: "✅ Gán nhân viên thành công",
      description: `Đã gán "${customer?.name}" cho ${employee?.name}`,
    });
  };

  const CreateCustomerForm = () => {
    const [formData, setFormData] = useState({
      name: "",
      industry: "",
      contactPerson: "",
      email: "",
      phone: "",
      address: "",
      estimatedValue: "",
      notes: "",
      source: "",
      priority: "medium" as Customer["priority"],
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();

      // Validation
      if (!formData.name.trim()) {
        toast({
          title: "Lỗi validation",
          description: "Vui lòng nhập tên khách hàng",
          variant: "destructive",
        });
        return;
      }

      try {
        const newCustomer: Customer = {
          id: `cust-${Date.now()}`,
          name: formData.name,
          industry: formData.industry,
          contactPerson: formData.contactPerson,
          email: formData.email,
          phone: formData.phone,
          address: formData.address,
          estimatedValue: formData.estimatedValue
            ? parseInt(formData.estimatedValue)
            : undefined,
          notes: formData.notes,
          source: formData.source,
          priority: formData.priority,
          status: "potential",
          assignedTo: user?.id,
          assignedToName: user?.name,
          createdAt: new Date().toISOString().split("T")[0],
        };

        console.log("Adding new customer:", newCustomer);
        setCustomers((prev) => {
          const updated = [...prev, newCustomer];
          console.log("Updated customers list:", updated);
          return updated;
        });

        setIsCreateDialogOpen(false);

        // Reset form
        setFormData({
          name: "",
          industry: "",
          contactPerson: "",
          email: "",
          phone: "",
          address: "",
          estimatedValue: "",
          notes: "",
          source: "",
          priority: "medium",
        });

        toast({
          title: "🎉 Thêm khách hàng thành công!",
          description: `Đã thêm khách hàng "${newCustomer.name}" vào hệ thống`,
        });
      } catch (error) {
        console.error("Error adding customer:", error);
        toast({
          title: "Lỗi thêm khách hàng",
          description: "Có lỗi xảy ra khi thêm khách hàng",
          variant: "destructive",
        });
      }
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Tên công ty/khách hàng *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, name: e.target.value }))
              }
              placeholder="Nhập tên khách hàng"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="industry">Lĩnh vực</Label>
            <Input
              id="industry"
              value={formData.industry}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, industry: e.target.value }))
              }
              placeholder="VD: Sản xuất, Du lịch..."
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="contactPerson">Người liên hệ</Label>
            <Input
              id="contactPerson"
              value={formData.contactPerson}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  contactPerson: e.target.value,
                }))
              }
              placeholder="Tên người liên hệ"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Số điện thoại</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, phone: e.target.value }))
              }
              placeholder="Số điện thoại liên hệ"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, email: e.target.value }))
              }
              placeholder="Email liên hệ"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="address">Địa chỉ</Label>
            <Input
              id="address"
              value={formData.address}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, address: e.target.value }))
              }
              placeholder="Địa chỉ khách hàng"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="estimatedValue">Giá trị ước tính (VND)</Label>
            <Input
              id="estimatedValue"
              type="number"
              value={formData.estimatedValue}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  estimatedValue: e.target.value,
                }))
              }
              placeholder="Ví dụ: 500000000"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="source">Nguồn khách hàng</Label>
            <Select
              value={formData.source}
              onValueChange={(value) =>
                setFormData((prev) => ({ ...prev, source: value }))
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Chọn nguồn" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Website">Website</SelectItem>
                <SelectItem value="Giới thiệu">Giới thiệu</SelectItem>
                <SelectItem value="Cold Call">Cold Call</SelectItem>
                <SelectItem value="Email Marketing">Email Marketing</SelectItem>
                <SelectItem value="Social Media">Social Media</SelectItem>
                <SelectItem value="Hội chợ">Hội chợ</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="priority">Độ ưu tiên</Label>
          <Select
            value={formData.priority}
            onValueChange={(value) =>
              setFormData((prev) => ({
                ...prev,
                priority: value as Customer["priority"],
              }))
            }
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="high">Cao</SelectItem>
              <SelectItem value="medium">Trung bình</SelectItem>
              <SelectItem value="low">Thấp</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">Ghi chú</Label>
          <Textarea
            id="notes"
            value={formData.notes}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, notes: e.target.value }))
            }
            placeholder="Thông tin bổ sung về khách hàng..."
            rows={3}
          />
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => setIsCreateDialogOpen(false)}
          >
            Hủy
          </Button>
          <Button type="submit">Thêm khách hàng</Button>
        </div>
      </form>
    );
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tổng khách hàng</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <Building2 className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tiềm năng</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {stats.potential}
                </p>
              </div>
              <Star className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Đang tư vấn</p>
                <p className="text-2xl font-bold text-blue-600">
                  {stats.consulting}
                </p>
              </div>
              <Clock className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Đã chuyển đổi</p>
                <p className="text-2xl font-bold text-green-600">
                  {stats.customers}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Quản lý khách hàng</CardTitle>
              <CardDescription>
                {canAddCustomers
                  ? "Quản lý và theo dõi khách hàng"
                  : "Xem danh sách khách hàng (chỉ Sales/Marketing mới có thể thêm mới)"}
              </CardDescription>
            </div>
            {canAddCustomers ? (
              <Dialog
                open={isCreateDialogOpen}
                onOpenChange={setIsCreateDialogOpen}
              >
                <DialogTrigger asChild>
                  <Button>
                    <UserPlus className="h-4 w-4 mr-2" />
                    Thêm khách hàng
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Thêm khách hàng mới</DialogTitle>
                    <DialogDescription>
                      Nhập thông tin chi tiết về khách hàng
                    </DialogDescription>
                  </DialogHeader>
                  <CreateCustomerForm />
                </DialogContent>
              </Dialog>
            ) : (
              <p className="text-sm text-gray-600">
                Chỉ phòng ban Sales/Marketing mới có thể thêm khách hàng
              </p>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Tìm kiếm khách hàng..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả trạng thái</SelectItem>
                <SelectItem value="potential">Tiềm năng</SelectItem>
                <SelectItem value="consulting">Đang tư vấn</SelectItem>
                <SelectItem value="customer">Khách hàng</SelectItem>
                <SelectItem value="non-potential">Không tiềm năng</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterAssignee} onValueChange={setFilterAssignee}>
              <SelectTrigger className="w-48">
                <Users className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả nhân viên</SelectItem>
                {employees.map((emp) => (
                  <SelectItem key={emp.id} value={emp.id}>
                    {emp.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Customers Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredCustomers.map((customer) => (
              <Card
                key={customer.id}
                className="border-l-4 border-l-blue-400 hover:shadow-md transition-shadow"
              >
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-semibold text-lg mb-1">
                        {customer.name}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {customer.industry}
                      </p>
                    </div>
                    <div className="flex flex-col gap-2">
                      <div
                        className={`px-3 py-1 rounded-full text-xs font-medium border flex items-center gap-1 ${getStatusColor(customer.status)}`}
                      >
                        {getStatusIcon(customer.status)}
                        {getStatusText(customer.status)}
                      </div>
                      <Badge
                        variant={
                          customer.priority === "high"
                            ? "destructive"
                            : customer.priority === "medium"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {customer.priority === "high"
                          ? "Cao"
                          : customer.priority === "medium"
                            ? "TB"
                            : "Thấp"}
                      </Badge>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm mb-4">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-gray-400" />
                      <span>{customer.contactPerson}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-gray-400" />
                      <span>{customer.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-gray-400" />
                      <span>{customer.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      <span>{customer.address}</span>
                    </div>
                    {customer.estimatedValue && (
                      <div className="flex items-center gap-2">
                        <DollarSign className="h-4 w-4 text-gray-400" />
                        <span>
                          {customer.estimatedValue.toLocaleString("vi-VN")} VND
                        </span>
                      </div>
                    )}
                    {customer.assignedToName && (
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-gray-400" />
                        <span>Phụ trách: {customer.assignedToName}</span>
                      </div>
                    )}
                  </div>

                  {customer.notes && (
                    <div className="mb-4 p-2 bg-gray-50 rounded text-sm">
                      {customer.notes}
                    </div>
                  )}

                  {aiInsights[customer.id] && (
                    <div className="mb-4 p-3 bg-blue-50 border-l-4 border-blue-400 rounded text-sm">
                      <div className="flex items-center gap-2 font-medium text-blue-900 mb-2">
                        <Bot className="h-4 w-4" />
                        AI Insights
                      </div>
                      <div className="text-blue-800 whitespace-pre-line">
                        {aiInsights[customer.id]}
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2 flex-wrap">
                    <Select
                      value={customer.status}
                      onValueChange={(value) =>
                        changeCustomerStatus(
                          customer.id,
                          value as Customer["status"],
                        )
                      }
                    >
                      <SelectTrigger className="flex-1 min-w-[120px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="potential">Tiềm năng</SelectItem>
                        <SelectItem value="consulting">Đang tư vấn</SelectItem>
                        <SelectItem value="customer">Khách hàng</SelectItem>
                        <SelectItem value="non-potential">
                          Không tiềm năng
                        </SelectItem>
                      </SelectContent>
                    </Select>

                    <Select
                      value={customer.assignedTo || ""}
                      onValueChange={(value) =>
                        assignEmployee(customer.id, value)
                      }
                    >
                      <SelectTrigger className="flex-1 min-w-[120px]">
                        <SelectValue placeholder="Gán NV" />
                      </SelectTrigger>
                      <SelectContent>
                        {employees.map((emp) => (
                          <SelectItem key={emp.id} value={emp.id}>
                            {emp.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => generateAIInsights(customer)}
                      disabled={!!aiInsights[customer.id]}
                    >
                      <Bot className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredCustomers.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              Không tìm thấy khách hàng nào phù hợp với tiêu chí tìm kiếm.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
