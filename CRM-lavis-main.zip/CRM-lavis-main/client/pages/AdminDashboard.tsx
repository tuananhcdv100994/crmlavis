import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import UserManagement from "./UserManagement";
import CustomerManagement from "./CustomerManagement";
import TaskManagement from "./TaskManagement";
import AIChatbot from "@/components/AIChatbot";
import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users,
  Building2,
  ClipboardList,
  MessageSquare,
  BarChart3,
  UserPlus,
  Settings,
  LogOut,
  Paintbrush2,
  Phone,
  Mail,
  Calendar,
  TrendingUp,
  Activity,
  CheckCircle,
  Shield,
} from "lucide-react";

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);

  if (!user || user.role !== "admin") {
    return <Navigate to="/login" replace />;
  }

  const stats = [
    {
      label: "Tổng khách hàng",
      value: "1,234",
      change: "+12%",
      icon: Users,
      color: "text-blue-600",
    },
    {
      label: "Dự án đang thực hiện",
      value: "89",
      change: "+5%",
      icon: ClipboardList,
      color: "text-green-600",
    },
    {
      label: "Nhân viên hoạt động",
      value: "45",
      change: "+2%",
      icon: Activity,
      color: "text-purple-600",
    },
    {
      label: "Doanh thu tháng",
      value: "2.4B VND",
      change: "+18%",
      icon: TrendingUp,
      color: "text-cyan-600",
    },
  ];

  const recentCustomers = [
    {
      id: "1",
      name: "Công ty TNHH ABC",
      contact: "Nguyễn Văn A",
      phone: "0901234567",
      status: "Tiềm năng",
    },
    {
      id: "2",
      name: "Khách sạn XYZ",
      contact: "Trần Thị B",
      phone: "0907654321",
      status: "Đang t�� vấn",
    },
    {
      id: "3",
      name: "Nhà máy DEF",
      contact: "Lê Văn C",
      phone: "0912345678",
      status: "Đã ký HĐ",
    },
  ];

  const recentTasks = [
    {
      id: "1",
      title: "Tư vấn sơn cho khách hàng ABC",
      assignee: "Nguyễn Văn Nam",
      status: "Đang thực hiện",
      priority: "Cao",
    },
    {
      id: "2",
      title: "Giao hàng dự ��n XYZ",
      assignee: "Trần Thị Lan",
      status: "Hoàn thành",
      priority: "Trung bình",
    },
    {
      id: "3",
      title: "Báo giá cho khách hàng mới",
      assignee: "Lê Văn Phong",
      status: "Chờ duyệt",
      priority: "Thấp",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2Fa0178697b81a454483dcf391dc368cc9%2Fb3b4f2316e6b4f0cbaff901a9272dd93?format=webp&width=800"
                alt="Lavis Holding Logo"
                className="h-10 w-auto object-contain"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  Lavis Holding CRM
                </h1>
                <p className="text-sm text-gray-600">
                  Bảng điều khiển quản trị
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <Badge variant="secondary" className="text-xs">
                  <Settings className="h-3 w-3 mr-1" />
                  {user.role === "admin" ? "Quản trị viên" : "Nhân viên"}
                </Badge>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={logout}
                className="hover:bg-red-50 hover:border-red-300 hover:text-red-600"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Đăng xuất
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className="bg-white/60 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-200"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      {stat.label}
                    </p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">
                      {stat.value}
                    </p>
                    <p
                      className={`text-sm mt-1 ${stat.change.startsWith("+") ? "text-green-600" : "text-red-600"}`}
                    >
                      {stat.change} so với tháng trước
                    </p>
                  </div>
                  <div
                    className={`p-3 rounded-full bg-gradient-to-br from-blue-100 to-cyan-100`}
                  >
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-7 lg:w-fit">
            <TabsTrigger value="overview">Tổng quan</TabsTrigger>
            <TabsTrigger value="users">Quản lý User</TabsTrigger>
            <TabsTrigger value="customers">Khách hàng</TabsTrigger>
            <TabsTrigger value="tasks">Giao việc</TabsTrigger>
            <TabsTrigger value="departments">Phòng ban</TabsTrigger>
            <TabsTrigger value="reports">Báo cáo</TabsTrigger>
            <TabsTrigger value="settings">Cài đặt</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Customers */}
              <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-blue-600" />
                    Khách hàng mới nhất
                  </CardTitle>
                  <CardDescription>
                    Danh sách khách hàng được thêm gần đây
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentCustomers.map((customer) => (
                      <div
                        key={customer.id}
                        className="flex items-center justify-between p-3 bg-white/50 rounded-lg"
                      >
                        <div>
                          <p className="font-medium text-gray-900">
                            {customer.name}
                          </p>
                          <p className="text-sm text-gray-600 flex items-center gap-1">
                            <Phone className="h-3 w-3" />
                            {customer.contact} - {customer.phone}
                          </p>
                        </div>
                        <Badge
                          variant={
                            customer.status === "Đã ký HĐ"
                              ? "default"
                              : customer.status === "Đang tư vấn"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {customer.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                  <Button className="w-full mt-4" variant="outline">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Thêm khách hàng mới
                  </Button>
                </CardContent>
              </Card>

              {/* Recent Tasks */}
              <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ClipboardList className="h-5 w-5 text-green-600" />
                    Công việc gần đây
                  </CardTitle>
                  <CardDescription>
                    Trạng thái các công việc được giao
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentTasks.map((task) => (
                      <div
                        key={task.id}
                        className="flex items-center justify-between p-3 bg-white/50 rounded-lg"
                      >
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">
                            {task.title}
                          </p>
                          <p className="text-sm text-gray-600">
                            {task.assignee}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge
                            variant={
                              task.priority === "Cao"
                                ? "destructive"
                                : task.priority === "Trung bình"
                                  ? "secondary"
                                  : "outline"
                            }
                            className="text-xs"
                          >
                            {task.priority}
                          </Badge>
                          <Badge
                            variant={
                              task.status === "Hoàn thành"
                                ? "default"
                                : "outline"
                            }
                          >
                            {task.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button className="w-full mt-4" variant="outline">
                    <ClipboardList className="h-4 w-4 mr-2" />
                    Giao việc mới
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users">
            <UserManagement />
          </TabsContent>

          {/* Other tabs content placeholders */}
          <TabsContent value="customers">
            <CustomerManagement />
          </TabsContent>

          <TabsContent value="tasks">
            <TaskManagement />
          </TabsContent>

          <TabsContent value="employees">
            <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Quản lý nhân vi��n</CardTitle>
                <CardDescription>
                  Danh sách nhân viên và phân quyền
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center py-8">
                  T��nh năng quản lý nhân viên đang được phát triển...
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="departments">
            <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Quản lý phòng ban</CardTitle>
                <CardDescription>Tạo và quản lý cơ cấu tổ chức</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center py-8">
                  Tính năng quản lý phòng ban đang được phát triển...
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Báo cáo và thống kê</CardTitle>
                <CardDescription>
                  Theo dõi hiệu suất và tiến độ công việc
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center py-8">
                  Tính năng báo cáo đang được phát triển...
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5 text-blue-600" />
                    Cài đặt hệ thống
                  </CardTitle>
                  <CardDescription>
                    Quản lý cài đặt và cấu hình hệ thống
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-white/50 rounded-lg">
                    <div>
                      <p className="font-medium">Tích hợp AI</p>
                      <p className="text-sm text-gray-600">
                        Google Gemini AI được kích hoạt
                      </p>
                    </div>
                    <Badge>Đang hoạt động</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-white/50 rounded-lg">
                    <div>
                      <p className="font-medium">Chatbot AI</p>
                      <p className="text-sm text-gray-600">
                        Hỗ trợ khách hàng tự động
                      </p>
                    </div>
                    <Badge variant="secondary">Sẵn sàng</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-white/50 rounded-lg">
                    <div>
                      <p className="font-medium">Thông báo thời gian thực</p>
                      <p className="text-sm text-gray-600">
                        Cập nhật trạng thái ngay lập tức
                      </p>
                    </div>
                    <Badge>Bật</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-green-600" />
                    Bảo mật và quyền hạn
                  </CardTitle>
                  <CardDescription>
                    Quản lý phân quyền và bảo mật
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <p className="font-medium">Quyền tạo khách hàng</p>
                    <div className="text-sm text-gray-600">
                      Chỉ phòng ban: <strong>Kinh doanh, Marketing</strong>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="font-medium">Quyền tạo task</p>
                    <div className="text-sm text-gray-600">
                      Admin và người được phân quyền
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="font-medium">Thông tin tài khoản Admin</p>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div>
                        Tên đăng nhập: <strong>tuananhcdv</strong>
                      </div>
                      <div>
                        Vai trò: <strong>Quản trị viên</strong>
                      </div>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    onClick={logout}
                    className="w-full hover:bg-red-50 hover:border-red-300 hover:text-red-600"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Đăng xuất khỏi tài khoản Admin
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* AI Chatbot */}
      <AIChatbot
        isOpen={isChatbotOpen}
        onToggle={() => setIsChatbotOpen(!isChatbotOpen)}
        context="general"
      />
    </div>
  );
}
