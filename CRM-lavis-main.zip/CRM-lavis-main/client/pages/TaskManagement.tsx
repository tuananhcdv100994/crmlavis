import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  ClipboardList,
  Plus,
  Clock,
  AlertTriangle,
  CheckCircle,
  Users,
  Calendar as CalendarIcon2,
  Tag,
  Search,
  Filter,
  Bot,
  Flag,
  Target,
  MessageSquare,
  FileText,
  Trash2,
  Edit,
  Eye,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { AIService } from "@/services/aiService";

export interface Task {
  id: string;
  title: string;
  description: string;
  status: "pending" | "in-progress" | "completed" | "overdue";
  priority: "high" | "medium" | "low";
  isPriorityMarked: boolean;
  deadline: string;
  assignees: string[];
  assigneeNames: string[];
  relatedPersons: string[];
  relatedPersonNames: string[];
  tags: string[];
  category: string;
  createdBy: string;
  createdByName: string;
  createdAt: string;
  completedAt?: string;
  estimatedHours?: number;
  actualHours?: number;
  attachments: string[];
  comments: Array<{
    id: string;
    author: string;
    content: string;
    timestamp: string;
  }>;
}

export default function TaskManagement() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  const [filterAssignee, setFilterAssignee] = useState("all");
  const [aiSuggestions, setAiSuggestions] = useState<{ [key: string]: string }>(
    {},
  );

  // Check if user can create tasks (admin or authorized users)
  const canCreateTasks =
    user?.role === "admin" ||
    user?.permissions?.includes("create_tasks") ||
    user?.permissions?.includes("tasks") ||
    user?.permissions?.includes("all");

  useEffect(() => {
    // Load tasks from localStorage or use mock data
    const savedTasks = localStorage.getItem("crm_tasks");
    if (savedTasks) {
      try {
        setTasks(JSON.parse(savedTasks));
        return;
      } catch (error) {
        console.error("Error loading saved tasks:", error);
      }
    }

    // Mock task data
    const mockTasks: Task[] = [
      {
        id: "task-1",
        title: "Tư vấn sơn cho khách hàng ABC Paint",
        description:
          "Liên hệ và tư vấn loại sơn phù hợp cho dự án nhà máy. Cần phân tích yêu cầu và đưa ra báo giá chi tiết.",
        status: "in-progress",
        priority: "high",
        isPriorityMarked: true,
        deadline: "2024-01-20",
        assignees: ["emp-1"],
        assigneeNames: ["Nguyễn Văn Nam"],
        relatedPersons: ["emp-2"],
        relatedPersonNames: ["Trần Thị Lan"],
        tags: ["tư vấn", "báo giá", "khách hàng"],
        category: "Kinh doanh",
        createdBy: "admin-1",
        createdByName: "Tuấn Anh - Admin",
        createdAt: "2024-01-15",
        estimatedHours: 8,
        actualHours: 5,
        attachments: [],
        comments: [
          {
            id: "comment-1",
            author: "Nguyễn Văn Nam",
            content: "Đã liên hệ khách hàng, họ quan tâm đến sơn chống ăn mòn",
            timestamp: "2024-01-16 09:30",
          },
        ],
      },
      {
        id: "task-2",
        title: "Cập nhật website với sản phẩm mới",
        description:
          "Thêm thông tin sản phẩm sơn mới vào website công ty. Bao gồm hình ảnh, mô tả và thông số kỹ thuật.",
        status: "pending",
        priority: "medium",
        isPriorityMarked: false,
        deadline: "2024-01-25",
        assignees: ["emp-2"],
        assigneeNames: ["Trần Thị Lan"],
        relatedPersons: ["emp-3"],
        relatedPersonNames: ["Lê Văn Phong"],
        tags: ["website", "marketing", "sản phẩm"],
        category: "Marketing",
        createdBy: "admin-1",
        createdByName: "Tuấn Anh - Admin",
        createdAt: "2024-01-14",
        estimatedHours: 6,
        attachments: [],
        comments: [],
      },
      {
        id: "task-3",
        title: "Báo cáo doanh thu tháng 1",
        description:
          "Tổng hợp và phân tích doanh thu tháng 1. So sánh với cùng kỳ năm trước và đưa ra nhận xét.",
        status: "completed",
        priority: "high",
        isPriorityMarked: true,
        deadline: "2024-01-31",
        assignees: ["emp-1"],
        assigneeNames: ["Nguyễn Văn Nam"],
        relatedPersons: [],
        relatedPersonNames: [],
        tags: ["báo cáo", "doanh thu", "phân tích"],
        category: "Quản lý",
        createdBy: "admin-1",
        createdByName: "Tuấn Anh - Admin",
        createdAt: "2024-01-10",
        completedAt: "2024-01-30",
        estimatedHours: 4,
        actualHours: 3,
        attachments: ["bao-cao-doanh-thu-t1.pdf"],
        comments: [],
      },
    ];
    setTasks(mockTasks);
    localStorage.setItem("crm_tasks", JSON.stringify(mockTasks));
  }, []);

  // Save tasks to localStorage whenever tasks state changes
  useEffect(() => {
    if (tasks.length > 0) {
      localStorage.setItem("crm_tasks", JSON.stringify(tasks));
    }
  }, [tasks]);

  const employees = [
    { id: "emp-1", name: "Nguyễn Văn Nam", department: "Kinh doanh" },
    { id: "emp-2", name: "Trần Thị Lan", department: "Marketing" },
    { id: "emp-3", name: "Lê Văn Phong", department: "Kỹ thuật" },
  ];

  const categories = [
    "Kinh doanh",
    "Marketing",
    "Kỹ thuật",
    "Quản lý",
    "Hỗ trợ",
    "Nghiên cứu",
  ];

  const getStatusColor = (status: Task["status"]) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "in-progress":
        return "bg-blue-100 text-blue-800 border-blue-300";
      case "completed":
        return "bg-green-100 text-green-800 border-green-300";
      case "overdue":
        return "bg-red-100 text-red-800 border-red-300";
      default:
        return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  const getStatusIcon = (status: Task["status"]) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />;
      case "in-progress":
        return <Target className="h-4 w-4" />;
      case "completed":
        return <CheckCircle className="h-4 w-4" />;
      case "overdue":
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusText = (status: Task["status"]) => {
    switch (status) {
      case "pending":
        return "Chờ xử lý";
      case "in-progress":
        return "Đang thực hiện";
      case "completed":
        return "Hoàn thành";
      case "overdue":
        return "Quá hạn";
      default:
        return "Không xác định";
    }
  };

  const getPriorityColor = (priority: Task["priority"]) => {
    switch (priority) {
      case "high":
        return "text-red-600";
      case "medium":
        return "text-yellow-600";
      case "low":
        return "text-green-600";
      default:
        return "text-gray-600";
    }
  };

  const filteredTasks = tasks.filter((task) => {
    const matchesSearch =
      task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.tags.some((tag) =>
        tag.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    const matchesStatus =
      filterStatus === "all" || task.status === filterStatus;
    const matchesPriority =
      filterPriority === "all" || task.priority === filterPriority;
    const matchesAssignee =
      filterAssignee === "all" || task.assignees.includes(filterAssignee);
    return matchesSearch && matchesStatus && matchesPriority && matchesAssignee;
  });

  const stats = {
    total: tasks.length,
    pending: tasks.filter((t) => t.status === "pending").length,
    inProgress: tasks.filter((t) => t.status === "in-progress").length,
    completed: tasks.filter((t) => t.status === "completed").length,
    overdue: tasks.filter((t) => t.status === "overdue").length,
    priority: tasks.filter((t) => t.isPriorityMarked).length,
  };

  const generateAISuggestions = async (title: string, description: string) => {
    const response = await AIService.generateTaskSuggestions(
      title,
      description,
    );

    if (response.success) {
      return response.text;
    } else {
      toast({
        title: "Lỗi AI",
        description: response.error || "Không thể tạo gợi ý",
        variant: "destructive",
      });
      return "";
    }
  };

  const changeTaskStatus = (taskId: string, newStatus: Task["status"]) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === taskId
          ? {
              ...task,
              status: newStatus,
              completedAt:
                newStatus === "completed"
                  ? new Date().toISOString()
                  : undefined,
            }
          : task,
      ),
    );

    toast({
      title: "Cập nhật trạng thái",
      description: `Đã chuyển trạng thái thành ${getStatusText(newStatus)}`,
    });
  };

  const CreateTaskForm = () => {
    const [formData, setFormData] = useState({
      title: "",
      description: "",
      priority: "medium" as Task["priority"],
      isPriorityMarked: false,
      deadline: "",
      assignees: [] as string[],
      relatedPersons: [] as string[],
      tags: "",
      category: "",
      estimatedHours: "",
    });
    const [aiSuggestion, setAiSuggestion] = useState("");
    const [loadingAI, setLoadingAI] = useState(false);

    const handleGenerateAI = async () => {
      if (!formData.title.trim()) {
        toast({
          title: "Cần tiêu đề",
          description: "Vui lòng nhập tiêu đề task trước khi tạo gợi ý AI",
          variant: "destructive",
        });
        return;
      }

      setLoadingAI(true);
      const suggestion = await generateAISuggestions(
        formData.title,
        formData.description,
      );
      setAiSuggestion(suggestion);
      setLoadingAI(false);
    };

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();

      // Validation
      if (!formData.title.trim()) {
        toast({
          title: "Lỗi validation",
          description: "Vui lòng nhập tiêu đề task",
          variant: "destructive",
        });
        return;
      }

      if (!formData.deadline) {
        toast({
          title: "Lỗi validation",
          description: "Vui lòng chọn deadline",
          variant: "destructive",
        });
        return;
      }

      if (formData.assignees.length === 0) {
        toast({
          title: "Lỗi validation",
          description: "Vui lòng chọn ít nhất một người thực hiện",
          variant: "destructive",
        });
        return;
      }

      try {
        const assigneeNames = formData.assignees.map(
          (id) => employees.find((emp) => emp.id === id)?.name || "",
        );
        const relatedPersonNames = formData.relatedPersons.map(
          (id) => employees.find((emp) => emp.id === id)?.name || "",
        );

        const newTask: Task = {
          id: `task-${Date.now()}`,
          title: formData.title,
          description: formData.description,
          priority: formData.priority,
          isPriorityMarked: formData.isPriorityMarked,
          deadline: formData.deadline,
          assignees: formData.assignees,
          assigneeNames,
          relatedPersons: formData.relatedPersons,
          relatedPersonNames,
          tags: formData.tags
            .split(",")
            .map((tag) => tag.trim())
            .filter(Boolean),
          category: formData.category,
          status: "pending",
          createdBy: user?.id || "",
          createdByName: user?.name || "",
          createdAt: new Date().toISOString().split("T")[0],
          estimatedHours: formData.estimatedHours
            ? parseInt(formData.estimatedHours)
            : undefined,
          attachments: [],
          comments: [],
        };

        console.log("Adding new task:", newTask);
        setTasks((prev) => {
          const updated = [...prev, newTask];
          console.log("Updated tasks list:", updated);
          return updated;
        });

        setIsCreateDialogOpen(false);

        // Reset form
        setFormData({
          title: "",
          description: "",
          priority: "medium",
          isPriorityMarked: false,
          deadline: "",
          assignees: [],
          relatedPersons: [],
          tags: "",
          category: "",
          estimatedHours: "",
        });
        setAiSuggestion("");

        toast({
          title: "Tạo task thành công",
          description: `Đã tạo task "${newTask.title}"`,
        });
      } catch (error) {
        console.error("Error creating task:", error);
        toast({
          title: "Lỗi tạo task",
          description: "Có lỗi xảy ra khi tạo task",
          variant: "destructive",
        });
      }
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="title">Tiêu đề task *</Label>
          <div className="flex gap-2">
            <Input
              id="title"
              value={formData.title}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, title: e.target.value }))
              }
              placeholder="Nhập tiêu đề task"
              required
              className="flex-1"
            />
            <Button
              type="button"
              variant="outline"
              onClick={handleGenerateAI}
              disabled={loadingAI}
            >
              {loadingAI ? (
                <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
              ) : (
                <Bot className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Mô tả chi tiết</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, description: e.target.value }))
            }
            placeholder="Mô tả chi tiết về task cần thực hiện..."
            rows={4}
          />
        </div>

        {aiSuggestion && (
          <div className="p-4 bg-blue-50 border-l-4 border-blue-400 rounded">
            <div className="flex items-center gap-2 font-medium text-blue-900 mb-2">
              <Bot className="h-4 w-4" />
              Gợi ý từ AI
            </div>
            <div className="text-blue-800 text-sm whitespace-pre-line">
              {aiSuggestion}
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="priority">Độ ưu tiên</Label>
            <Select
              value={formData.priority}
              onValueChange={(value) =>
                setFormData((prev) => ({
                  ...prev,
                  priority: value as Task["priority"],
                }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="high">Cao</SelectItem>
                <SelectItem value="medium">Trung bình</SelectItem>
                <SelectItem value="low">Thấp</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="category">Danh mục</Label>
            <Select
              value={formData.category}
              onValueChange={(value) =>
                setFormData((prev) => ({ ...prev, category: value }))
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Chọn danh mục" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="deadline">Deadline</Label>
            <Input
              id="deadline"
              type="date"
              value={formData.deadline}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, deadline: e.target.value }))
              }
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="estimatedHours">Ước tính thời gian (giờ)</Label>
            <Input
              id="estimatedHours"
              type="number"
              value={formData.estimatedHours}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  estimatedHours: e.target.value,
                }))
              }
              placeholder="VD: 8"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Người thực hiện *</Label>
          <div className="grid grid-cols-2 gap-2">
            {employees.map((emp) => (
              <label
                key={emp.id}
                className="flex items-center space-x-2 cursor-pointer"
              >
                <Checkbox
                  checked={formData.assignees.includes(emp.id)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFormData((prev) => ({
                        ...prev,
                        assignees: [...prev.assignees, emp.id],
                      }));
                    } else {
                      setFormData((prev) => ({
                        ...prev,
                        assignees: prev.assignees.filter((id) => id !== emp.id),
                      }));
                    }
                  }}
                />
                <span className="text-sm">
                  {emp.name} ({emp.department})
                </span>
              </label>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <Label>Người liên quan</Label>
          <div className="grid grid-cols-2 gap-2">
            {employees.map((emp) => (
              <label
                key={emp.id}
                className="flex items-center space-x-2 cursor-pointer"
              >
                <Checkbox
                  checked={formData.relatedPersons.includes(emp.id)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFormData((prev) => ({
                        ...prev,
                        relatedPersons: [...prev.relatedPersons, emp.id],
                      }));
                    } else {
                      setFormData((prev) => ({
                        ...prev,
                        relatedPersons: prev.relatedPersons.filter(
                          (id) => id !== emp.id,
                        ),
                      }));
                    }
                  }}
                />
                <span className="text-sm">
                  {emp.name} ({emp.department})
                </span>
              </label>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="tags">Tags (phân cách bằng dấu phẩy)</Label>
          <Input
            id="tags"
            value={formData.tags}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, tags: e.target.value }))
            }
            placeholder="VD: tư vấn, báo giá, khách hàng"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="isPriorityMarked"
            checked={formData.isPriorityMarked}
            onCheckedChange={(checked) =>
              setFormData((prev) => ({
                ...prev,
                isPriorityMarked: checked as boolean,
              }))
            }
          />
          <Label htmlFor="isPriorityMarked" className="flex items-center gap-2">
            <Flag className="h-4 w-4 text-red-500" />
            Đánh dấu ưu tiên hoàn thành
          </Label>
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => setIsCreateDialogOpen(false)}
          >
            Hủy
          </Button>
          <Button type="submit">Tạo task</Button>
        </div>
      </form>
    );
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tổng tasks</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <ClipboardList className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Chờ xử lý</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {stats.pending}
                </p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Đang làm</p>
                <p className="text-2xl font-bold text-blue-600">
                  {stats.inProgress}
                </p>
              </div>
              <Target className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Hoàn thành</p>
                <p className="text-2xl font-bold text-green-600">
                  {stats.completed}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Quá hạn</p>
                <p className="text-2xl font-bold text-red-600">
                  {stats.overdue}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Ưu tiên</p>
                <p className="text-2xl font-bold text-purple-600">
                  {stats.priority}
                </p>
              </div>
              <Flag className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Quản lý task</CardTitle>
              <CardDescription>
                {canCreateTasks
                  ? "Tạo và quản lý công việc cho team"
                  : "Xem danh sách task (chỉ Admin hoặc người được phân quyền mới tạo được task)"}
              </CardDescription>
            </div>
            {canCreateTasks ? (
              <Dialog
                open={isCreateDialogOpen}
                onOpenChange={setIsCreateDialogOpen}
              >
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Tạo task mới
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Tạo task mới</DialogTitle>
                    <DialogDescription>
                      Nhập thông tin chi tiết về task cần thực hiện
                    </DialogDescription>
                  </DialogHeader>
                  <CreateTaskForm />
                </DialogContent>
              </Dialog>
            ) : (
              <p className="text-sm text-gray-600">
                Chỉ Admin hoặc người được phân quyền mới có thể tạo task
              </p>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Tìm kiếm task..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả trạng thái</SelectItem>
                <SelectItem value="pending">Chờ xử lý</SelectItem>
                <SelectItem value="in-progress">Đang thực hiện</SelectItem>
                <SelectItem value="completed">Hoàn thành</SelectItem>
                <SelectItem value="overdue">Quá hạn</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-48">
                <Flag className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả độ ưu tiên</SelectItem>
                <SelectItem value="high">Cao</SelectItem>
                <SelectItem value="medium">Trung bình</SelectItem>
                <SelectItem value="low">Thấp</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterAssignee} onValueChange={setFilterAssignee}>
              <SelectTrigger className="w-48">
                <Users className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả nhân viên</SelectItem>
                {employees.map((emp) => (
                  <SelectItem key={emp.id} value={emp.id}>
                    {emp.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Tasks Grid */}
          <div className="space-y-4">
            {filteredTasks.map((task) => (
              <Card
                key={task.id}
                className={`border-l-4 ${task.isPriorityMarked ? "border-l-red-400" : "border-l-blue-400"} hover:shadow-md transition-shadow`}
              >
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-lg">{task.title}</h3>
                        {task.isPriorityMarked && (
                          <Flag className="h-4 w-4 text-red-500" />
                        )}
                      </div>
                      <p className="text-gray-600 mb-3">{task.description}</p>

                      <div className="flex flex-wrap gap-2 mb-3">
                        {task.tags.map((tag, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="text-xs"
                          >
                            <Tag className="h-3 w-3 mr-1" />
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex flex-col gap-2 ml-4">
                      <div
                        className={`px-3 py-1 rounded-full text-xs font-medium border flex items-center gap-1 ${getStatusColor(task.status)}`}
                      >
                        {getStatusIcon(task.status)}
                        {getStatusText(task.status)}
                      </div>
                      <Badge
                        variant={
                          task.priority === "high"
                            ? "destructive"
                            : task.priority === "medium"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {task.priority === "high"
                          ? "Cao"
                          : task.priority === "medium"
                            ? "TB"
                            : "Thấp"}
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mb-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <CalendarIcon2 className="h-4 w-4 text-gray-400" />
                        <span>Deadline: {task.deadline}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-gray-400" />
                        <span>Thực hiện: {task.assigneeNames.join(", ")}</span>
                      </div>
                      {task.relatedPersonNames.length > 0 && (
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-gray-400" />
                          <span>
                            Liên quan: {task.relatedPersonNames.join(", ")}
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-gray-400" />
                        <span>Danh mục: {task.category}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span>
                          Thời gian: {task.actualHours || 0}/
                          {task.estimatedHours || 0}h
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4 text-gray-400" />
                        <span>{task.comments.length} bình luận</span>
                      </div>
                    </div>
                  </div>

                  {task.comments.length > 0 && (
                    <div className="mb-4 p-3 bg-gray-50 rounded">
                      <p className="text-sm font-medium mb-2">
                        Bình luận gần nhất:
                      </p>
                      <div className="text-sm">
                        <span className="font-medium">
                          {task.comments[task.comments.length - 1].author}:
                        </span>
                        <span className="ml-2">
                          {task.comments[task.comments.length - 1].content}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2 flex-wrap">
                    <Select
                      value={task.status}
                      onValueChange={(value) =>
                        changeTaskStatus(task.id, value as Task["status"])
                      }
                    >
                      <SelectTrigger className="flex-1 min-w-[120px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Chờ xử lý</SelectItem>
                        <SelectItem value="in-progress">
                          Đang thực hiện
                        </SelectItem>
                        <SelectItem value="completed">Hoàn thành</SelectItem>
                        <SelectItem value="overdue">Quá hạn</SelectItem>
                      </SelectContent>
                    </Select>

                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-1" />
                      Chi tiết
                    </Button>

                    <Button variant="outline" size="sm">
                      <MessageSquare className="h-4 w-4 mr-1" />
                      Bình luận
                    </Button>

                    {canCreateTasks && (
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4 mr-1" />
                        Sửa
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredTasks.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              Không tìm thấy task nào phù hợp với tiêu chí tìm kiếm.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
