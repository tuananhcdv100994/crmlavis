import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building2, Users, Shield, Paintbrush2 } from "lucide-react";
import { Navigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

export default function Login() {
  const { user, login, isLoading } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginType, setLoginType] = useState<"admin" | "employee">("employee");
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (user) {
    return (
      <Navigate to={user.role === "admin" ? "/admin" : "/dashboard"} replace />
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast({
        title: "Lỗi đăng nhập",
        description: "Vui lòng nhập đầy đủ thông tin",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    const success = await login(username, password);

    if (success) {
      toast({
        title: "Đăng nhập thành công",
        description: "Chào mừng bạn đến với Lavis Holding CRM!",
      });

      // Navigate based on user type
      setTimeout(() => {
        if (username === "tuananhcdv") {
          navigate("/admin");
        } else {
          navigate("/dashboard");
        }
      }, 1000);
    } else {
      toast({
        title: "Đăng nhập thất bại",
        description: "Tên đăng nhập hoặc mật khẩu không đúng",
        variant: "destructive",
      });
    }
    setIsSubmitting(false);
  };

  const fillDemo = (type: "admin" | "employee") => {
    if (type === "admin") {
      setUsername("tuananhcdv");
      setPassword("tuananh1994");
    } else {
      setUsername("employee1");
      setPassword("password123");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo and Branding */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2Fa0178697b81a454483dcf391dc368cc9%2Fb3b4f2316e6b4f0cbaff901a9272dd93?format=webp&width=800"
              alt="Lavis Holding Logo"
              className="h-16 w-auto object-contain"
            />
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
            Lavis Holding
          </h1>
          <p className="text-gray-600 text-sm mt-1">CRM & Quản lý nhân viên</p>
        </div>

        <Card className="shadow-xl border-0 bg-white/70 backdrop-blur-sm">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center">
              Đăng nhập hệ thống
            </CardTitle>
            <CardDescription className="text-center">
              Chọn loại tài khoản để đăng nhập
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs
              value={loginType}
              onValueChange={(value) =>
                setLoginType(value as "admin" | "employee")
              }
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger
                  value="employee"
                  className="flex items-center gap-2"
                >
                  <Users className="h-4 w-4" />
                  Nhân viên
                </TabsTrigger>
                <TabsTrigger value="admin" className="flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  Quản trị
                </TabsTrigger>
              </TabsList>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Tên đăng nhập</Label>
                  <Input
                    id="username"
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Nhập tên đăng nhập"
                    className="h-11"
                    disabled={isSubmitting}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Mật khẩu</Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Nhập mật khẩu"
                    className="h-11"
                    disabled={isSubmitting}
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full h-11 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-medium shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02]"
                  disabled={isSubmitting || isLoading}
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Đang đăng nhập...
                    </div>
                  ) : (
                    "Đăng nhập"
                  )}
                </Button>
              </form>

              {/* Demo login buttons */}
              <div className="mt-6 space-y-3">
                <p className="text-xs text-center text-gray-500">
                  Tài khoản demo:
                </p>

                <TabsContent value="admin" className="mt-2">
                  <Button
                    variant="outline"
                    className="w-full h-10 text-sm hover:bg-blue-50 hover:border-blue-300 transition-colors"
                    onClick={() => fillDemo("admin")}
                    type="button"
                  >
                    <Shield className="h-4 w-4 mr-2" />
                    Điền thông tin Admin
                  </Button>
                </TabsContent>

                <TabsContent value="employee" className="mt-2">
                  <Button
                    variant="outline"
                    className="w-full h-10 text-sm hover:bg-blue-50 hover:border-blue-300 transition-colors"
                    onClick={() => fillDemo("employee")}
                    type="button"
                  >
                    <Users className="h-4 w-4 mr-2" />
                    Điền thông tin Nhân viên
                  </Button>
                </TabsContent>
              </div>
            </Tabs>
          </CardContent>
        </Card>

        {/* Features */}
        <div className="mt-8 grid grid-cols-3 gap-4 text-center">
          <div className="bg-white/50 backdrop-blur-sm p-3 rounded-lg">
            <Building2 className="h-6 w-6 mx-auto mb-2 text-blue-600" />
            <p className="text-xs text-gray-600">Quản lý CRM</p>
          </div>
          <div className="bg-white/50 backdrop-blur-sm p-3 rounded-lg">
            <Users className="h-6 w-6 mx-auto mb-2 text-cyan-600" />
            <p className="text-xs text-gray-600">Giao việc</p>
          </div>
          <div className="bg-white/50 backdrop-blur-sm p-3 rounded-lg">
            <Shield className="h-6 w-6 mx-auto mb-2 text-blue-600" />
            <p className="text-xs text-gray-600">Bảo mật</p>
          </div>
        </div>
      </div>
    </div>
  );
}
