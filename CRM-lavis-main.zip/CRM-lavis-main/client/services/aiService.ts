const GEMINI_API_KEY = "AIzaSyDzMOeUW-zDXSeejjr4y6NT23ZOj_BHd2Y";
const GEMINI_ENDPOINT =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";

export interface AIResponse {
  text: string;
  success: boolean;
  error?: string;
}

export class AIService {
  static async generateContent(prompt: string): Promise<AIResponse> {
    try {
      const response = await fetch(GEMINI_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-goog-api-key": GEMINI_API_KEY,
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: prompt,
                },
              ],
            },
          ],
        }),
      });

      const data = await response.json();

      if (response.ok && data.candidates && data.candidates[0]) {
        return {
          text: data.candidates[0].content.parts[0].text,
          success: true,
        };
      } else {
        return {
          text: "",
          success: false,
          error: data.error?.message || "Không thể tạo nội dung AI",
        };
      }
    } catch (error) {
      return {
        text: "",
        success: false,
        error: error instanceof Error ? error.message : "Lỗi kết nối AI",
      };
    }
  }

  static async generateTaskSuggestions(
    taskTitle: string,
    description: string,
  ): Promise<AIResponse> {
    const prompt = `Hãy phân tích công việc sau và đưa ra gợi ý:
Tiêu đề: ${taskTitle}
Mô tả: ${description}

Vui lòng cung cấp:
1. Ước tính thời gian hoàn thành
2. Độ ưu tiên được đề xuất (Cao/Trung bình/Thấp)
3. Gợi ý về kỹ năng cần thiết
4. Các bước thực hiện chính
5. Rủi ro tiềm ẩn

Trả lời bằng tiếng Việt, ngắn gọn và chuyên nghiệp.`;

    return this.generateContent(prompt);
  }

  static async generateCustomerInsights(
    customerName: string,
    industry: string,
    status: string,
  ): Promise<AIResponse> {
    const prompt = `Phân tích khách hàng sau:
Tên khách hàng: ${customerName}
Lĩnh vực: ${industry}
Trạng thái hiện tại: ${status}

Hãy đưa ra:
1. Chiến lược tiếp cận phù hợp
2. Sản phẩm/dịch vụ được đề xuất
3. Thời điểm tốt nhất để liên hệ
4. Câu hỏi nên hỏi trong cuộc gọi tiếp theo
5. Dự đoán tỷ lệ chuyển đổi

Trả lời bằng tiếng Việt, thiết thực và có thể áp dụng ngay.`;

    return this.generateContent(prompt);
  }

  static async generateReportSummary(data: any): Promise<AIResponse> {
    const prompt = `Hãy phân tích dữ liệu báo cáo sau và tạo tóm tắt thông minh:
${JSON.stringify(data, null, 2)}

Vui lòng cung cấp:
1. Điểm nổi bật chính
2. Xu hướng đáng chú ý
3. Khuyến nghị hành động
4. Cảnh báo về vấn đề tiềm ẩn
5. Dự báo cho giai đoạn tiếp theo

Trả lời bằng tiếng Việt, súc tích và có giá trị thực tiễn.`;

    return this.generateContent(prompt);
  }

  static async chatWithAI(
    message: string,
    context?: string,
  ): Promise<AIResponse> {
    const prompt = context
      ? `Ngữ cảnh: ${context}\n\nCâu hỏi: ${message}\n\nHãy trả lời một cách hữu ích và chuyên nghiệp bằng tiếng Việt.`
      : `${message}\n\nHãy trả lời một cách hữu ích và chuyên nghiệp bằng tiếng Việt.`;

    return this.generateContent(prompt);
  }
}
