import React, { createContext, useContext, useState, useEffect } from "react";

export interface User {
  id: string;
  username: string;
  email: string;
  role: "admin" | "employee";
  name: string;
  avatar?: string;
  department?: string;
  permissions: string[];
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    try {
      const savedUser = localStorage.getItem("crm_user");
      if (savedUser) {
        const parsedUser = JSON.parse(savedUser);
        console.log("Restored user from localStorage:", parsedUser);
        setUser(parsedUser);
      }
    } catch (error) {
      console.error("Error parsing saved user:", error);
      localStorage.removeItem("crm_user");
    }
    setIsLoading(false);
  }, []);

  const login = async (
    username: string,
    password: string,
  ): Promise<boolean> => {
    setIsLoading(true);

    // Admin login
    if (username === "tuananhcdv" && password === "tuananh1994") {
      const adminUser: User = {
        id: "admin-1",
        username: "tuananhcdv",
        email: "admin@lavisholding.com",
        role: "admin",
        name: "Tuấn Anh - Admin",
        avatar: "/placeholder.svg",
        department: "Quản trị",
        permissions: ["all"],
      };
      console.log("Admin login successful, setting user:", adminUser);
      setUser(adminUser);
      localStorage.setItem("crm_user", JSON.stringify(adminUser));
      setIsLoading(false);
      return true;
    }

    // Employee login (demo users)
    const employees = [
      {
        id: "emp-1",
        username: "employee1",
        password: "password123",
        email: "employee1@lavisbrothers.com",
        role: "employee" as const,
        name: "Nguyễn Văn Nam",
        department: "Kinh doanh",
        permissions: ["tasks", "customers", "chat"],
      },
      {
        id: "emp-2",
        username: "employee2",
        password: "password123",
        email: "employee2@lavisbrothers.com",
        role: "employee" as const,
        name: "Trần Thị Lan",
        department: "Marketing",
        permissions: ["tasks", "chat"],
      },
    ];

    const employee = employees.find(
      (emp) => emp.username === username && emp.password === password,
    );
    if (employee) {
      const { password: _, ...userWithoutPassword } = employee;
      setUser(userWithoutPassword);
      localStorage.setItem("crm_user", JSON.stringify(userWithoutPassword));
      setIsLoading(false);
      return true;
    }

    setIsLoading(false);
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("crm_user");
  };

  const value = {
    user,
    login,
    logout,
    isLoading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
