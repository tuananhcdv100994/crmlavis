# 🚀 Deployment Guide - Lavis CRM trên VPS

## Hướng dẫn deploy ứng dụng lên VPS

### 1. Chuẩn bị VPS

**Yêu cầu hệ thống:**

- Ubuntu 20.04+ hoặc CentOS 7+
- Node.js 18+
- npm 8+
- RAM: tối thiểu 1GB
- Disk: tối thiểu 2GB free space

**Cài đặt Node.js:**

```bash
# Ubuntu/Debian
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# CentOS/RHEL
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs
```

### 2. Upload code lên VPS

```bash
# Clone repository
git clone <your-repo-url> lavis-crm
cd lavis-crm

# Hoặc upload file zip và extract
unzip lavis-crm.zip
cd lavis-crm
```

### 3. Cài đặt dependencies

```bash
# Cài đặt tất cả dependencies
npm install

# Hoặc chỉ production dependencies
npm install --production
```

### 4. Cấu hình environment

```bash
# Copy environment template
cp .env.example .env

# Chỉnh sửa file .env
nano .env
```

**Cấu hình quan trọng:**

```env
NODE_ENV=production
PORT=8080
HOST=0.0.0.0
FRONTEND_URL=https://your-domain.com
```

### 5. Build ứng dụng

```bash
# Build cho production
npm run build:prod

# Kiểm tra build thành công
ls -la dist/
```

### 6. Chạy ứng dụng

**Option 1: Chạy trực tiếp**

```bash
npm run start:prod
```

**Option 2: Sử dụng startup script**

```bash
npm run serve
```

**Option 3: Sử dụng PM2 (khuyến nghị)**

```bash
# Cài đặt PM2
npm install -g pm2

# Tạo file ecosystem
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'lavis-crm',
    script: 'dist/server/node-build.mjs',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 8080
    }
  }]
};
EOF

# Start với PM2
pm2 start ecosystem.config.js
pm2 startup
pm2 save
```

### 7. Cấu hình Nginx (khuyến nghị)

```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    # SSL Configuration
    ssl_certificate /path/to/your/certificate.crt;
    ssl_certificate_key /path/to/your/private.key;

    # Proxy to Node.js app
    location / {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

### 8. Kiểm tra ứng dụng

```bash
# Health check
curl http://localhost:8080/health

# Test API
curl http://localhost:8080/api/ping

# Check processes
pm2 status
```

### 9. Troubleshooting

**Lỗi thường gặp:**

1. **Port đã được sử d��ng:**

```bash
# Kiểm tra port
sudo netstat -tlnp | grep :8080
# Kill process nếu cần
sudo kill -9 <PID>
```

2. **Permission denied:**

```bash
# Cấp quyền cho startup script
chmod +x scripts/start-production.sh
```

3. **Module not found:**

```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

4. **Build fail:**

```bash
# Clear cache và rebuild
npm run clean
npm run rebuild
```

**Log checking:**

```bash
# PM2 logs
pm2 logs lavis-crm

# System logs
journalctl -u nginx
tail -f /var/log/nginx/error.log
```

### 10. Monitoring

**Health check endpoint:**

- `GET /health` - Kiểm tra trạng thái server
- `GET /api/ping` - Kiểm tra API

**PM2 monitoring:**

```bash
pm2 monit
pm2 status
pm2 logs
```

### 11. Update ứng dụng

```bash
# Backup current version
cp -r lavis-crm lavis-crm-backup

# Pull latest code
git pull origin main

# Install dependencies
npm install

# Rebuild
npm run build:prod

# Restart with PM2
pm2 restart lavis-crm

# Verify
npm run health
```

### 12. Performance tuning

**Cấu hình Node.js:**

```bash
# Tăng memory limit
NODE_OPTIONS="--max-old-space-size=2048" npm run start:prod
```

**PM2 cluster mode:**

```javascript
// ecosystem.config.js
module.exports = {
  apps: [
    {
      name: "lavis-crm",
      script: "dist/server/node-build.mjs",
      instances: "max", // Sử dụng tất cả CPU cores
      exec_mode: "cluster",
      max_memory_restart: "1G",
    },
  ],
};
```
