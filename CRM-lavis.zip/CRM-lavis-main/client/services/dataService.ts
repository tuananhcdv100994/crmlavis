// Data Service for persistent storage using JSON files and localStorage fallback
export class DataService {
  private static baseUrl = '/src/shared/data/';

  // Load customers data from JSON file or localStorage
  static async loadCustomers() {
    try {
      // Try to load from JSON file first
      const response = await fetch('/shared/data/customers.json');
      if (response.ok) {
        const data = await response.json();
        // Sync with localStorage
        localStorage.setItem('crm_customers', JSON.stringify(data));
        return data;
      }
    } catch (error) {
      console.log('Could not load customers from file, using localStorage');
    }
    
    // Fallback to localStorage
    const saved = localStorage.getItem('crm_customers');
    if (saved) {
      return JSON.parse(saved);
    }
    
    return [];
  }

  // Load tasks data from JSON file or localStorage
  static async loadTasks() {
    try {
      // Try to load from JSON file first
      const response = await fetch('/shared/data/tasks.json');
      if (response.ok) {
        const data = await response.json();
        // Sync with localStorage
        localStorage.setItem('crm_tasks', JSON.stringify(data));
        return data;
      }
    } catch (error) {
      console.log('Could not load tasks from file, using localStorage');
    }
    
    // Fallback to localStorage
    const saved = localStorage.getItem('crm_tasks');
    if (saved) {
      return JSON.parse(saved);
    }
    
    return [];
  }

  // Load users data from JSON file or localStorage
  static async loadUsers() {
    try {
      // Try to load from JSON file first
      const response = await fetch('/shared/data/users.json');
      if (response.ok) {
        const data = await response.json();
        // Sync with localStorage
        localStorage.setItem('crm_users', JSON.stringify(data));
        return data;
      }
    } catch (error) {
      console.log('Could not load users from file, using localStorage');
    }
    
    // Fallback to localStorage
    const saved = localStorage.getItem('crm_users');
    if (saved) {
      return JSON.parse(saved);
    }
    
    return [];
  }

  // Save customers (to localStorage and trigger file download for persistence)
  static saveCustomers(customers: any[]) {
    localStorage.setItem('crm_customers', JSON.stringify(customers));
    this.triggerAutoSave('customers', customers);
  }

  // Save tasks (to localStorage and trigger file download for persistence)
  static saveTasks(tasks: any[]) {
    localStorage.setItem('crm_tasks', JSON.stringify(tasks));
    this.triggerAutoSave('tasks', tasks);
  }

  // Save users (to localStorage and trigger file download for persistence)
  static saveUsers(users: any[]) {
    localStorage.setItem('crm_users', JSON.stringify(users));
    this.triggerAutoSave('users', users);
  }

  // Trigger auto-save to keep file in sync (for development purposes)
  private static triggerAutoSave(type: string, data: any[]) {
    // This will create a downloadable backup that can be saved back to the source
    console.log(`Auto-saving ${type} data:`, data.length, 'records');
    
    // In a real production environment, this would send data to a server
    // For now, we'll just ensure localStorage is updated and provide download capability
    const backupData = {
      type,
      data,
      timestamp: new Date().toISOString(),
      version: '1.0.0'
    };
    
    localStorage.setItem(`crm_backup_${type}`, JSON.stringify(backupData));
  }

  // Get all data for comprehensive backup
  static async getAllData() {
    const customers = await this.loadCustomers();
    const tasks = await this.loadTasks();
    const users = await this.loadUsers();
    
    return {
      customers,
      tasks,
      users,
      exportDate: new Date().toISOString(),
      version: '1.0.0'
    };
  }

  // Restore all data from backup
  static restoreAllData(backupData: any) {
    if (backupData.customers) {
      this.saveCustomers(backupData.customers);
    }
    if (backupData.tasks) {
      this.saveTasks(backupData.tasks);
    }
    if (backupData.users) {
      this.saveUsers(backupData.users);
    }
    
    console.log('Data restored from backup:', backupData.exportDate);
    return true;
  }

  // Generate file content for manual save to source
  static generateSourceFiles() {
    const customers = localStorage.getItem('crm_customers');
    const tasks = localStorage.getItem('crm_tasks');
    const users = localStorage.getItem('crm_users');

    return {
      'customers.json': customers ? JSON.stringify(JSON.parse(customers), null, 2) : '[]',
      'tasks.json': tasks ? JSON.stringify(JSON.parse(tasks), null, 2) : '[]',
      'users.json': users ? JSON.stringify(JSON.parse(users), null, 2) : '[]'
    };
  }

  // Download source files for manual update
  static downloadSourceFiles() {
    const files = this.generateSourceFiles();
    
    Object.entries(files).forEach(([filename, content]) => {
      const blob = new Blob([content], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    });
    
    console.log('Source files downloaded. Update shared/data/ folder with these files for persistence.');
  }
}
