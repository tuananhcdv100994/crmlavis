// Clean Test Script - Test hệ thống sau khi xóa backup và attendance
export class CleanTest {
  private static log(message: string, type: 'info' | 'success' | 'error' = 'info') {
    const prefix = type === 'success' ? '✅' : type === 'error' ? '❌' : '🔍';
    console.log(`${prefix} [CLEAN-TEST] ${message}`);
  }

  // Test core CRUD functions
  static testCoreFunctions() {
    this.log('=== TESTING CORE FUNCTIONS AFTER CLEANUP ===');
    
    try {
      // Test Customer CRUD
      const customers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
      this.log(`Customer data: ${customers.length} records`, customers.length > 0 ? 'success' : 'info');

      // Test Task CRUD  
      const tasks = JSON.parse(localStorage.getItem('crm_tasks') || '[]');
      this.log(`Task data: ${tasks.length} records`, tasks.length > 0 ? 'success' : 'info');

      // Test User CRUD
      const users = JSON.parse(localStorage.getItem('crm_users') || '[]');
      this.log(`User data: ${users.length} records`, users.length > 0 ? 'success' : 'info');

      this.log('✅ All core data structures intact', 'success');
      return true;
    } catch (error) {
      this.log(`❌ Core function test failed: ${error}`, 'error');
      return false;
    }
  }

  // Test current user permissions (without backup and attendance)
  static testCleanPermissions() {
    this.log('=== TESTING CLEAN PERMISSIONS ===');
    
    const currentUser = localStorage.getItem('crm_user');
    if (!currentUser) {
      this.log('❌ No user logged in', 'error');
      return false;
    }

    const user = JSON.parse(currentUser);
    this.log(`Current user: ${user.name} (${user.role})`, 'info');
    
    // Test core permissions (without backup and attendance)
    const corePermissions = [
      'create_customers',
      'edit_customers', 
      'delete_customers',
      'create_tasks',
      'edit_tasks',
      'delete_tasks',
      'create_users',
      'edit_users',
      'delete_users',
      'view_reports',
      'export_data',
      'system_settings',
      'manage_permissions'
    ];

    let hasAllCore = true;
    corePermissions.forEach(permission => {
      const hasPermission = user.permissions?.includes(permission) || 
                           user.permissions?.includes('all') || 
                           user.role === 'admin';
      
      this.log(`${permission}: ${hasPermission ? 'HAS' : 'MISSING'}`, 
        hasPermission ? 'success' : 'error');
      
      if (!hasPermission) hasAllCore = false;
    });

    // Check that backup and attendance permissions are removed
    const removedPermissions = ['backup_system', 'attendance'];
    removedPermissions.forEach(permission => {
      const hasPermission = user.permissions?.includes(permission);
      this.log(`${permission} (should be removed): ${hasPermission ? 'STILL EXISTS' : 'REMOVED'}`, 
        hasPermission ? 'error' : 'success');
    });

    return hasAllCore;
  }

  // Test UI components (check for missing imports)
  static testUIIntegrity() {
    this.log('=== TESTING UI INTEGRITY ===');
    
    try {
      // Check if any components are trying to import removed files
      const potentialErrors = [];
      
      // Check for backup service usage
      if (typeof window !== 'undefined') {
        // These would cause errors if backup service is still referenced
        const hasBackupErrors = document.querySelectorAll('[data-testid="backup"]').length > 0;
        const hasAttendanceErrors = document.querySelectorAll('[data-testid="attendance"]').length > 0;
        
        if (hasBackupErrors) potentialErrors.push('Backup UI elements still present');
        if (hasAttendanceErrors) potentialErrors.push('Attendance UI elements still present');
      }

      if (potentialErrors.length === 0) {
        this.log('✅ No UI integrity issues found', 'success');
        return true;
      } else {
        potentialErrors.forEach(error => this.log(`❌ ${error}`, 'error'));
        return false;
      }
    } catch (error) {
      this.log(`❌ UI integrity test failed: ${error}`, 'error');
      return false;
    }
  }

  // Test essential functionality
  static testEssentialFunctionality() {
    this.log('=== TESTING ESSENTIAL FUNCTIONALITY ===');
    
    try {
      // Test create customer
      const customers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
      const testCustomer = {
        id: `clean-test-customer-${Date.now()}`,
        name: 'Clean Test Customer',
        industry: 'Test',
        contactPerson: 'Test Contact',
        email: 'clean@test.com',
        phone: '0123456789',
        address: 'Test Address',
        status: 'potential',
        assignedTo: 'admin-1',
        assignedToName: 'Nguyễn Văn Nam',
        estimatedValue: 1000000,
        notes: 'Clean test customer',
        createdAt: new Date().toISOString().split('T')[0],
        source: 'Test',
        priority: 'medium',
        projects: [],
        totalProjectValue: 0,
        activeProjects: 0,
        completedProjects: 0,
      };

      customers.push(testCustomer);
      localStorage.setItem('crm_customers', JSON.stringify(customers));
      this.log('✅ Customer creation test passed', 'success');

      // Test create task
      const tasks = JSON.parse(localStorage.getItem('crm_tasks') || '[]');
      const testTask = {
        id: `clean-test-task-${Date.now()}`,
        title: 'Clean Test Task',
        description: 'Test task after cleanup',
        status: 'pending',
        priority: 'medium',
        deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        assignees: ['admin-1'],
        assigneeNames: ['Nguyễn Văn Nam'],
        category: 'Test',
        createdBy: 'admin-1',
        createdByName: 'Nguyễn Văn Nam',
        createdAt: new Date().toISOString().split('T')[0],
        estimatedHours: 2,
        tags: ['clean-test'],
      };

      tasks.push(testTask);
      localStorage.setItem('crm_tasks', JSON.stringify(tasks));
      this.log('✅ Task creation test passed', 'success');

      // Clean up test data
      const cleanCustomers = customers.filter(c => !c.id.includes('clean-test-customer'));
      const cleanTasks = tasks.filter(t => !t.id.includes('clean-test-task'));
      localStorage.setItem('crm_customers', JSON.stringify(cleanCustomers));
      localStorage.setItem('crm_tasks', JSON.stringify(cleanTasks));
      
      this.log('✅ Test data cleaned up', 'success');
      return true;
    } catch (error) {
      this.log(`❌ Essential functionality test failed: ${error}`, 'error');
      return false;
    }
  }

  // Run all clean tests
  static runAllCleanTests() {
    this.log('🧹 STARTING CLEAN SYSTEM TEST AFTER REMOVING BACKUP & ATTENDANCE 🧹');
    
    const results = {
      coreFunctions: false,
      cleanPermissions: false,
      uiIntegrity: false,
      essentialFunctionality: false
    };

    // Test 1: Core Functions
    results.coreFunctions = this.testCoreFunctions();

    // Test 2: Clean Permissions
    results.cleanPermissions = this.testCleanPermissions();

    // Test 3: UI Integrity
    results.uiIntegrity = this.testUIIntegrity();

    // Test 4: Essential Functionality
    results.essentialFunctionality = this.testEssentialFunctionality();

    // Summary
    this.log('=== CLEAN TEST RESULTS ===');
    Object.entries(results).forEach(([test, passed]) => {
      this.log(`${test}: ${passed ? 'PASS' : 'FAIL'}`, passed ? 'success' : 'error');
    });

    const allPassed = Object.values(results).every(result => result);
    this.log(`Overall Result: ${allPassed ? 'ALL CLEAN TESTS PASSED' : 'SOME TESTS FAILED'}`, 
      allPassed ? 'success' : 'error');

    if (allPassed) {
      this.log('🎉 SYSTEM IS CLEAN AND FUNCTIONAL!', 'success');
      this.log('✅ Backup and Attendance removed successfully', 'success');
      this.log('✅ All core CRUD functions working', 'success');
      this.log('✅ No import errors or missing dependencies', 'success');
    } else {
      this.log('❌ Some issues found after cleanup', 'error');
    }

    this.log('🧹 CLEAN TEST COMPLETED!', 'success');
    return results;
  }

  // Check for any remaining references
  static checkRemainingReferences() {
    this.log('=== CHECKING FOR REMAINING REFERENCES ===');
    
    const currentUser = JSON.parse(localStorage.getItem('crm_user') || '{}');
    
    // Check user permissions for removed features
    const badPermissions = (currentUser.permissions || []).filter((perm: string) => 
      perm === 'backup_system' || perm === 'attendance'
    );

    if (badPermissions.length > 0) {
      this.log(`❌ Found bad permissions: ${badPermissions.join(', ')}`, 'error');
      
      // Clean them up
      const cleanPermissions = currentUser.permissions.filter((perm: string) => 
        perm !== 'backup_system' && perm !== 'attendance'
      );
      
      currentUser.permissions = cleanPermissions;
      localStorage.setItem('crm_user', JSON.stringify(currentUser));
      this.log('✅ Cleaned up bad permissions', 'success');
    } else {
      this.log('✅ No bad permissions found', 'success');
    }

    // Check for any backup data
    const backupKeys = Object.keys(localStorage).filter(key => 
      key.includes('backup') || key.includes('attendance')
    );

    if (backupKeys.length > 0) {
      this.log(`❌ Found backup/attendance data: ${backupKeys.join(', ')}`, 'error');
      
      // Clean them up
      backupKeys.forEach(key => localStorage.removeItem(key));
      this.log('✅ Cleaned up backup/attendance data', 'success');
    } else {
      this.log('✅ No backup/attendance data found', 'success');
    }

    return badPermissions.length === 0 && backupKeys.length === 0;
  }
}

// Make available globally
if (typeof window !== 'undefined') {
  (window as any).CleanTest = CleanTest;
}

export default CleanTest;
