// Simple Test Script để test tất cả chức năng CRUD mới
export class SimpleTest {
  private static log(message: string, type: 'info' | 'success' | 'error' = 'info') {
    const prefix = type === 'success' ? '✅' : type === 'error' ? '❌' : '🔍';
    console.log(`${prefix} [SIMPLE-TEST] ${message}`);
  }

  // Test Customer CRUD
  static testCustomerCRUD() {
    this.log('=== TESTING CUSTOMER CRUD ===');
    
    try {
      // Test Create
      const customers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
      const testCustomer = {
        id: `test-customer-${Date.now()}`,
        name: `Test Company ${new Date().toLocaleTimeString()}`,
        industry: "Technology",
        contactPerson: "Test Contact",
        email: `test${Date.now()}@test.com`,
        phone: "0987654321",
        address: "Test Address",
        status: "potential",
        assignedTo: "admin-1",
        assignedToName: "Nguyễn Văn Nam",
        estimatedValue: 1000000,
        notes: "Test customer",
        createdAt: new Date().toISOString().split('T')[0],
        source: "Test",
        priority: "medium",
        projects: [],
        totalProjectValue: 0,
        activeProjects: 0,
        completedProjects: 0,
      };

      // CREATE
      const updatedCustomers = [...customers, testCustomer];
      localStorage.setItem('crm_customers', JSON.stringify(updatedCustomers));
      this.log(`✅ CREATE Customer: ${testCustomer.name}`, 'success');

      // READ
      const loadedCustomers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
      const foundCustomer = loadedCustomers.find((c: any) => c.id === testCustomer.id);
      if (foundCustomer) {
        this.log(`✅ READ Customer: Found ${foundCustomer.name}`, 'success');
      } else {
        this.log(`❌ READ Customer: Not found`, 'error');
        return false;
      }

      // UPDATE
      foundCustomer.name = `${foundCustomer.name} - Updated`;
      const updateCustomers = loadedCustomers.map((c: any) => 
        c.id === testCustomer.id ? foundCustomer : c
      );
      localStorage.setItem('crm_customers', JSON.stringify(updateCustomers));
      this.log(`✅ UPDATE Customer: ${foundCustomer.name}`, 'success');

      // DELETE
      const deleteCustomers = updateCustomers.filter((c: any) => c.id !== testCustomer.id);
      localStorage.setItem('crm_customers', JSON.stringify(deleteCustomers));
      this.log(`✅ DELETE Customer: Removed`, 'success');

      return true;
    } catch (error) {
      this.log(`❌ Customer CRUD failed: ${error}`, 'error');
      return false;
    }
  }

  // Test Task CRUD
  static testTaskCRUD() {
    this.log('=== TESTING TASK CRUD ===');
    
    try {
      // Test Create
      const tasks = JSON.parse(localStorage.getItem('crm_tasks') || '[]');
      const testTask = {
        id: `test-task-${Date.now()}`,
        title: `Test Task ${new Date().toLocaleTimeString()}`,
        description: "Test task description",
        status: "pending",
        priority: "medium",
        deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        assignees: ["admin-1"],
        assigneeNames: ["Nguyễn Văn Nam"],
        category: "Testing",
        createdBy: "admin-1",
        createdByName: "Nguyễn Văn Nam",
        createdAt: new Date().toISOString().split('T')[0],
        estimatedHours: 2,
        tags: ["test"],
      };

      // CREATE
      const updatedTasks = [...tasks, testTask];
      localStorage.setItem('crm_tasks', JSON.stringify(updatedTasks));
      this.log(`✅ CREATE Task: ${testTask.title}`, 'success');

      // READ
      const loadedTasks = JSON.parse(localStorage.getItem('crm_tasks') || '[]');
      const foundTask = loadedTasks.find((t: any) => t.id === testTask.id);
      if (foundTask) {
        this.log(`✅ READ Task: Found ${foundTask.title}`, 'success');
      } else {
        this.log(`❌ READ Task: Not found`, 'error');
        return false;
      }

      // UPDATE
      foundTask.title = `${foundTask.title} - Updated`;
      foundTask.status = "completed";
      const updateTasks = loadedTasks.map((t: any) => 
        t.id === testTask.id ? foundTask : t
      );
      localStorage.setItem('crm_tasks', JSON.stringify(updateTasks));
      this.log(`✅ UPDATE Task: ${foundTask.title} (${foundTask.status})`, 'success');

      // DELETE
      const deleteTasks = updateTasks.filter((t: any) => t.id !== testTask.id);
      localStorage.setItem('crm_tasks', JSON.stringify(deleteTasks));
      this.log(`✅ DELETE Task: Removed`, 'success');

      return true;
    } catch (error) {
      this.log(`❌ Task CRUD failed: ${error}`, 'error');
      return false;
    }
  }

  // Test User CRUD
  static testUserCRUD() {
    this.log('=== TESTING USER CRUD ===');
    
    try {
      // Test Create
      const users = JSON.parse(localStorage.getItem('crm_users') || '[]');
      const testUser = {
        id: `test-user-${Date.now()}`,
        username: `testuser${Date.now()}`,
        email: `test${Date.now()}@test.com`,
        name: `Test User ${new Date().toLocaleTimeString()}`,
        role: "employee",
        department: "Test Department",
        position: "Test Position",
        phone: "0123456789",
        status: "active",
        permissions: ["view_customers", "view_tasks"],
        createdAt: new Date().toISOString().split('T')[0],
      };

      // CREATE
      const updatedUsers = [...users, testUser];
      localStorage.setItem('crm_users', JSON.stringify(updatedUsers));
      this.log(`✅ CREATE User: ${testUser.name}`, 'success');

      // READ
      const loadedUsers = JSON.parse(localStorage.getItem('crm_users') || '[]');
      const foundUser = loadedUsers.find((u: any) => u.id === testUser.id);
      if (foundUser) {
        this.log(`✅ READ User: Found ${foundUser.name}`, 'success');
      } else {
        this.log(`❌ READ User: Not found`, 'error');
        return false;
      }

      // UPDATE
      foundUser.name = `${foundUser.name} - Updated`;
      foundUser.status = "inactive";
      const updateUsers = loadedUsers.map((u: any) => 
        u.id === testUser.id ? foundUser : u
      );
      localStorage.setItem('crm_users', JSON.stringify(updateUsers));
      this.log(`✅ UPDATE User: ${foundUser.name} (${foundUser.status})`, 'success');

      // DELETE
      const deleteUsers = updateUsers.filter((u: any) => u.id !== testUser.id);
      localStorage.setItem('crm_users', JSON.stringify(deleteUsers));
      this.log(`✅ DELETE User: Removed`, 'success');

      return true;
    } catch (error) {
      this.log(`❌ User CRUD failed: ${error}`, 'error');
      return false;
    }
  }

  // Test current user permissions
  static testCurrentUserPermissions() {
    this.log('=== TESTING CURRENT USER PERMISSIONS ===');
    
    const currentUser = localStorage.getItem('crm_user');
    if (!currentUser) {
      this.log('❌ No user logged in', 'error');
      return false;
    }

    const user = JSON.parse(currentUser);
    this.log(`Current user: ${user.name} (${user.role})`, 'info');
    this.log(`Email: ${user.email}`, 'info');
    this.log(`Total permissions: ${user.permissions?.length || 0}`, 'info');

    // Test key permissions
    const keyPermissions = [
      'create_customers',
      'edit_customers', 
      'delete_customers',
      'create_tasks',
      'edit_tasks',
      'delete_tasks',
      'create_users',
      'edit_users',
      'delete_users'
    ];

    let hasAllPermissions = true;
    keyPermissions.forEach(permission => {
      const hasPermission = user.permissions?.includes(permission) || 
                           user.permissions?.includes('all') || 
                           user.role === 'admin';
      
      this.log(`${permission}: ${hasPermission ? 'HAS' : 'MISSING'}`, 
        hasPermission ? 'success' : 'error');
      
      if (!hasPermission) hasAllPermissions = false;
    });

    if (hasAllPermissions) {
      this.log('✅ All key permissions available', 'success');
    } else {
      this.log('❌ Missing some key permissions', 'error');
    }

    return hasAllPermissions;
  }

  // Test data persistence
  static testDataPersistence() {
    this.log('=== TESTING DATA PERSISTENCE ===');
    
    const customers = localStorage.getItem('crm_customers');
    const tasks = localStorage.getItem('crm_tasks');
    const users = localStorage.getItem('crm_users');

    this.log(`Customers data: ${customers ? 'EXISTS' : 'MISSING'}`, customers ? 'success' : 'error');
    this.log(`Tasks data: ${tasks ? 'EXISTS' : 'MISSING'}`, tasks ? 'success' : 'error');
    this.log(`Users data: ${users ? 'EXISTS' : 'MISSING'}`, users ? 'success' : 'error');

    if (customers && tasks && users) {
      const customersData = JSON.parse(customers);
      const tasksData = JSON.parse(tasks);
      const usersData = JSON.parse(users);

      this.log(`Customers count: ${customersData.length}`, 'info');
      this.log(`Tasks count: ${tasksData.length}`, 'info');
      this.log(`Users count: ${usersData.length}`, 'info');

      return true;
    }

    return false;
  }

  // Run all tests
  static runAllTests() {
    this.log('🚀 STARTING SIMPLE CRUD TEST SUITE 🚀');
    
    const results = {
      currentUser: false,
      dataPersistence: false,
      customerCRUD: false,
      taskCRUD: false,
      userCRUD: false
    };

    // Test 1: Current user permissions
    results.currentUser = this.testCurrentUserPermissions();

    // Test 2: Data persistence
    results.dataPersistence = this.testDataPersistence();

    // Test 3: Customer CRUD
    results.customerCRUD = this.testCustomerCRUD();

    // Test 4: Task CRUD
    results.taskCRUD = this.testTaskCRUD();

    // Test 5: User CRUD
    results.userCRUD = this.testUserCRUD();

    // Summary
    this.log('=== TEST RESULTS SUMMARY ===');
    Object.entries(results).forEach(([test, passed]) => {
      this.log(`${test}: ${passed ? 'PASS' : 'FAIL'}`, passed ? 'success' : 'error');
    });

    const allPassed = Object.values(results).every(result => result);
    this.log(`Overall Result: ${allPassed ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`, 
      allPassed ? 'success' : 'error');

    this.log('🎉 SIMPLE TEST SUITE COMPLETED!', 'success');

    if (allPassed) {
      this.log('✅ ALL CRUD FUNCTIONS ARE WORKING CORRECTLY!', 'success');
      this.log('✅ BUTTONS SHOULD BE CLICKABLE NOW!', 'success');
      this.log('✅ ADMIN NGUYỄN VĂN NAM HAS FULL ACCESS!', 'success');
    } else {
      this.log('❌ Some functionality may not work as expected', 'error');
    }

    return results;
  }

  // Quick demo for user
  static runQuickDemo() {
    this.log('🎭 RUNNING QUICK DEMO - CREATING SAMPLE DATA 🎭');
    
    try {
      // Create demo customer
      const customers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
      const demoCustomer = {
        id: `demo-customer-${Date.now()}`,
        name: `Demo Company ${new Date().toLocaleTimeString()}`,
        industry: "Demo Industry",
        contactPerson: "Demo Contact",
        email: `demo${Date.now()}@demo.com`,
        phone: "0999999999",
        address: "Demo Address",
        status: "active",
        assignedTo: "admin-1",
        assignedToName: "Nguyễn Văn Nam",
        estimatedValue: 5000000,
        notes: "Demo customer created by admin",
        createdAt: new Date().toISOString().split('T')[0],
        source: "Demo",
        priority: "high",
        projects: [],
        totalProjectValue: 0,
        activeProjects: 0,
        completedProjects: 0,
      };
      
      customers.push(demoCustomer);
      localStorage.setItem('crm_customers', JSON.stringify(customers));
      this.log(`✅ Created demo customer: ${demoCustomer.name}`, 'success');

      // Create demo task
      const tasks = JSON.parse(localStorage.getItem('crm_tasks') || '[]');
      const demoTask = {
        id: `demo-task-${Date.now()}`,
        title: `Demo Task ${new Date().toLocaleTimeString()}`,
        description: "Demo task created by admin to test functionality",
        status: "in-progress",
        priority: "high",
        deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        assignees: ["admin-1"],
        assigneeNames: ["Nguyễn Văn Nam"],
        category: "Demo",
        createdBy: "admin-1",
        createdByName: "Nguyễn Văn Nam",
        createdAt: new Date().toISOString().split('T')[0],
        estimatedHours: 8,
        tags: ["demo", "admin-test"],
      };
      
      tasks.push(demoTask);
      localStorage.setItem('crm_tasks', JSON.stringify(tasks));
      this.log(`✅ Created demo task: ${demoTask.title}`, 'success');

      // Create demo user
      const users = JSON.parse(localStorage.getItem('crm_users') || '[]');
      const demoUser = {
        id: `demo-user-${Date.now()}`,
        username: `demouser${Date.now()}`,
        email: `demo${Date.now()}@company.com`,
        name: `Demo User ${new Date().toLocaleTimeString()}`,
        role: "employee",
        department: "Demo Department",
        position: "Demo Position",
        phone: "0888888888",
        status: "active",
        permissions: ["view_customers", "view_tasks", "create_tasks"],
        createdAt: new Date().toISOString().split('T')[0],
      };
      
      users.push(demoUser);
      localStorage.setItem('crm_users', JSON.stringify(users));
      this.log(`✅ Created demo user: ${demoUser.name}`, 'success');

      this.log('🎉 DEMO DATA CREATED SUCCESSFULLY!', 'success');
      this.log('🔄 Please refresh the page to see the new data!', 'info');

      return true;
    } catch (error) {
      this.log(`❌ Demo creation failed: ${error}`, 'error');
      return false;
    }
  }
}

// Make available globally
if (typeof window !== 'undefined') {
  (window as any).SimpleTest = SimpleTest;
}

export default SimpleTest;
