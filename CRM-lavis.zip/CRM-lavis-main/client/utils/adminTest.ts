// Test script để kiểm tra chức năng admin mới (Nguyễn Văn Nam)
export class AdminTest {
  private static log(message: string, type: 'info' | 'success' | 'error' = 'info') {
    const prefix = type === 'success' ? '✅' : type === 'error' ? '❌' : '🔍';
    console.log(`${prefix} [ADMIN-TEST] ${message}`);
  }

  // Test login với admin mới
  static testAdminLogin() {
    this.log('=== TESTING NEW ADMIN LOGIN ===');
    
    const savedUser = localStorage.getItem('crm_user');
    if (!savedUser) {
      this.log('No user logged in', 'error');
      return false;
    }

    const user = JSON.parse(savedUser);
    this.log(`Current user: ${user.name}`, 'info');
    this.log(`Role: ${user.role}`, 'info');
    this.log(`Email: ${user.email}`, 'info');
    this.log(`Department: ${user.department}`, 'info');
    this.log(`Total permissions: ${user.permissions?.length || 0}`, 'info');

    // Kiểm tra admin cụ thể
    if (user.name === 'Nguyễn Văn Nam' && user.role === 'admin') {
      this.log('✅ Admin Nguyễn Văn Nam logged in successfully!', 'success');
      return true;
    } else {
      this.log('❌ Admin Nguyễn Văn Nam not found or not admin role', 'error');
      return false;
    }
  }

  // Test customer management permissions
  static testCustomerPermissions() {
    this.log('=== TESTING CUSTOMER MANAGEMENT PERMISSIONS ===');
    
    const user = JSON.parse(localStorage.getItem('crm_user') || '{}');
    
    const requiredPermissions = [
      'view_customers',
      'create_customers', 
      'edit_customers',
      'delete_customers'
    ];

    let allPermissionsPresent = true;

    requiredPermissions.forEach(permission => {
      const hasPermission = user.permissions?.includes(permission) || 
                           user.permissions?.includes('all') || 
                           user.role === 'admin';
      
      this.log(`Permission '${permission}': ${hasPermission ? 'HAS' : 'MISSING'}`, 
        hasPermission ? 'success' : 'error');
      
      if (!hasPermission) allPermissionsPresent = false;
    });

    return allPermissionsPresent;
  }

  // Test tạo khách hàng
  static testCreateCustomer() {
    this.log('=== TESTING CUSTOMER CREATION ===');
    
    try {
      const customers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
      
      const testCustomer = {
        id: `admin-test-customer-${Date.now()}`,
        name: `Test Company by Admin - ${new Date().toLocaleTimeString()}`,
        industry: "Technology",
        contactPerson: "Admin Test Contact",
        email: `admin-test-${Date.now()}@company.com`,
        phone: "0987654321",
        address: "Admin Test Address",
        status: "potential",
        assignedTo: "admin-1",
        assignedToName: "Nguyễn Văn Nam",
        estimatedValue: 1000000,
        notes: "Test customer created by admin Nguyễn Văn Nam",
        createdAt: new Date().toISOString().split('T')[0],
        source: "Admin Test",
        priority: "high",
        projects: [],
        totalProjectValue: 0,
        activeProjects: 0,
        completedProjects: 0,
      };

      const updatedCustomers = [...customers, testCustomer];
      localStorage.setItem('crm_customers', JSON.stringify(updatedCustomers));
      
      this.log(`✅ Successfully created customer: ${testCustomer.name}`, 'success');
      this.log(`Total customers now: ${updatedCustomers.length}`, 'info');
      
      return testCustomer;
    } catch (error) {
      this.log(`❌ Failed to create customer: ${error}`, 'error');
      return null;
    }
  }

  // Test xóa khách hàng
  static testDeleteCustomer() {
    this.log('=== TESTING CUSTOMER DELETION ===');
    
    try {
      const customers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
      
      // Tìm customer test để xóa
      const testCustomer = customers.find((c: any) => c.name.includes('Test Company by Admin'));
      
      if (!testCustomer) {
        this.log('No test customer found to delete', 'error');
        return false;
      }

      const updatedCustomers = customers.filter((c: any) => c.id !== testCustomer.id);
      localStorage.setItem('crm_customers', JSON.stringify(updatedCustomers));
      
      this.log(`✅ Successfully deleted customer: ${testCustomer.name}`, 'success');
      this.log(`Total customers now: ${updatedCustomers.length}`, 'info');
      
      return true;
    } catch (error) {
      this.log(`❌ Failed to delete customer: ${error}`, 'error');
      return false;
    }
  }

  // Test tạo task
  static testCreateTask() {
    this.log('=== TESTING TASK CREATION ===');
    
    try {
      const tasks = JSON.parse(localStorage.getItem('crm_tasks') || '[]');
      
      const testTask = {
        id: `admin-test-task-${Date.now()}`,
        title: `Admin Test Task - ${new Date().toLocaleTimeString()}`,
        description: "Test task created by admin Nguyễn Văn Nam",
        status: "pending",
        priority: "high",
        isPriorityMarked: true,
        deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        assignees: ["admin-1"],
        assigneeNames: ["Nguyễn Văn Nam"],
        relatedPersons: [],
        relatedPersonNames: [],
        tags: ["admin-test", "functionality-test"],
        category: "Admin Testing",
        createdBy: "admin-1",
        createdByName: "Nguyễn Văn Nam",
        createdAt: new Date().toISOString().split('T')[0],
        estimatedHours: 2,
        attachments: [],
        canSelfApprove: true,
      };

      const updatedTasks = [...tasks, testTask];
      localStorage.setItem('crm_tasks', JSON.stringify(updatedTasks));
      
      this.log(`✅ Successfully created task: ${testTask.title}`, 'success');
      this.log(`Total tasks now: ${updatedTasks.length}`, 'info');
      
      return testTask;
    } catch (error) {
      this.log(`❌ Failed to create task: ${error}`, 'error');
      return null;
    }
  }

  // Test tạo user
  static testCreateUser() {
    this.log('=== TESTING USER CREATION ===');
    
    try {
      const users = JSON.parse(localStorage.getItem('crm_users') || '[]');
      
      const testUser = {
        id: `admin-test-user-${Date.now()}`,
        username: `admintest${Date.now()}`,
        email: `admin-test-${Date.now()}@lavisholding.com`,
        name: `Admin Test User ${new Date().toLocaleTimeString()}`,
        role: "employee",
        department: "Test Department",
        position: "Test Employee",
        phone: "0123456789",
        status: "active",
        permissions: ["view_customers", "view_tasks", "create_tasks"],
        createdAt: new Date().toISOString().split('T')[0],
      };

      const updatedUsers = [...users, testUser];
      localStorage.setItem('crm_users', JSON.stringify(updatedUsers));
      
      this.log(`✅ Successfully created user: ${testUser.name}`, 'success');
      this.log(`Total users now: ${updatedUsers.length}`, 'info');
      
      return testUser;
    } catch (error) {
      this.log(`❌ Failed to create user: ${error}`, 'error');
      return null;
    }
  }

  // Chạy tất cả test
  static async runFullAdminTest() {
    this.log('🚀 STARTING FULL ADMIN FUNCTIONALITY TEST 🚀');
    
    const results = {
      login: false,
      permissions: false,
      createCustomer: false,
      deleteCustomer: false,
      createTask: false,
      createUser: false
    };

    // Test 1: Login
    results.login = this.testAdminLogin();
    
    // Test 2: Permissions
    results.permissions = this.testCustomerPermissions();
    
    // Test 3: Create Customer
    const customer = this.testCreateCustomer();
    results.createCustomer = !!customer;
    
    // Test 4: Delete Customer
    results.deleteCustomer = this.testDeleteCustomer();
    
    // Test 5: Create Task
    const task = this.testCreateTask();
    results.createTask = !!task;
    
    // Test 6: Create User
    const user = this.testCreateUser();
    results.createUser = !!user;

    // Summary
    this.log('=== TEST RESULTS SUMMARY ===');
    Object.entries(results).forEach(([test, passed]) => {
      this.log(`${test}: ${passed ? 'PASS' : 'FAIL'}`, passed ? 'success' : 'error');
    });

    const allPassed = Object.values(results).every(result => result);
    this.log(`Overall: ${allPassed ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`, 
      allPassed ? 'success' : 'error');

    this.log('🎉 ADMIN TEST COMPLETED!', 'success');
    
    return results;
  }

  // Cleanup test data
  static cleanupTestData() {
    this.log('Cleaning up test data...', 'info');
    
    // Clean customers
    const customers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
    const cleanCustomers = customers.filter((c: any) => !c.id.includes('admin-test-customer'));
    localStorage.setItem('crm_customers', JSON.stringify(cleanCustomers));
    
    // Clean tasks  
    const tasks = JSON.parse(localStorage.getItem('crm_tasks') || '[]');
    const cleanTasks = tasks.filter((t: any) => !t.id.includes('admin-test-task'));
    localStorage.setItem('crm_tasks', JSON.stringify(cleanTasks));
    
    // Clean users
    const users = JSON.parse(localStorage.getItem('crm_users') || '[]');
    const cleanUsers = users.filter((u: any) => !u.id.includes('admin-test-user'));
    localStorage.setItem('crm_users', JSON.stringify(cleanUsers));
    
    this.log('✅ Test data cleaned up', 'success');
  }
}

// Make available globally
if (typeof window !== 'undefined') {
  (window as any).AdminTest = AdminTest;
}

export default AdminTest;
