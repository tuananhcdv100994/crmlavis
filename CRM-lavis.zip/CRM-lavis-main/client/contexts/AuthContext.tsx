import React, { createContext, useContext, useState, useEffect } from "react";

export interface User {
  id: string;
  username: string;
  email: string;
  role: "admin" | "employee";
  name: string;
  avatar?: string;
  department?: string;
  permissions: string[];
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    try {
      const savedUser = localStorage.getItem("crm_user");
      console.log("=== AUTH CONTEXT INIT ===");
      console.log("Saved user from localStorage:", savedUser);

      if (savedUser) {
        const parsedUser = JSON.parse(savedUser);
        console.log("Parsed user:", parsedUser);
        console.log("User role:", parsedUser.role);
        console.log("User permissions:", parsedUser.permissions);
        setUser(parsedUser);
      } else {
        console.log("No saved user found in localStorage");
      }
    } catch (error) {
      console.error("Error parsing saved user:", error);
      localStorage.removeItem("crm_user");
    }
    setIsLoading(false);
    console.log("Auth context loading completed");
  }, []);

  const login = async (
    username: string,
    password: string,
  ): Promise<boolean> => {
    setIsLoading(true);

    // Admin login - Nguyễn Văn Nam với quyền admin
    if (username === "tuananhcdv" && password === "tuananh1994") {
      const adminUser: User = {
        id: "admin-1",
        username: "tuananhcdv",
        email: "nam.nguyen@lavisholding.com",
        role: "admin",
        name: "Nguyễn Văn Nam",
        avatar: "/placeholder.svg",
        department: "Quản trị",
        permissions: [
          "view_customers", "create_customers", "edit_customers", "delete_customers",
          "view_tasks", "create_tasks", "edit_tasks", "delete_tasks",
          "view_users", "create_users", "edit_users", "delete_users",
          "view_reports", "export_data", "system_settings",
          "view_departments", "create_departments", "edit_departments", "delete_departments",
          "manage_permissions", "manage_chat", "create_groups",
          "all" // Keep 'all' for backward compatibility
        ],
      };
      console.log("Admin login successful, setting user:", adminUser);
      setUser(adminUser);
      localStorage.setItem("crm_user", JSON.stringify(adminUser));
      setIsLoading(false);
      return true;
    }

    // Employee login (demo users)
    const employees = [
      {
        id: "emp-2",
        username: "employee2",
        password: "password123",
        email: "employee2@lavisbrothers.com",
        role: "employee" as const,
        name: "Trần Thị Lan",
        department: "Marketing",
        permissions: ["tasks", "chat"],
      },
    ];

    const employee = employees.find(
      (emp) => emp.username === username && emp.password === password,
    );
    if (employee) {
      const { password: _, ...userWithoutPassword } = employee;
      setUser(userWithoutPassword);
      localStorage.setItem("crm_user", JSON.stringify(userWithoutPassword));
      setIsLoading(false);
      return true;
    }

    setIsLoading(false);
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("crm_user");
  };

  const value = {
    user,
    login,
    logout,
    isLoading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
