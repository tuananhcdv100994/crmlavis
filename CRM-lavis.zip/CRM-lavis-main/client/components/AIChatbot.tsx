import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import {
  Bot,
  Send,
  User,
  MessageSquare,
  Minimize2,
  Maximize2,
  X,
  Lightbulb,
  BarChart3,
  Users,
  Calendar,
} from "lucide-react";
import { AIService } from "@/services/aiService";
import { useAuth } from "@/contexts/AuthContext";

interface ChatMessage {
  id: string;
  type: "user" | "ai";
  content: string;
  timestamp: string;
  context?: string;
}

interface AIChatbotProps {
  isOpen: boolean;
  onToggle: () => void;
  context?: "customer" | "task" | "general";
  contextData?: any;
}

export default function AIChatbot({
  isOpen,
  onToggle,
  context = "general",
  contextData,
}: AIChatbotProps) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      // Welcome message
      const welcomeMessage: ChatMessage = {
        id: "welcome",
        type: "ai",
        content: `Xin chào ${user?.name}! 👋 Tôi là AI Assistant của Lavis Holding. Tôi có thể giúp bạn:\n\n• Phân tích và tư vấn về khách hàng\n• Gợi ý cho việc tạo task và quản lý công việc\n• Tạo báo cáo và thống kê\n• Trả lời các câu hỏi về CRM\n\nBạn cần hỗ trợ gì hôm nay?`,
        timestamp: new Date().toLocaleTimeString("vi-VN"),
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen, user?.name, messages.length]);

  const getContextPrompt = () => {
    switch (context) {
      case "customer":
        return contextData
          ? `Thông tin khách hàng hiện tại: ${JSON.stringify(contextData)}`
          : "";
      case "task":
        return contextData
          ? `Thông tin task hiện tại: ${JSON.stringify(contextData)}`
          : "";
      default:
        return "Đây là cuộc trò chuyện tổng quan về CRM và quản lý công việc";
    }
  };

  const quickSuggestions = [
    {
      icon: Users,
      text: "Phân tích khách hàng tiềm năng",
      prompt:
        "Hãy phân tích danh sách khách hàng tiềm năng và đưa ra chiến lược tiếp cận phù hợp",
    },
    {
      icon: Calendar,
      text: "Lên kế hoạch tuần",
      prompt:
        "Giúp tôi lên kế hoạch công việc cho tuần này dựa trên các task đang có",
    },
    {
      icon: BarChart3,
      text: "Báo cáo hiệu suất",
      prompt:
        "Tạo báo cáo tóm tắt về hiệu suất làm việc và đưa ra khuyến nghị cải thiện",
    },
    {
      icon: Lightbulb,
      text: "Ý tưởng marketing",
      prompt: "Đưa ra các ý tưởng marketing sáng tạo cho sản phẩm sơn Lavis",
    },
  ];

  const handleSendMessage = async (messageText?: string) => {
    const message = messageText || inputMessage.trim();
    if (!message || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: "user",
      content: message,
      timestamp: new Date().toLocaleTimeString("vi-VN"),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputMessage("");
    setIsLoading(true);

    try {
      const contextPrompt = getContextPrompt();
      const response = await AIService.chatWithAI(message, contextPrompt);

      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: "ai",
        content: response.success
          ? response.text
          : "Xin lỗi, tôi không thể trả lời được lúc này. Vui lòng thử lại sau.",
        timestamp: new Date().toLocaleTimeString("vi-VN"),
      };

      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: "ai",
        content: "Đã xảy ra lỗi khi kết nối với AI. Vui lòng thử lại sau.",
        timestamp: new Date().toLocaleTimeString("vi-VN"),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChat = () => {
    setMessages([]);
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={onToggle}
          className="rounded-full h-14 w-14 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 shadow-lg hover:shadow-xl transition-all duration-200"
        >
          <Bot className="h-6 w-6 text-white" />
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Card
        className={`transition-all duration-300 shadow-2xl border-0 bg-white/95 backdrop-blur-sm ${
          isMinimized ? "w-80 h-16" : "w-96 h-[600px]"
        }`}
      >
        <CardHeader className="p-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bot className="h-5 w-5" />
              <div>
                <CardTitle className="text-sm">AI Assistant</CardTitle>
                <CardDescription className="text-xs text-blue-100">
                  Powered by Gemini AI
                </CardDescription>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMinimized(!isMinimized)}
                className="h-8 w-8 p-0 text-white hover:bg-white/20"
              >
                {isMinimized ? (
                  <Maximize2 className="h-4 w-4" />
                ) : (
                  <Minimize2 className="h-4 w-4" />
                )}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={onToggle}
                className="h-8 w-8 p-0 text-white hover:bg-white/20"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
          {context !== "general" && !isMinimized && (
            <Badge variant="secondary" className="w-fit text-xs">
              {context === "customer" ? "Tư vấn khách hàng" : "Hỗ trợ task"}
            </Badge>
          )}
        </CardHeader>

        {!isMinimized && (
          <CardContent className="p-0 flex flex-col h-[calc(100%-80px)]">
            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex items-start gap-2 ${
                      message.type === "user" ? "flex-row-reverse" : "flex-row"
                    }`}
                  >
                    <div
                      className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                        message.type === "user"
                          ? "bg-blue-600 text-white"
                          : "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                      }`}
                    >
                      {message.type === "user" ? (
                        <User className="h-4 w-4" />
                      ) : (
                        <Bot className="h-4 w-4" />
                      )}
                    </div>
                    <div
                      className={`flex-1 max-w-[80%] ${
                        message.type === "user" ? "text-right" : "text-left"
                      }`}
                    >
                      <div
                        className={`inline-block p-3 rounded-lg text-sm ${
                          message.type === "user"
                            ? "bg-blue-600 text-white rounded-br-sm"
                            : "bg-gray-100 text-gray-900 rounded-bl-sm"
                        }`}
                      >
                        <div className="whitespace-pre-line">
                          {message.content}
                        </div>
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        {message.timestamp}
                      </div>
                    </div>
                  </div>
                ))}

                {isLoading && (
                  <div className="flex items-start gap-2">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white flex items-center justify-center">
                      <Bot className="h-4 w-4" />
                    </div>
                    <div className="bg-gray-100 p-3 rounded-lg rounded-bl-sm">
                      <div className="flex space-x-1">
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0ms" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "150ms" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "300ms" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Quick Suggestions */}
            {messages.length <= 1 && (
              <div className="p-4 border-t border-gray-200">
                <p className="text-xs text-gray-600 mb-2">Gợi ý nhanh:</p>
                <div className="grid grid-cols-2 gap-2">
                  {quickSuggestions.map((suggestion, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      className="text-xs h-auto p-2 flex flex-col items-center gap-1 hover:bg-blue-50"
                      onClick={() => handleSendMessage(suggestion.prompt)}
                    >
                      <suggestion.icon className="h-3 w-3" />
                      <span className="text-center leading-tight">
                        {suggestion.text}
                      </span>
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Input */}
            <div className="p-4 border-t border-gray-200">
              <div className="flex gap-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Nhập tin nhắn..."
                  disabled={isLoading}
                  className="flex-1"
                />
                <Button
                  onClick={() => handleSendMessage()}
                  disabled={!inputMessage.trim() || isLoading}
                  size="sm"
                  className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
              {messages.length > 1 && (
                <div className="flex justify-center mt-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearChat}
                    className="text-xs text-gray-500"
                  >
                    Xóa cuộc trò chuyện
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
}
