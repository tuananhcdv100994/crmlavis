DebugHelper.runFullDiagnostic();
