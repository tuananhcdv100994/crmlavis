import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users, UserPlus, Trash2, Edit, Phone, Mail, Building2, Shield, Activity, Search, Filter, Calendar } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface User {
  id: string;
  username: string;
  email: string;
  name: string;
  role: "admin" | "employee";
  department: string;
  position: string;
  phone: string;
  avatar?: string;
  status: "active" | "inactive";
  lastLogin?: string;
  permissions: string[];
  createdAt: string;
}

export default function UserManagement() {
  const { user } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDepartment, setFilterDepartment] = useState("all");
  const [filterRole, setFilterRole] = useState("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  // Check permission - only admin can access
  if (!user || user.role !== "admin") {
    return <Navigate to="/login" replace />;
  }

  // Load users on component mount
  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = () => {
    console.log("Loading users...");
    try {
      const saved = localStorage.getItem('crm_users');
      if (saved) {
        const data = JSON.parse(saved);
        console.log("Loaded users:", data.length);
        setUsers(data);
      } else {
        // Create initial sample data
        const sampleUsers: User[] = [
          {
            id: "admin-1",
            username: "tuananhcdv",
            email: "nam.nguyen@lavisholding.com",
            name: "Nguyễn Văn Nam",
            role: "admin",
            department: "Quản trị",
            position: "Giám đốc điều hành",
            phone: "0907654321",
            avatar: "/placeholder.svg",
            status: "active",
            lastLogin: "2024-01-15 09:30",
            permissions: [
              "view_customers", "create_customers", "edit_customers", "delete_customers",
              "view_tasks", "create_tasks", "edit_tasks", "delete_tasks",
              "view_users", "create_users", "edit_users", "delete_users",
              "view_reports", "export_data", "system_settings",
              "view_departments", "create_departments", "edit_departments", "delete_departments",
              "manage_permissions", "manage_chat", "create_groups",
              "all"
            ],
            createdAt: "2023-01-01",
          },
          {
            id: "emp-2",
            username: "employee2",
            email: "lan.tran@lavisholding.com",
            name: "Trần Thị Lan",
            role: "employee",
            department: "Marketing",
            position: "Chuyên viên Marketing",
            phone: "0912345678",
            status: "active",
            lastLogin: "2024-01-14 17:20",
            permissions: ["view_customers", "view_tasks", "create_tasks", "edit_tasks"],
            createdAt: "2023-03-10",
          },
          {
            id: "emp-3",
            username: "employee3",
            email: "phong.le@lavisholding.com",
            name: "Lê Văn Phong",
            role: "employee",
            department: "Kỹ thuật",
            position: "Kỹ sư",
            phone: "0923456789",
            status: "active",
            lastLogin: "2024-01-12 15:30",
            permissions: ["view_tasks", "create_tasks", "edit_tasks"],
            createdAt: "2023-04-20",
          },
        ];
        setUsers(sampleUsers);
        localStorage.setItem('crm_users', JSON.stringify(sampleUsers));
        console.log("Created sample users:", sampleUsers.length);
      }
    } catch (error) {
      console.error("Error loading users:", error);
      setUsers([]);
    }
  };

  const saveUsers = (newUsers: User[]) => {
    try {
      localStorage.setItem('crm_users', JSON.stringify(newUsers));
      setUsers(newUsers);
      console.log("Saved users:", newUsers.length);
    } catch (error) {
      console.error("Error saving users:", error);
      toast({
        title: "❌ Lỗi lưu dữ liệu",
        description: "Không thể lưu thông tin người dùng",
        variant: "destructive",
      });
    }
  };

  const handleCreateUser = (formData: any) => {
    console.log("Creating user:", formData);
    
    try {
      // Check if username or email already exists
      const existingUser = users.find(u => 
        u.username === formData.username || u.email === formData.email
      );
      
      if (existingUser) {
        toast({
          title: "❌ Lỗi",
          description: "Username hoặc email đã tồn tại",
          variant: "destructive",
        });
        return;
      }

      const newUser: User = {
        id: `user-${Date.now()}`,
        ...formData,
        avatar: "/placeholder.svg",
        status: "active",
        createdAt: new Date().toISOString().split('T')[0],
        lastLogin: undefined,
        permissions: formData.role === "admin" ? [
          "view_customers", "create_customers", "edit_customers", "delete_customers",
          "view_tasks", "create_tasks", "edit_tasks", "delete_tasks",
          "view_users", "create_users", "edit_users", "delete_users",
          "view_reports", "export_data", "system_settings",
          "manage_permissions", "all"
        ] : ["view_customers", "view_tasks"],
      };

      const updatedUsers = [...users, newUser];
      saveUsers(updatedUsers);

      toast({
        title: "✅ Thành công",
        description: `Đã tạo tài khoản: ${newUser.name}`,
      });

      setIsCreateDialogOpen(false);
    } catch (error) {
      console.error("Error creating user:", error);
      toast({
        title: "❌ Lỗi",
        description: "Không thể tạo tài khoản",
        variant: "destructive",
      });
    }
  };

  const handleEditUser = (formData: any) => {
    console.log("Editing user:", formData);
    
    if (!editingUser) return;

    try {
      const updatedUser = { ...editingUser, ...formData };
      const updatedUsers = users.map(u => 
        u.id === editingUser.id ? updatedUser : u
      );
      
      saveUsers(updatedUsers);

      toast({
        title: "✅ Thành công",
        description: `Đã cập nhật tài khoản: ${updatedUser.name}`,
      });

      setIsEditDialogOpen(false);
      setEditingUser(null);
    } catch (error) {
      console.error("Error editing user:", error);
      toast({
        title: "❌ Lỗi",
        description: "Không thể cập nhật tài khoản",
        variant: "destructive",
      });
    }
  };

  const handleDeleteUser = (userId: string) => {
    console.log("Deleting user:", userId);
    
    // Prevent admin from deleting themselves
    if (userId === user.id) {
      toast({
        title: "❌ Không thể xóa",
        description: "Bạn không thể xóa tài khoản của chính mình",
        variant: "destructive",
      });
      return;
    }

    try {
      const updatedUsers = users.filter(u => u.id !== userId);
      saveUsers(updatedUsers);

      toast({
        title: "✅ Thành công",
        description: "Đã xóa tài khoản",
      });
    } catch (error) {
      console.error("Error deleting user:", error);
      toast({
        title: "❌ Lỗi",
        description: "Không thể xóa tài khoản",
        variant: "destructive",
      });
    }
  };

  const handleUpdateStatus = (userId: string, newStatus: "active" | "inactive") => {
    console.log("Updating user status:", userId, newStatus);
    
    // Prevent admin from deactivating themselves
    if (userId === user.id && newStatus === "inactive") {
      toast({
        title: "❌ Không thể thực hiện",
        description: "Bạn không thể vô hiệu hóa tài khoản của chính mình",
        variant: "destructive",
      });
      return;
    }

    try {
      const updatedUsers = users.map(u => 
        u.id === userId ? { ...u, status: newStatus } : u
      );
      saveUsers(updatedUsers);

      toast({
        title: "✅ Cập nhật trạng thái",
        description: `Đã ${newStatus === "active" ? "kích hoạt" : "vô hiệu hóa"} tài khoản`,
      });
    } catch (error) {
      console.error("Error updating user status:", error);
      toast({
        title: "❌ Lỗi",
        description: "Không thể cập nhật trạng thái",
        variant: "destructive",
      });
    }
  };

  const departments = ["Quản trị", "Kinh doanh", "Marketing", "Kỹ thuật", "Nhân sự", "Kế toán"];
  const positions = ["Giám đốc", "Trưởng phòng", "Chuyên viên", "Nhân viên", "Thực tập sinh"];

  const filteredUsers = users.filter((userData) => {
    const matchesSearch =
      userData.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      userData.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      userData.department.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDepartment = filterDepartment === "all" || userData.department === filterDepartment;
    const matchesRole = filterRole === "all" || userData.role === filterRole;
    
    return matchesSearch && matchesDepartment && matchesRole;
  });

  const stats = {
    total: users.length,
    active: users.filter(u => u.status === "active").length,
    inactive: users.filter(u => u.status === "inactive").length,
    admins: users.filter(u => u.role === "admin").length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Quản lý người dùng</h1>
          <p className="text-gray-600">Tạo, chỉnh sửa và quản lý tài khoản người dùng</p>
        </div>
        
        <CreateUserDialog 
          isOpen={isCreateDialogOpen}
          onOpenChange={setIsCreateDialogOpen}
          onSubmit={handleCreateUser}
          departments={departments}
          positions={positions}
        />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tổng người dùng</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Đang hoạt động</p>
                <p className="text-2xl font-bold text-green-600">{stats.active}</p>
              </div>
              <Activity className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Không hoạt động</p>
                <p className="text-2xl font-bold text-gray-600">{stats.inactive}</p>
              </div>
              <Users className="h-8 w-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Quản trị viên</p>
                <p className="text-2xl font-bold text-orange-600">{stats.admins}</p>
              </div>
              <Shield className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Tìm kiếm người dùng..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterDepartment} onValueChange={setFilterDepartment}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Phòng ban" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả phòng ban</SelectItem>
                {departments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterRole} onValueChange={setFilterRole}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Vai trò" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả vai trò</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="employee">Nhân viên</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* User List */}
      <div className="space-y-4">
        {filteredUsers.map((userData) => (
          <UserCard
            key={userData.id}
            user={userData}
            currentUser={user}
            onEdit={(user) => {
              setEditingUser(user);
              setIsEditDialogOpen(true);
            }}
            onDelete={handleDeleteUser}
            onUpdateStatus={handleUpdateStatus}
            departments={departments}
            positions={positions}
          />
        ))}
      </div>

      {filteredUsers.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Users className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium mb-2">Không có người dùng</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm ? "Không tìm thấy người dùng phù hợp" : "Chưa có người dùng nào trong hệ thống"}
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <UserPlus className="h-4 w-4 mr-2" />
              Thêm người dùng đầu tiên
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Edit Dialog */}
      {editingUser && (
        <EditUserDialog
          user={editingUser}
          isOpen={isEditDialogOpen}
          onOpenChange={setIsEditDialogOpen}
          onSubmit={handleEditUser}
          departments={departments}
          positions={positions}
        />
      )}
    </div>
  );
}

// User Card Component
function UserCard({ 
  user: userData, 
  currentUser,
  onEdit, 
  onDelete, 
  onUpdateStatus,
  departments,
  positions
}: {
  user: User;
  currentUser: any;
  onEdit: (user: User) => void;
  onDelete: (id: string) => void;
  onUpdateStatus: (id: string, status: "active" | "inactive") => void;
  departments: string[];
  positions: string[];
}) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div className="flex items-center space-x-4 flex-1">
            <Avatar className="h-12 w-12">
              <AvatarImage src={userData.avatar} alt={userData.name} />
              <AvatarFallback>{userData.name.charAt(0)}</AvatarFallback>
            </Avatar>

            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-medium">{userData.name}</h3>
                <Badge variant={userData.role === "admin" ? "default" : "secondary"}>
                  {userData.role === "admin" ? "Admin" : "Nhân viên"}
                </Badge>
                <Badge variant={userData.status === "active" ? "default" : "outline"}>
                  {userData.status === "active" ? "Hoạt động" : "Không hoạt động"}
                </Badge>
                {userData.id === currentUser.id && (
                  <Badge variant="outline" className="text-blue-600">
                    Bạn
                  </Badge>
                )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Mail className="h-3 w-3" />
                    <span>{userData.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-3 w-3" />
                    <span>{userData.phone}</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-3 w-3" />
                    <span>{userData.department} - {userData.position}</span>
                  </div>
                  {userData.lastLogin && (
                    <div className="flex items-center gap-2">
                      <Calendar className="h-3 w-3" />
                      <span>Đăng nhập: {userData.lastLogin}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-2 text-xs text-gray-500">
                <span>Quyền: {userData.permissions.length} permissions</span>
                <span className="ml-4">Tạo: {userData.createdAt}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2 ml-4">
            {/* Status Toggle */}
            <Select 
              value={userData.status} 
              onValueChange={(value) => onUpdateStatus(userData.id, value as "active" | "inactive")}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Hoạt động</SelectItem>
                <SelectItem value="inactive">Không hoạt động</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onEdit(userData)}
              >
                <Edit className="h-4 w-4" />
              </Button>
              
              {userData.id !== currentUser.id && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (confirm(`Bạn có chắc muốn xóa tài khoản "${userData.name}"?`)) {
                      onDelete(userData.id);
                    }
                  }}
                  className="hover:bg-red-50 hover:border-red-300"
                >
                  <Trash2 className="h-4 w-4 text-red-600" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Create User Dialog
function CreateUserDialog({ 
  isOpen, 
  onOpenChange, 
  onSubmit,
  departments,
  positions 
}: {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: any) => void;
  departments: string[];
  positions: string[];
}) {
  const [formData, setFormData] = useState({
    name: "",
    username: "",
    email: "",
    phone: "",
    department: "",
    position: "",
    role: "employee",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.username.trim() || !formData.email.trim()) {
      toast({
        title: "❌ Lỗi",
        description: "Vui lòng điền đầy đủ thông tin bắt buộc",
        variant: "destructive",
      });
      return;
    }

    if (!formData.department || !formData.position) {
      toast({
        title: "❌ Lỗi",
        description: "Vui lòng chọn phòng ban và chức vụ",
        variant: "destructive",
      });
      return;
    }

    onSubmit(formData);

    // Reset form
    setFormData({
      name: "",
      username: "",
      email: "",
      phone: "",
      department: "",
      position: "",
      role: "employee",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button>
          <UserPlus className="h-4 w-4 mr-2" />
          Tạo tài khoản
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Tạo tài khoản mới</DialogTitle>
          <DialogDescription>
            Điền thông tin để tạo tài khoản cho nhân viên mới
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Họ và tên *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Nhập họ và tên"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">Tên đăng nhập *</Label>
              <Input
                id="username"
                value={formData.username}
                onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                placeholder="Nhập tên đăng nhập"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="Nhập email"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Số điện thoại</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                placeholder="Nhập số điện thoại"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="department">Phòng ban *</Label>
              <Select value={formData.department} onValueChange={(value) => setFormData(prev => ({ ...prev, department: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Chọn phòng ban" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="position">Chức vụ *</Label>
              <Select value={formData.position} onValueChange={(value) => setFormData(prev => ({ ...prev, position: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Chọn chức vụ" />
                </SelectTrigger>
                <SelectContent>
                  {positions.map((pos) => (
                    <SelectItem key={pos} value={pos}>
                      {pos}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Vai trò</Label>
            <Select value={formData.role} onValueChange={(value) => setFormData(prev => ({ ...prev, role: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="employee">Nhân viên</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Hủy
            </Button>
            <Button type="submit">
              Tạo tài khoản
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Edit User Dialog
function EditUserDialog({ 
  user,
  isOpen, 
  onOpenChange, 
  onSubmit,
  departments,
  positions
}: {
  user: User;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: any) => void;
  departments: string[];
  positions: string[];
}) {
  const [formData, setFormData] = useState({
    name: user.name,
    username: user.username,
    email: user.email,
    phone: user.phone,
    department: user.department,
    position: user.position,
    role: user.role,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.username.trim() || !formData.email.trim()) {
      toast({
        title: "❌ Lỗi",
        description: "Vui lòng điền đầy đủ thông tin bắt buộc",
        variant: "destructive",
      });
      return;
    }

    onSubmit(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Chỉnh sửa tài khoản</DialogTitle>
          <DialogDescription>
            Cập nhật thông tin tài khoản người dùng
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Họ và tên *</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Nhập họ và tên"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-username">Tên đăng nhập *</Label>
              <Input
                id="edit-username"
                value={formData.username}
                onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                placeholder="Nhập tên đăng nhập"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-email">Email *</Label>
              <Input
                id="edit-email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="Nhập email"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-phone">Số điện thoại</Label>
              <Input
                id="edit-phone"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                placeholder="Nhập số điện thoại"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-department">Phòng ban</Label>
              <Select value={formData.department} onValueChange={(value) => setFormData(prev => ({ ...prev, department: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-position">Chức vụ</Label>
              <Select value={formData.position} onValueChange={(value) => setFormData(prev => ({ ...prev, position: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {positions.map((pos) => (
                    <SelectItem key={pos} value={pos}>
                      {pos}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-role">Vai trò</Label>
            <Select value={formData.role} onValueChange={(value) => setFormData(prev => ({ ...prev, role: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="employee">Nhân viên</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Hủy
            </Button>
            <Button type="submit">
              Cập nhật
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
