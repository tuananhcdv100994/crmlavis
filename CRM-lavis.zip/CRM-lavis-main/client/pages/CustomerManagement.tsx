import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Users, UserPlus, Trash2, Edit, Phone, Mail, Building2, MapPin, Calendar, DollarSign, Search, Filter, Star } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Customer {
  id: string;
  name: string;
  industry: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  status: "potential" | "active" | "inactive";
  assignedTo: string;
  assignedToName: string;
  estimatedValue: number;
  notes: string;
  createdAt: string;
  source: string;
  priority: "low" | "medium" | "high";
  projects: Project[];
  totalProjectValue: number;
  activeProjects: number;
  completedProjects: number;
}

interface Project {
  id: string;
  name: string;
  value: number;
  status: "active" | "completed" | "on-hold";
  startDate: string;
  endDate?: string;
}

export default function CustomerManagement() {
  const { user } = useAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  // Check permission
  if (!user || (user.role !== "admin" && !user.permissions?.includes("view_customers"))) {
    return <Navigate to="/login" replace />;
  }

  // Load customers on component mount
  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = () => {
    console.log("Loading customers...");
    try {
      const saved = localStorage.getItem('crm_customers');
      if (saved) {
        const data = JSON.parse(saved);
        console.log("Loaded customers:", data.length);
        setCustomers(data);
      } else {
        // Create initial sample data
        const sampleCustomers: Customer[] = [
          {
            id: "cust-1",
            name: "Công ty TNHH ABC",
            industry: "Công nghệ",
            contactPerson: "Nguyễn Văn A",
            email: "a.nguyen@abc.com",
            phone: "0901234567",
            address: "123 Đường ABC, TP.HCM",
            status: "active",
            assignedTo: "admin-1",
            assignedToName: "Nguyễn Văn Nam",
            estimatedValue: 5000000,
            notes: "Khách hàng tiềm năng cao",
            createdAt: "2024-01-15",
            source: "Website",
            priority: "high",
            projects: [],
            totalProjectValue: 0,
            activeProjects: 0,
            completedProjects: 0,
          },
          {
            id: "cust-2", 
            name: "Công ty CP XYZ",
            industry: "Sản xuất",
            contactPerson: "Trần Thị B",
            email: "b.tran@xyz.com",
            phone: "0907654321",
            address: "456 Đường XYZ, Hà Nội",
            status: "potential",
            assignedTo: "admin-1",
            assignedToName: "Nguyễn Văn Nam",
            estimatedValue: 3000000,
            notes: "Cần follow up thường xuyên",
            createdAt: "2024-01-10",
            source: "Referral",
            priority: "medium",
            projects: [],
            totalProjectValue: 0,
            activeProjects: 0,
            completedProjects: 0,
          }
        ];
        setCustomers(sampleCustomers);
        localStorage.setItem('crm_customers', JSON.stringify(sampleCustomers));
        console.log("Created sample customers:", sampleCustomers.length);
      }
    } catch (error) {
      console.error("Error loading customers:", error);
      setCustomers([]);
    }
  };

  const saveCustomers = (newCustomers: Customer[]) => {
    try {
      localStorage.setItem('crm_customers', JSON.stringify(newCustomers));
      setCustomers(newCustomers);
      console.log("Saved customers:", newCustomers.length);
    } catch (error) {
      console.error("Error saving customers:", error);
      toast({
        title: "❌ Lỗi lưu dữ liệu",
        description: "Không thể lưu thông tin khách hàng",
        variant: "destructive",
      });
    }
  };

  const handleCreateCustomer = (formData: any) => {
    console.log("Creating customer:", formData);
    
    // Check permission
    if (user.role !== "admin" && !user.permissions?.includes("create_customers")) {
      toast({
        title: "❌ Không có quyền",
        description: "Bạn không có quyền tạo khách hàng",
        variant: "destructive",
      });
      return;
    }

    try {
      const newCustomer: Customer = {
        id: `cust-${Date.now()}`,
        ...formData,
        assignedTo: user.id,
        assignedToName: user.name,
        createdAt: new Date().toISOString().split('T')[0],
        projects: [],
        totalProjectValue: 0,
        activeProjects: 0,
        completedProjects: 0,
      };

      const updatedCustomers = [...customers, newCustomer];
      saveCustomers(updatedCustomers);

      toast({
        title: "✅ Thành công",
        description: `Đã tạo khách hàng: ${newCustomer.name}`,
      });

      setIsCreateDialogOpen(false);
    } catch (error) {
      console.error("Error creating customer:", error);
      toast({
        title: "❌ Lỗi",
        description: "Không thể tạo khách hàng",
        variant: "destructive",
      });
    }
  };

  const handleEditCustomer = (formData: any) => {
    console.log("Editing customer:", formData);
    
    if (!editingCustomer) return;

    // Check permission
    if (user.role !== "admin" && !user.permissions?.includes("edit_customers")) {
      toast({
        title: "❌ Không có quyền",
        description: "Bạn không có quyền sửa khách hàng",
        variant: "destructive",
      });
      return;
    }

    try {
      const updatedCustomer = { ...editingCustomer, ...formData };
      const updatedCustomers = customers.map(c => 
        c.id === editingCustomer.id ? updatedCustomer : c
      );
      
      saveCustomers(updatedCustomers);

      toast({
        title: "✅ Thành công",
        description: `Đã cập nhật khách hàng: ${updatedCustomer.name}`,
      });

      setIsEditDialogOpen(false);
      setEditingCustomer(null);
    } catch (error) {
      console.error("Error editing customer:", error);
      toast({
        title: "❌ Lỗi",
        description: "Không thể cập nhật khách hàng",
        variant: "destructive",
      });
    }
  };

  const handleDeleteCustomer = (customerId: string) => {
    console.log("Deleting customer:", customerId);
    
    // Check permission
    if (user.role !== "admin" && !user.permissions?.includes("delete_customers")) {
      toast({
        title: "❌ Không có quyền",
        description: "Bạn không có quyền xóa khách hàng",
        variant: "destructive",
      });
      return;
    }

    try {
      const updatedCustomers = customers.filter(c => c.id !== customerId);
      saveCustomers(updatedCustomers);

      toast({
        title: "✅ Thành công",
        description: "Đã xóa khách hàng",
      });
    } catch (error) {
      console.error("Error deleting customer:", error);
      toast({
        title: "❌ Lỗi",
        description: "Không thể xóa khách hàng",
        variant: "destructive",
      });
    }
  };

  const filteredCustomers = customers.filter((customer) => {
    const matchesSearch = 
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.contactPerson.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === "all" || customer.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: customers.length,
    active: customers.filter(c => c.status === "active").length,
    potential: customers.filter(c => c.status === "potential").length,
    inactive: customers.filter(c => c.status === "inactive").length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Quản lý khách hàng</h1>
          <p className="text-gray-600">Quản lý thông tin khách hàng và cơ hội kinh doanh</p>
        </div>
        
        {(user.role === "admin" || user.permissions?.includes("create_customers")) && (
          <CreateCustomerDialog 
            isOpen={isCreateDialogOpen}
            onOpenChange={setIsCreateDialogOpen}
            onSubmit={handleCreateCustomer}
          />
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tổng khách hàng</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Đang hoạt động</p>
                <p className="text-2xl font-bold text-green-600">{stats.active}</p>
              </div>
              <Building2 className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tiềm năng</p>
                <p className="text-2xl font-bold text-yellow-600">{stats.potential}</p>
              </div>
              <Star className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Không hoạt động</p>
                <p className="text-2xl font-bold text-gray-600">{stats.inactive}</p>
              </div>
              <Users className="h-8 w-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Tìm kiếm khách hàng..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả trạng thái</SelectItem>
                <SelectItem value="active">Đang hoạt động</SelectItem>
                <SelectItem value="potential">Tiềm năng</SelectItem>
                <SelectItem value="inactive">Không hoạt động</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Customer List */}
      <div className="space-y-4">
        {filteredCustomers.map((customer) => (
          <CustomerCard
            key={customer.id}
            customer={customer}
            onEdit={(customer) => {
              setEditingCustomer(customer);
              setIsEditDialogOpen(true);
            }}
            onDelete={handleDeleteCustomer}
            canEdit={user.role === "admin" || user.permissions?.includes("edit_customers")}
            canDelete={user.role === "admin" || user.permissions?.includes("delete_customers")}
          />
        ))}
      </div>

      {filteredCustomers.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Users className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium mb-2">Không có khách hàng</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm ? "Không tìm thấy khách hàng phù hợp" : "Chưa có khách hàng nào trong hệ thống"}
            </p>
            {(user.role === "admin" || user.permissions?.includes("create_customers")) && (
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <UserPlus className="h-4 w-4 mr-2" />
                Thêm khách hàng đầu tiên
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Edit Dialog */}
      {editingCustomer && (
        <EditCustomerDialog
          customer={editingCustomer}
          isOpen={isEditDialogOpen}
          onOpenChange={setIsEditDialogOpen}
          onSubmit={handleEditCustomer}
        />
      )}
    </div>
  );
}

// Customer Card Component
function CustomerCard({ 
  customer, 
  onEdit, 
  onDelete, 
  canEdit, 
  canDelete 
}: {
  customer: Customer;
  onEdit: (customer: Customer) => void;
  onDelete: (id: string) => void;
  canEdit: boolean;
  canDelete: boolean;
}) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800";
      case "potential": return "bg-yellow-100 text-yellow-800";
      case "inactive": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <h3 className="text-lg font-semibold">{customer.name}</h3>
              <Badge className={getStatusColor(customer.status)}>
                {customer.status === "active" ? "Đang hoạt động" :
                 customer.status === "potential" ? "Tiềm năng" : "Không hoạt động"}
              </Badge>
              <Badge className={getPriorityColor(customer.priority)}>
                {customer.priority === "high" ? "Cao" :
                 customer.priority === "medium" ? "Trung bình" : "Thấp"}
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4" />
                  <span>{customer.industry}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>{customer.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span>{customer.phone}</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span>{customer.address}</span>
                </div>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  <span>{customer.estimatedValue.toLocaleString('vi-VN')} VNĐ</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span>Tạo: {customer.createdAt}</span>
                </div>
              </div>
            </div>

            {customer.notes && (
              <div className="mt-3 p-3 bg-gray-50 rounded text-sm">
                <strong>Ghi chú:</strong> {customer.notes}
              </div>
            )}
          </div>

          <div className="flex gap-2 ml-4">
            {canEdit && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onEdit(customer)}
              >
                <Edit className="h-4 w-4" />
              </Button>
            )}
            {canDelete && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  if (confirm(`Bạn có chắc muốn xóa khách hàng "${customer.name}"?`)) {
                    onDelete(customer.id);
                  }
                }}
                className="hover:bg-red-50 hover:border-red-300"
              >
                <Trash2 className="h-4 w-4 text-red-600" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Create Customer Dialog
function CreateCustomerDialog({ 
  isOpen, 
  onOpenChange, 
  onSubmit 
}: {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: any) => void;
}) {
  const [formData, setFormData] = useState({
    name: "",
    industry: "",
    contactPerson: "",
    email: "",
    phone: "",
    address: "",
    status: "potential",
    estimatedValue: "",
    notes: "",
    source: "",
    priority: "medium",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.contactPerson.trim() || !formData.email.trim()) {
      toast({
        title: "❌ Lỗi",
        description: "Vui lòng điền đầy đủ thông tin bắt buộc",
        variant: "destructive",
      });
      return;
    }

    onSubmit({
      ...formData,
      estimatedValue: parseInt(formData.estimatedValue) || 0,
    });

    // Reset form
    setFormData({
      name: "",
      industry: "",
      contactPerson: "",
      email: "",
      phone: "",
      address: "",
      status: "potential",
      estimatedValue: "",
      notes: "",
      source: "",
      priority: "medium",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button>
          <UserPlus className="h-4 w-4 mr-2" />
          Thêm khách hàng
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Thêm khách hàng mới</DialogTitle>
          <DialogDescription>
            Điền thông tin khách hàng mới vào form bên dưới
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Tên công ty *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Nhập tên công ty"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="industry">Ngành nghề</Label>
              <Input
                id="industry"
                value={formData.industry}
                onChange={(e) => setFormData(prev => ({ ...prev, industry: e.target.value }))}
                placeholder="Nhập ngành nghề"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="contactPerson">Người liên hệ *</Label>
              <Input
                id="contactPerson"
                value={formData.contactPerson}
                onChange={(e) => setFormData(prev => ({ ...prev, contactPerson: e.target.value }))}
                placeholder="Nhập tên người liên hệ"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="Nhập email"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Số điện thoại</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                placeholder="Nhập số điện thoại"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="estimatedValue">Giá trị ước tính (VNĐ)</Label>
              <Input
                id="estimatedValue"
                type="number"
                value={formData.estimatedValue}
                onChange={(e) => setFormData(prev => ({ ...prev, estimatedValue: e.target.value }))}
                placeholder="0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Địa chỉ</Label>
            <Input
              id="address"
              value={formData.address}
              onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
              placeholder="Nhập địa chỉ"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status">Trạng thái</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="potential">Tiềm năng</SelectItem>
                  <SelectItem value="active">Đang hoạt động</SelectItem>
                  <SelectItem value="inactive">Không hoạt động</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="priority">Độ ưu tiên</Label>
              <Select value={formData.priority} onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Thấp</SelectItem>
                  <SelectItem value="medium">Trung bình</SelectItem>
                  <SelectItem value="high">Cao</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="source">Nguồn khách hàng</Label>
              <Input
                id="source"
                value={formData.source}
                onChange={(e) => setFormData(prev => ({ ...prev, source: e.target.value }))}
                placeholder="Website, Referral..."
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Ghi chú</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Ghi chú về khách hàng..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Hủy
            </Button>
            <Button type="submit">
              Tạo khách hàng
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Edit Customer Dialog
function EditCustomerDialog({ 
  customer,
  isOpen, 
  onOpenChange, 
  onSubmit 
}: {
  customer: Customer;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: any) => void;
}) {
  const [formData, setFormData] = useState({
    name: customer.name,
    industry: customer.industry,
    contactPerson: customer.contactPerson,
    email: customer.email,
    phone: customer.phone,
    address: customer.address,
    status: customer.status,
    estimatedValue: customer.estimatedValue.toString(),
    notes: customer.notes,
    source: customer.source,
    priority: customer.priority,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.contactPerson.trim() || !formData.email.trim()) {
      toast({
        title: "❌ Lỗi",
        description: "Vui lòng điền đầy đủ thông tin bắt buộc",
        variant: "destructive",
      });
      return;
    }

    onSubmit({
      ...formData,
      estimatedValue: parseInt(formData.estimatedValue) || 0,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Chỉnh sửa khách hàng</DialogTitle>
          <DialogDescription>
            Cập nhật thông tin khách hàng
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Tên công ty *</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Nhập tên công ty"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-industry">Ngành nghề</Label>
              <Input
                id="edit-industry"
                value={formData.industry}
                onChange={(e) => setFormData(prev => ({ ...prev, industry: e.target.value }))}
                placeholder="Nhập ngành nghề"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-contactPerson">Người liên hệ *</Label>
              <Input
                id="edit-contactPerson"
                value={formData.contactPerson}
                onChange={(e) => setFormData(prev => ({ ...prev, contactPerson: e.target.value }))}
                placeholder="Nhập tên người liên hệ"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-email">Email *</Label>
              <Input
                id="edit-email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="Nhập email"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-phone">Số điện thoại</Label>
              <Input
                id="edit-phone"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                placeholder="Nhập số điện thoại"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-estimatedValue">Giá trị ước tính (VNĐ)</Label>
              <Input
                id="edit-estimatedValue"
                type="number"
                value={formData.estimatedValue}
                onChange={(e) => setFormData(prev => ({ ...prev, estimatedValue: e.target.value }))}
                placeholder="0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-address">Địa chỉ</Label>
            <Input
              id="edit-address"
              value={formData.address}
              onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
              placeholder="Nhập địa chỉ"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-status">Trạng thái</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="potential">Tiềm năng</SelectItem>
                  <SelectItem value="active">Đang hoạt động</SelectItem>
                  <SelectItem value="inactive">Không hoạt động</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-priority">Độ ưu tiên</Label>
              <Select value={formData.priority} onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Thấp</SelectItem>
                  <SelectItem value="medium">Trung bình</SelectItem>
                  <SelectItem value="high">Cao</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-source">Nguồn khách hàng</Label>
              <Input
                id="edit-source"
                value={formData.source}
                onChange={(e) => setFormData(prev => ({ ...prev, source: e.target.value }))}
                placeholder="Website, Referral..."
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-notes">Ghi chú</Label>
            <Textarea
              id="edit-notes"
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Ghi chú về khách hàng..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Hủy
            </Button>
            <Button type="submit">
              Cập nhật
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
