import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Building2,
  Users,
  Plus,
  Edit,
  Trash2,
  Target,
  TrendingUp,
  Calendar,
  Award,
  UserCheck,
  Briefcase,
  Search,
  Filter,
  BarChart3,
  PieChart,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { DataService } from "@/services/dataService";

interface Department {
  id: string;
  name: string;
  description: string;
  manager: string;
  managerId: string;
  memberCount: number;
  budget: number;
  status: "active" | "inactive";
  goals: string[];
  location: string;
  createdAt: string;
  updatedAt: string;
  color: string;
}

interface DepartmentStats {
  totalEmployees: number;
  totalCustomers: number;
  activeTasks: number;
  completedTasks: number;
  monthlyRevenue: number;
  performance: number;
}

export default function DepartmentManagement() {
  const { user } = useAuth();
  const [departments, setDepartments] = useState<Department[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<Department | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [departmentStats, setDepartmentStats] = useState<Record<string, DepartmentStats>>({});

  useEffect(() => {
    loadDepartments();
    loadUsers();
    loadStats();
  }, []);

  const loadDepartments = async () => {
    const savedDepartments = localStorage.getItem('crm_departments');
    if (savedDepartments) {
      setDepartments(JSON.parse(savedDepartments));
    } else {
      // Initialize with default departments
      const defaultDepartments: Department[] = [
        {
          id: "dept-1",
          name: "Kinh doanh",
          description: "Phòng ban phụ trách bán hàng và phát triển khách hàng",
          manager: "Nguyễn Văn Nam",
          managerId: "emp-1",
          memberCount: 8,
          budget: 500000000,
          status: "active",
          goals: ["Tăng doanh thu 25%", "Mở rộng thị trường mới", "Cải thiện chất lượng dịch vụ"],
          location: "Tầng 2, Tòa nhà A",
          createdAt: "2023-01-15",
          updatedAt: "2024-01-15",
          color: "#3B82F6"
        },
        {
          id: "dept-2",
          name: "Marketing",
          description: "Phòng ban phụ trách marketing và truyền thông",
          manager: "Trần Thị Lan",
          managerId: "emp-2",
          memberCount: 5,
          budget: 300000000,
          status: "active",
          goals: ["Tăng nhận diện thương hiệu", "Phát triển kênh digital", "Tăng tương tác khách hàng"],
          location: "Tầng 3, Tòa nhà A",
          createdAt: "2023-02-01",
          updatedAt: "2024-01-10",
          color: "#10B981"
        },
        {
          id: "dept-3",
          name: "Kỹ thuật",
          description: "Phòng ban phụ trách phát triển sản phẩm và kỹ thuật",
          manager: "Lê Văn Phong",
          managerId: "emp-3",
          memberCount: 12,
          budget: 800000000,
          status: "active",
          goals: ["Phát triển sản phẩm mới", "Cải thiện hiệu suất hệ thống", "Tự động hóa quy trình"],
          location: "Tầng 4, Tòa nhà B",
          createdAt: "2023-01-20",
          updatedAt: "2024-01-12",
          color: "#8B5CF6"
        },
        {
          id: "dept-4",
          name: "Nhân sự",
          description: "Phòng ban phụ trách quản lý nhân sự và phát triển tổ chức",
          manager: "Phạm Thị Mai",
          managerId: "emp-4",
          memberCount: 4,
          budget: 200000000,
          status: "active",
          goals: ["Tuyển dụng nhân tài", "Đào tạo phát triển", "Xây dựng văn hóa công ty"],
          location: "Tầng 1, Tòa nhà A",
          createdAt: "2023-03-01",
          updatedAt: "2024-01-08",
          color: "#F59E0B"
        }
      ];
      setDepartments(defaultDepartments);
      localStorage.setItem('crm_departments', JSON.stringify(defaultDepartments));
    }
  };

  const loadUsers = async () => {
    try {
      const usersData = await DataService.loadUsers();
      setUsers(usersData);
    } catch (error) {
      console.error("Error loading users:", error);
    }
  };

  const loadStats = () => {
    // Mock stats for departments
    const stats: Record<string, DepartmentStats> = {
      "dept-1": {
        totalEmployees: 8,
        totalCustomers: 150,
        activeTasks: 25,
        completedTasks: 87,
        monthlyRevenue: 450000000,
        performance: 92
      },
      "dept-2": {
        totalEmployees: 5,
        totalCustomers: 80,
        activeTasks: 15,
        completedTasks: 45,
        monthlyRevenue: 180000000,
        performance: 88
      },
      "dept-3": {
        totalEmployees: 12,
        totalCustomers: 30,
        activeTasks: 35,
        completedTasks: 120,
        monthlyRevenue: 200000000,
        performance: 95
      },
      "dept-4": {
        totalEmployees: 4,
        totalCustomers: 0,
        activeTasks: 8,
        completedTasks: 22,
        monthlyRevenue: 0,
        performance: 85
      }
    };
    setDepartmentStats(stats);
  };

  const saveDepartments = (updatedDepartments: Department[]) => {
    localStorage.setItem('crm_departments', JSON.stringify(updatedDepartments));
    setDepartments(updatedDepartments);
  };

  const filteredDepartments = departments.filter((dept) => {
    const matchesSearch = 
      dept.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dept.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dept.manager.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || dept.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const DepartmentForm = ({ department, isEdit = false }: { department?: Department; isEdit?: boolean }) => {
    const [formData, setFormData] = useState({
      name: department?.name || "",
      description: department?.description || "",
      managerId: department?.managerId || "",
      budget: department?.budget || 0,
      status: department?.status || "active",
      goals: department?.goals?.join(", ") || "",
      location: department?.location || "",
      color: department?.color || "#3B82F6"
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      
      if (!formData.name.trim() || !formData.description.trim()) {
        toast({
          title: "Lỗi validation",
          description: "Vui lòng điền đầy đủ thông tin bắt buộc",
          variant: "destructive",
        });
        return;
      }

      const manager = users.find(u => u.id === formData.managerId);
      const goalsArray = formData.goals.split(",").map(g => g.trim()).filter(g => g.length > 0);

      if (isEdit && department) {
        const updatedDepartment: Department = {
          ...department,
          name: formData.name,
          description: formData.description,
          manager: manager?.name || "",
          managerId: formData.managerId,
          budget: formData.budget,
          status: formData.status as "active" | "inactive",
          goals: goalsArray,
          location: formData.location,
          color: formData.color,
          updatedAt: new Date().toISOString().split("T")[0],
        };

        const updatedDepartments = departments.map(d => 
          d.id === department.id ? updatedDepartment : d
        );
        saveDepartments(updatedDepartments);
        setIsEditDialogOpen(false);
        
        toast({
          title: "✅ Cập nhật thành công",
          description: `Đã cập nhật phòng ban ${formData.name}`,
        });
      } else {
        const newDepartment: Department = {
          id: `dept-${Date.now()}`,
          name: formData.name,
          description: formData.description,
          manager: manager?.name || "",
          managerId: formData.managerId,
          memberCount: 0,
          budget: formData.budget,
          status: formData.status as "active" | "inactive",
          goals: goalsArray,
          location: formData.location,
          color: formData.color,
          createdAt: new Date().toISOString().split("T")[0],
          updatedAt: new Date().toISOString().split("T")[0],
        };

        saveDepartments([...departments, newDepartment]);
        setIsCreateDialogOpen(false);
        
        toast({
          title: "✅ Tạo thành công",
          description: `Đã tạo phòng ban ${formData.name}`,
        });
      }
    };

    const departmentColors = [
      "#3B82F6", "#10B981", "#8B5CF6", "#F59E0B", 
      "#EF4444", "#06B6D4", "#84CC16", "#F97316"
    ];

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Tên phòng ban *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Nhập tên phòng ban"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="manager">Trưởng phòng</Label>
            <Select
              value={formData.managerId}
              onValueChange={(value) => setFormData(prev => ({ ...prev, managerId: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Chọn trưởng phòng" />
              </SelectTrigger>
              <SelectContent>
                {users.filter(u => u.role === "employee").map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Mô tả *</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            placeholder="Nhập mô tả phòng ban"
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="budget">Ngân sách (VNĐ)</Label>
            <Input
              id="budget"
              type="number"
              value={formData.budget}
              onChange={(e) => setFormData(prev => ({ ...prev, budget: parseInt(e.target.value) || 0 }))}
              placeholder="Nhập ngân sách"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="location">Vị trí</Label>
            <Input
              id="location"
              value={formData.location}
              onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
              placeholder="Nhập vị trí văn phòng"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="goals">Mục tiêu (phân cách bằng dấu phẩy)</Label>
          <Textarea
            id="goals"
            value={formData.goals}
            onChange={(e) => setFormData(prev => ({ ...prev, goals: e.target.value }))}
            placeholder="Nhập các mục tiêu của phòng ban"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="status">Trạng thái</Label>
            <Select
              value={formData.status}
              onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Hoạt động</SelectItem>
                <SelectItem value="inactive">Tạm dừng</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Màu sắc</Label>
            <div className="flex gap-2">
              {departmentColors.map((color) => (
                <button
                  key={color}
                  type="button"
                  className={`w-8 h-8 rounded-full border-2 ${
                    formData.color === color ? "border-gray-600" : "border-gray-300"
                  }`}
                  style={{ backgroundColor: color }}
                  onClick={() => setFormData(prev => ({ ...prev, color }))}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              if (isEdit) {
                setIsEditDialogOpen(false);
              } else {
                setIsCreateDialogOpen(false);
              }
            }}
          >
            Hủy
          </Button>
          <Button type="submit">
            {isEdit ? "Cập nhật" : "Tạo phòng ban"}
          </Button>
        </div>
      </form>
    );
  };

  const deleteDepartment = (departmentId: string) => {
    const updatedDepartments = departments.filter(d => d.id !== departmentId);
    saveDepartments(updatedDepartments);
    toast({
      title: "Xóa thành công",
      description: "Phòng ban đã được xóa khỏi hệ thống",
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount);
  };

  if (user?.role !== "admin") {
    return (
      <div className="p-8 text-center">
        <Building2 className="h-16 w-16 mx-auto mb-4 text-gray-400" />
        <h2 className="text-xl font-semibold mb-2">Không có quyền truy cập</h2>
        <p className="text-gray-600">Chỉ Admin mới có thể quản lý phòng ban</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tổng phòng ban</p>
                <p className="text-2xl font-bold">{departments.length}</p>
              </div>
              <Building2 className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tổng nhân viên</p>
                <p className="text-2xl font-bold text-green-600">
                  {departments.reduce((sum, dept) => sum + dept.memberCount, 0)}
                </p>
              </div>
              <Users className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tổng ngân sách</p>
                <p className="text-2xl font-bold text-purple-600">
                  {formatCurrency(departments.reduce((sum, dept) => sum + dept.budget, 0))}
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Hiệu suất TB</p>
                <p className="text-2xl font-bold text-orange-600">
                  {Math.round(Object.values(departmentStats).reduce((sum, stat) => sum + stat.performance, 0) / Object.keys(departmentStats).length)}%
                </p>
              </div>
              <Award className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Management */}
      <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-blue-600" />
                Quản lý phòng ban
              </CardTitle>
              <CardDescription>
                Tạo, chỉnh sửa và quản lý các phòng ban trong tổ chức
              </CardDescription>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Tạo phòng ban
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Tạo phòng ban mới</DialogTitle>
                  <DialogDescription>
                    Điền thông tin để tạo phòng ban mới
                  </DialogDescription>
                </DialogHeader>
                <DepartmentForm />
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {/* Search and Filter */}
          <div className="flex gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Tìm kiếm phòng ban..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả trạng thái</SelectItem>
                <SelectItem value="active">Hoạt động</SelectItem>
                <SelectItem value="inactive">Tạm dừng</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Departments Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDepartments.map((department) => {
              const stats = departmentStats[department.id];
              return (
                <Card key={department.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded-full"
                          style={{ backgroundColor: department.color }}
                        />
                        <div>
                          <CardTitle className="text-lg">{department.name}</CardTitle>
                          <Badge variant={department.status === "active" ? "default" : "secondary"}>
                            {department.status === "active" ? "Hoạt động" : "Tạm dừng"}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedDepartment(department);
                            setIsEditDialogOpen(true);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm" className="hover:bg-red-50">
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Xác nhận xóa phòng ban</AlertDialogTitle>
                              <AlertDialogDescription>
                                Bạn có chắc chắn muốn xóa phòng ban {department.name}? 
                                Hành động này không thể hoàn tác.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Hủy</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteDepartment(department.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Xóa phòng ban
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-gray-600">{department.description}</p>
                    
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <UserCheck className="h-4 w-4 text-blue-600" />
                        <span>Trưởng phòng: {department.manager || "Chưa có"}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Users className="h-4 w-4 text-green-600" />
                        <span>{department.memberCount} nhân viên</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Briefcase className="h-4 w-4 text-purple-600" />
                        <span>Ngân sách: {formatCurrency(department.budget)}</span>
                      </div>
                    </div>

                    {/* Stats */}
                    {stats && (
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="bg-blue-50 p-2 rounded">
                          <div className="font-medium text-blue-700">Khách hàng</div>
                          <div className="text-blue-600">{stats.totalCustomers}</div>
                        </div>
                        <div className="bg-green-50 p-2 rounded">
                          <div className="font-medium text-green-700">Công việc</div>
                          <div className="text-green-600">{stats.activeTasks}</div>
                        </div>
                        <div className="bg-purple-50 p-2 rounded">
                          <div className="font-medium text-purple-700">Doanh thu</div>
                          <div className="text-purple-600">{formatCurrency(stats.monthlyRevenue)}</div>
                        </div>
                        <div className="bg-orange-50 p-2 rounded">
                          <div className="font-medium text-orange-700">Hiệu suất</div>
                          <div className="text-orange-600">{stats.performance}%</div>
                        </div>
                      </div>
                    )}

                    {/* Goals */}
                    {department.goals.length > 0 && (
                      <div>
                        <div className="text-sm font-medium mb-2 flex items-center gap-1">
                          <Target className="h-4 w-4" />
                          Mục tiêu:
                        </div>
                        <div className="space-y-1">
                          {department.goals.slice(0, 2).map((goal, index) => (
                            <div key={index} className="text-xs bg-gray-50 p-2 rounded">
                              {goal}
                            </div>
                          ))}
                          {department.goals.length > 2 && (
                            <div className="text-xs text-gray-500">
                              +{department.goals.length - 2} mục tiêu khác
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {filteredDepartments.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              Không tìm thấy phòng ban nào phù hợp với tiêu chí tìm kiếm.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Chỉnh sửa phòng ban</DialogTitle>
            <DialogDescription>
              Cập nhật thông tin phòng ban
            </DialogDescription>
          </DialogHeader>
          {selectedDepartment && (
            <DepartmentForm department={selectedDepartment} isEdit={true} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
