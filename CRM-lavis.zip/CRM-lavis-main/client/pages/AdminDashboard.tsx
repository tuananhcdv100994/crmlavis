import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import UserManagement from "./UserManagement";
import CustomerManagement from "./CustomerManagement";
import TaskManagement from "./TaskManagement";
import PermissionSettings from "./PermissionSettings";
import GroupChat from "./GroupChat";
import DepartmentManagement from "./DepartmentManagement";
import Reports from "./Reports";
import AIChatbot from "@/components/AIChatbot";
import { DataService } from "@/services/dataService";
import CRMTestRunner from "@/utils/testRunner";
import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users,
  Building2,
  ClipboardList,
  MessageSquare,
  BarChart3,
  UserPlus,
  Settings,
  LogOut,
  Paintbrush2,
  Phone,
  Mail,
  Calendar,
  TrendingUp,
  Activity,
  CheckCircle,
  Shield,
  Download,
  Database,
  FileText,
  Upload,
} from "lucide-react";

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [customers, setCustomers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [activeTab, setActiveTab] = useState("overview");

  if (!user || user.role !== "admin") {
    return <Navigate to="/login" replace />;
  }

  // Load real-time data and start backup service
  useEffect(() => {
    const loadData = async () => {
      try {
        // Load data from persistent files first, fallback to localStorage
        const [customersData, tasksData, usersData] = await Promise.all([
          DataService.loadCustomers(),
          DataService.loadTasks(),
          DataService.loadUsers()
        ]);

        setCustomers(customersData);
        setTasks(tasksData);
        setUsers(usersData);

        console.log('Loaded real data:', {
          customers: customersData.length,
          tasks: tasksData.length,
          users: usersData.length
        });
      } catch (error) {
        console.error("Error loading data:", error);
      }
    };

    loadData();

    // Data loaded successfully

    return () => clearInterval(interval);
  }, []);

  // Calculate real-time statistics with accurate data
  const totalCustomers = customers.length;
  const potentialCustomers = customers.filter(c => c.status === "potential").length;
  const consultingCustomers = customers.filter(c => c.status === "consulting").length;
  const convertedCustomers = customers.filter(c => c.status === "customer").length;

  // Task statistics
  const totalTasks = tasks.length;
  const activeTasks = tasks.filter(task => task.status === "in-progress" || task.status === "pending").length;
  const completedTasks = tasks.filter(task => task.status === "completed").length;
  const overdueTasks = tasks.filter(task => task.status === "overdue").length;

  // User statistics
  const totalUsers = users.length;
  const activeEmployees = users.filter(user => user.role === "employee" && user.isActive).length;

  // Revenue calculation from converted customers
  const totalRevenue = customers
    .filter(customer => customer.status === "customer" && customer.estimatedValue)
    .reduce((sum, customer) => sum + (customer.estimatedValue || 0), 0);

  const potentialRevenue = customers
    .filter(customer => (customer.status === "potential" || customer.status === "consulting") && customer.estimatedValue)
    .reduce((sum, customer) => sum + (customer.estimatedValue || 0), 0);

  // Calculate growth percentages based on actual data
  const customerGrowth = totalCustomers > 0 ? Math.round((convertedCustomers / totalCustomers) * 100) : 0;
  const taskCompletionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  const activeUserRate = totalUsers > 1 ? Math.round((activeEmployees / (totalUsers - 1)) * 100) : 0; // -1 for admin
  const revenueGrowth = potentialRevenue > 0 ? Math.round((totalRevenue / (totalRevenue + potentialRevenue)) * 100) : 0;

  const stats = [
    {
      label: "Tổng khách hàng",
      value: totalCustomers.toString(),
      change: `${customerGrowth}% đã chuyển đổi`,
      icon: Users,
      color: "text-blue-600",
    },
    {
      label: "Dự án đang thực hiện",
      value: activeTasks.toString(),
      change: `${taskCompletionRate}% hoàn thành`,
      icon: ClipboardList,
      color: "text-green-600",
    },
    {
      label: "Nhân viên hoạt động",
      value: activeEmployees.toString(),
      change: `${activeUserRate}% đang làm việc`,
      icon: Activity,
      color: "text-purple-600",
    },
    {
      label: "Doanh thu thực tế",
      value: totalRevenue > 0 ? `${(totalRevenue / 1000000000).toFixed(1)}B VND` : "0 VND",
      change: `${revenueGrowth}% từ tiềm năng`,
      icon: TrendingUp,
      color: "text-cyan-600",
    },
  ];

  // Get recent customers from real data
  const recentCustomers = customers
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 3)
    .map(customer => ({
      id: customer.id,
      name: customer.name,
      contact: customer.contactPerson,
      phone: customer.phone,
      status: customer.status === "potential" ? "Tiềm năng" :
              customer.status === "consulting" ? "Đang tư vấn" :
              customer.status === "customer" ? "Đã ký HĐ" : "Không tiềm năng"
    }));

  // Get recent tasks from real data
  const recentTasks = tasks
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 3)
    .map(task => ({
      id: task.id,
      title: task.title,
      assignee: task.assigneeNames?.[0] || "Chưa gán",
      status: task.status === "pending" ? "Chờ duyệt" :
              task.status === "in-progress" ? "Đang thực hiện" :
              task.status === "completed" ? "Hoàn thành" : "Quá hạn",
      priority: task.priority === "high" ? "Cao" :
                task.priority === "medium" ? "Trung bình" : "Thấp"
    }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 via-blue-100 via-purple-100 to-pink-100 relative">
      {/* Nature background overlay */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-gradient-to-r from-green-400/30 via-blue-500/30 via-purple-500/30 to-pink-500/30"></div>
        <div className="absolute top-10 left-10 w-32 h-32 bg-yellow-300/40 rounded-full blur-3xl"></div>
        <div className="absolute top-32 right-20 w-40 h-40 bg-green-400/40 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-1/4 w-36 h-36 bg-blue-400/40 rounded-full blur-3xl"></div>
        <div className="absolute bottom-40 right-1/3 w-28 h-28 bg-purple-400/40 rounded-full blur-3xl"></div>
      </div>
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2Fa0178697b81a454483dcf391dc368cc9%2Fb3b4f2316e6b4f0cbaff901a9272dd93?format=webp&width=800"
                alt="Lavis Holding Logo"
                className="h-10 w-auto object-contain"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  CRM
                </h1>
                <p className="text-sm text-gray-600">
                  Bảng điều khiển quản trị
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <Badge variant="secondary" className="text-xs">
                  <Settings className="h-3 w-3 mr-1" />
                  {user.role === "admin" ? "Quản trị viên" : "Nhân viên"}
                </Badge>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={logout}
                className="hover:bg-red-50 hover:border-red-300 hover:text-red-600"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Đăng xuất
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 relative z-10">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl hover:shadow-2xl hover:bg-white/80 transition-all duration-300 hover:scale-105"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      {stat.label}
                    </p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">
                      {stat.value}
                    </p>
                    <p
                      className={`text-sm mt-1 ${stat.change.startsWith("+") ? "text-green-600" : "text-red-600"}`}
                    >
                      {stat.change} so với tháng trước
                    </p>
                  </div>
                  <div
                    className={`p-3 rounded-full bg-gradient-to-br from-blue-100 to-cyan-100`}
                  >
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-10 lg:w-fit bg-white/35 backdrop-blur-md border border-white/15">
            <TabsTrigger value="overview">Tổng quan</TabsTrigger>
            <TabsTrigger value="users">Quản lý User</TabsTrigger>
            <TabsTrigger value="customers">Khách hàng</TabsTrigger>
            <TabsTrigger value="tasks">Giao việc</TabsTrigger>
            <TabsTrigger value="chat">Chat nhóm</TabsTrigger>
            <TabsTrigger value="departments">Phòng ban</TabsTrigger>
            <TabsTrigger value="reports">Báo cáo</TabsTrigger>
            <TabsTrigger value="permissions">Quyền hạn</TabsTrigger>
            <TabsTrigger value="settings">Cài đặt</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Customers */}
              <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-blue-600" />
                    Khách hàng mới nhất
                  </CardTitle>
                  <CardDescription>
                    Danh sách khách hàng được thêm gần đây
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentCustomers.map((customer) => (
                      <div
                        key={customer.id}
                        className="flex items-center justify-between p-3 bg-white/50 rounded-lg"
                      >
                        <div>
                          <p className="font-medium text-gray-900">
                            {customer.name}
                          </p>
                          <p className="text-sm text-gray-600 flex items-center gap-1">
                            <Phone className="h-3 w-3" />
                            {customer.contact} - {customer.phone}
                          </p>
                        </div>
                        <Badge
                          variant={
                            customer.status === "Đã k�� HĐ"
                              ? "default"
                              : customer.status === "Đang tư vấn"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {customer.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                  <Button
                    className="w-full mt-4"
                    variant="outline"
                    onClick={() => setActiveTab("customers")}
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Thêm khách hàng mới
                  </Button>
                </CardContent>
              </Card>

              {/* Recent Tasks */}
              <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ClipboardList className="h-5 w-5 text-green-600" />
                    Công việc gần đây
                  </CardTitle>
                  <CardDescription>
                    Trạng thái các công việc được giao
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentTasks.map((task) => (
                      <div
                        key={task.id}
                        className="flex items-center justify-between p-3 bg-white/50 rounded-lg"
                      >
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">
                            {task.title}
                          </p>
                          <p className="text-sm text-gray-600">
                            {task.assignee}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge
                            variant={
                              task.priority === "Cao"
                                ? "destructive"
                                : task.priority === "Trung bình"
                                  ? "secondary"
                                  : "outline"
                            }
                            className="text-xs"
                          >
                            {task.priority}
                          </Badge>
                          <Badge
                            variant={
                              task.status === "Hoàn thành"
                                ? "default"
                                : "outline"
                            }
                          >
                            {task.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button
                    className="w-full mt-4"
                    variant="outline"
                    onClick={() => setActiveTab("tasks")}
                  >
                    <ClipboardList className="h-4 w-4 mr-2" />
                    Giao việc mới
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users">
            <UserManagement />
          </TabsContent>

          {/* Other tabs content placeholders */}
          <TabsContent value="customers">
            <CustomerManagement />
          </TabsContent>

          <TabsContent value="tasks">
            <TaskManagement />
          </TabsContent>

          <TabsContent value="chat">
            <GroupChat />
          </TabsContent>

          <TabsContent value="permissions">
            <PermissionSettings />
          </TabsContent>

          <TabsContent value="employees">
            <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
              <CardHeader>
                <CardTitle>Quản lý nhân vi��n</CardTitle>
                <CardDescription>
                  Danh sách nhân viên và phân quyền
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center py-8">
                  T��nh năng quản lý nhân viên đang được phát triển...
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="departments">
            <DepartmentManagement />
          </TabsContent>

          <TabsContent value="reports">
            <Reports />
          </TabsContent>


          <TabsContent value="settings">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5 text-blue-600" />
                    Cài đặt hệ thống
                  </CardTitle>
                  <CardDescription>
                    Quản lý cài đặt và cấu hình hệ thống
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-white/50 rounded-lg">
                    <div>
                      <p className="font-medium">Tích hợp AI</p>
                      <p className="text-sm text-gray-600">
                        Google Gemini AI được kích hoạt
                      </p>
                    </div>
                    <Badge>Đang hoạt động</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-white/50 rounded-lg">
                    <div>
                      <p className="font-medium">Chatbot AI</p>
                      <p className="text-sm text-gray-600">
                        Hỗ trợ khách hàng tự động
                      </p>
                    </div>
                    <Badge variant="secondary">Sẵn sàng</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-white/50 rounded-lg">
                    <div>
                      <p className="font-medium">Thông báo thời gian thực</p>
                      <p className="text-sm text-gray-600">
                        Cập nhật trạng thái ngay lập tức
                      </p>
                    </div>
                    <Badge>Bật</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-green-600" />
                    Bảo mật và quyền hạn
                  </CardTitle>
                  <CardDescription>
                    Quản lý phân quyền và bảo mật
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <p className="font-medium">Quyền tạo khách hàng</p>
                    <div className="text-sm text-gray-600">
                      Chỉ phòng ban: <strong>Kinh doanh, Marketing</strong>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="font-medium">Quyền tạo task</p>
                    <div className="text-sm text-gray-600">
                      Admin và người được phân quyền
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="font-medium">Thông tin tài khoản Admin</p>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div>
                        Tên đăng nhập: <strong>tuananhcdv</strong>
                      </div>
                      <div>
                        Vai trò: <strong>Quản trị viên</strong>
                      </div>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    onClick={logout}
                    className="w-full hover:bg-red-50 hover:border-red-300 hover:text-red-600"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Đăng xuất khỏi tài khoản Admin
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-800">
                    <Settings className="h-5 w-5" />
                    Debug Admin Functions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    variant="outline"
                    onClick={() => {
                      console.log("=== ADMIN DEBUG INFO ===");
                      console.log("Current user:", user);
                      console.log("User permissions:", user?.permissions);
                      console.log("Admin role:", user?.role === "admin");
                      console.log("Can add customers:", user?.permissions?.includes("create_customers"));
                      console.log("Can add users:", user?.permissions?.includes("create_users"));
                      console.log("LocalStorage users:", localStorage.getItem("crm_users"));
                      console.log("LocalStorage customers:", localStorage.getItem("crm_customers"));
                      console.log("LocalStorage tasks:", localStorage.getItem("crm_tasks"));
                    }}
                    className="w-full"
                  >
                    Log Debug Info
                  </Button>
                  <Button
                    variant="outline"
                    onClick={async () => {
                      const results = await CRMTestRunner.runAllTests();
                      alert(`Test Results:\n✅ User Created: ${results.userCreated}\n✅ Customer Created: ${results.customerCreated}\n✅ Task Created: ${results.taskCreated}\n\nCheck console for detailed logs!`);
                    }}
                    className="w-full bg-green-50 hover:bg-green-100"
                  >
                    🚀 Run All CRM Tests
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      CRMTestRunner.cleanupTestData();
                      alert("Test data cleaned up!");
                    }}
                    className="w-full bg-yellow-50 hover:bg-yellow-100"
                  >
                    🧹 Clean Test Data
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      localStorage.clear();
                      window.location.reload();
                    }}
                    className="w-full hover:bg-red-50"
                  >
                    Clear All Data & Reload
                  </Button>
                </CardContent>
              </Card>

            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* AI Chatbot */}
      <AIChatbot
        isOpen={isChatbotOpen}
        onToggle={() => setIsChatbotOpen(!isChatbotOpen)}
        context="general"
      />
    </div>
  );
}
