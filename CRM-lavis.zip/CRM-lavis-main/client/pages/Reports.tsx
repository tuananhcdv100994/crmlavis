import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart3,
  PieChart,
  TrendingUp,
  TrendingDown,
  Users,
  Target,
  Calendar,
  Download,
  FileText,
  DollarSign,
  Activity,
  Award,
  Clock,
  CheckCircle,
  AlertCircle,
  Building2,
  UserCheck,
  Briefcase,
  LineChart,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { DataService } from "@/services/dataService";

interface ReportData {
  customers: any[];
  tasks: any[];
  users: any[];
  departments: any[];
}

interface CustomerReport {
  total: number;
  newThisMonth: number;
  activeCustomers: number;
  byStatus: Record<string, number>;
  bySource: Record<string, number>;
  byDepartment: Record<string, number>;
  growth: number;
}

interface TaskReport {
  total: number;
  completed: number;
  inProgress: number;
  pending: number;
  overdue: number;
  completionRate: number;
  avgCompletionTime: number;
  byPriority: Record<string, number>;
  byDepartment: Record<string, number>;
}

interface RevenueReport {
  totalRevenue: number;
  monthlyRevenue: number;
  quarterlyRevenue: number;
  yearlyRevenue: number;
  growth: number;
  byDepartment: Record<string, number>;
  byMonth: Record<string, number>;
}

interface UserReport {
  totalUsers: number;
  activeUsers: number;
  newUsersThisMonth: number;
  byDepartment: Record<string, number>;
  byRole: Record<string, number>;
  performance: Record<string, number>;
}

export default function Reports() {
  const { user } = useAuth();
  const [reportData, setReportData] = useState<ReportData>({
    customers: [],
    tasks: [],
    users: [],
    departments: []
  });
  const [timeRange, setTimeRange] = useState("month");
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadReportData();
  }, []);

  const loadReportData = async () => {
    setIsLoading(true);
    try {
      const [customers, tasks, users] = await Promise.all([
        DataService.loadCustomers(),
        DataService.loadTasks(),
        DataService.loadUsers()
      ]);

      const departments = JSON.parse(localStorage.getItem('crm_departments') || '[]');

      setReportData({
        customers: customers || [],
        tasks: tasks || [],
        users: users || [],
        departments: departments || []
      });
    } catch (error) {
      console.error("Error loading report data:", error);
      toast({
        title: "Lỗi tải dữ liệu",
        description: "Không thể tải dữ liệu báo c��o",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generateCustomerReport = (): CustomerReport => {
    const customers = reportData.customers;
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    const newThisMonth = customers.filter(c => {
      const createDate = new Date(c.createdAt);
      return createDate.getMonth() === currentMonth && createDate.getFullYear() === currentYear;
    }).length;

    const byStatus = customers.reduce((acc, customer) => {
      acc[customer.status] = (acc[customer.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const bySource = customers.reduce((acc, customer) => {
      const source = customer.source || "Khác";
      acc[source] = (acc[source] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const byDepartment = customers.reduce((acc, customer) => {
      const assignedUser = reportData.users.find(u => u.id === customer.assignedTo);
      const dept = assignedUser?.department || "Chưa phân công";
      acc[dept] = (acc[dept] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total: customers.length,
      newThisMonth,
      activeCustomers: customers.filter(c => c.status === "active").length,
      byStatus,
      bySource,
      byDepartment,
      growth: customers.length > 0 ? (newThisMonth / customers.length) * 100 : 0
    };
  };

  const generateTaskReport = (): TaskReport => {
    const tasks = reportData.tasks;
    const completed = tasks.filter(t => t.status === "completed").length;
    const inProgress = tasks.filter(t => t.status === "in-progress").length;
    const pending = tasks.filter(t => t.status === "pending").length;
    
    const now = new Date();
    const overdue = tasks.filter(t => {
      const dueDate = new Date(t.dueDate);
      return t.status !== "completed" && dueDate < now;
    }).length;

    const byPriority = tasks.reduce((acc, task) => {
      acc[task.priority] = (acc[task.priority] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const byDepartment = tasks.reduce((acc, task) => {
      const assignedUser = reportData.users.find(u => u.id === task.assignees[0]);
      const dept = assignedUser?.department || "Chưa phân công";
      acc[dept] = (acc[dept] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total: tasks.length,
      completed,
      inProgress,
      pending,
      overdue,
      completionRate: tasks.length > 0 ? (completed / tasks.length) * 100 : 0,
      avgCompletionTime: 3.5, // Mock data
      byPriority,
      byDepartment
    };
  };

  const generateRevenueReport = (): RevenueReport => {
    // Mock revenue data based on departments and performance
    const departmentRevenue = {
      "Kinh doanh": 450000000,
      "Marketing": 180000000,
      "Kỹ thuật": 200000000,
      "Nhân sự": 0
    };

    const monthlyRevenue = {
      "Jan": 120000000,
      "Feb": 140000000,
      "Mar": 160000000,
      "Apr": 180000000,
      "May": 200000000,
      "Jun": 220000000,
      "Jul": 240000000,
      "Aug": 260000000,
      "Sep": 280000000,
      "Oct": 300000000,
      "Nov": 320000000,
      "Dec": 340000000
    };

    const totalRevenue = Object.values(departmentRevenue).reduce((sum, val) => sum + val, 0);

    return {
      totalRevenue,
      monthlyRevenue: 280000000,
      quarterlyRevenue: 840000000,
      yearlyRevenue: totalRevenue,
      growth: 15.8,
      byDepartment: departmentRevenue,
      byMonth: monthlyRevenue
    };
  };

  const generateUserReport = (): UserReport => {
    const users = reportData.users;
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    const newUsersThisMonth = users.filter(u => {
      const createDate = new Date(u.createdAt);
      return createDate.getMonth() === currentMonth && createDate.getFullYear() === currentYear;
    }).length;

    const byDepartment = users.reduce((acc, user) => {
      acc[user.department] = (acc[user.department] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const byRole = users.reduce((acc, user) => {
      acc[user.role] = (acc[user.role] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const performance = {
      "Kinh doanh": 92,
      "Marketing": 88,
      "Kỹ thuật": 95,
      "Nhân sự": 85
    };

    return {
      totalUsers: users.length,
      activeUsers: users.filter(u => u.status === "active").length,
      newUsersThisMonth,
      byDepartment,
      byRole,
      performance
    };
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount);
  };

  const exportReport = (reportType: string) => {
    const data = {
      customers: generateCustomerReport(),
      tasks: generateTaskReport(),
      revenue: generateRevenueReport(),
      users: generateUserReport(),
      exportDate: new Date().toISOString(),
      timeRange,
      department: selectedDepartment
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${reportType}_report_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "✅ Xuất báo cáo thành công",
      description: `Đã tải xuống báo cáo ${reportType}`,
    });
  };

  if (user?.role !== "admin") {
    return (
      <div className="p-8 text-center">
        <BarChart3 className="h-16 w-16 mx-auto mb-4 text-gray-400" />
        <h2 className="text-xl font-semibold mb-2">Không có quyền truy cập</h2>
        <p className="text-gray-600">Chỉ Admin mới có thể xem báo cáo</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Đang tải dữ liệu báo cáo...</p>
        </div>
      </div>
    );
  }

  const customerReport = generateCustomerReport();
  const taskReport = generateTaskReport();
  const revenueReport = generateRevenueReport();
  const userReport = generateUserReport();

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-600" />
                Báo cáo & Thống kê
              </CardTitle>
              <CardDescription>
                Xem báo cáo tổng quan và chi tiết về hoạt động của hệ thống
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-32">
                  <Calendar className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Tuần</SelectItem>
                  <SelectItem value="month">Tháng</SelectItem>
                  <SelectItem value="quarter">Quý</SelectItem>
                  <SelectItem value="year">Năm</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-40">
                  <Building2 className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả phòng ban</SelectItem>
                  {reportData.departments.map((dept: any) => (
                    <SelectItem key={dept.id} value={dept.name}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tổng khách hàng</p>
                <p className="text-2xl font-bold">{customerReport.total}</p>
                <p className="text-xs text-green-600 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +{customerReport.newThisMonth} tháng này
                </p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Công việc hoàn thành</p>
                <p className="text-2xl font-bold text-green-600">{taskReport.completed}</p>
                <p className="text-xs text-gray-500">
                  {taskReport.completionRate.toFixed(1)}% tỷ lệ hoàn thành
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Doanh thu tháng</p>
                <p className="text-2xl font-bold text-purple-600">
                  {formatCurrency(revenueReport.monthlyRevenue)}
                </p>
                <p className="text-xs text-green-600 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +{revenueReport.growth}%
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Nhân viên hoạt động</p>
                <p className="text-2xl font-bold text-orange-600">{userReport.activeUsers}</p>
                <p className="text-xs text-green-600">
                  +{userReport.newUsersThisMonth} người mới
                </p>
              </div>
              <UserCheck className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Reports */}
      <Tabs defaultValue="customers" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="customers">Khách hàng</TabsTrigger>
          <TabsTrigger value="tasks">Công việc</TabsTrigger>
          <TabsTrigger value="revenue">Doanh thu</TabsTrigger>
          <TabsTrigger value="performance">Hiệu suất</TabsTrigger>
        </TabsList>

        {/* Customer Report */}
        <TabsContent value="customers" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Báo cáo khách hàng</h3>
            <Button onClick={() => exportReport('customer')}>
              <Download className="h-4 w-4 mr-2" />
              Xuất báo cáo
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Theo trạng thái</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(customerReport.byStatus).map(([status, count]) => (
                    <div key={status} className="flex justify-between items-center">
                      <span className="capitalize">{status}</span>
                      <Badge variant="secondary">{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Theo nguồn</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(customerReport.bySource).map(([source, count]) => (
                    <div key={source} className="flex justify-between items-center">
                      <span>{source}</span>
                      <Badge variant="secondary">{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Theo phòng ban</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(customerReport.byDepartment).map(([dept, count]) => (
                    <div key={dept} className="flex justify-between items-center">
                      <span>{dept}</span>
                      <Badge variant="secondary">{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Task Report */}
        <TabsContent value="tasks" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Báo cáo công việc</h3>
            <Button onClick={() => exportReport('task')}>
              <Download className="h-4 w-4 mr-2" />
              Xuất báo cáo
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Đang thực hiện</p>
                    <p className="text-2xl font-bold text-blue-600">{taskReport.inProgress}</p>
                  </div>
                  <Activity className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Chờ xử lý</p>
                    <p className="text-2xl font-bold text-yellow-600">{taskReport.pending}</p>
                  </div>
                  <Clock className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Quá hạn</p>
                    <p className="text-2xl font-bold text-red-600">{taskReport.overdue}</p>
                  </div>
                  <AlertCircle className="h-8 w-8 text-red-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Tỷ lệ hoàn thành</p>
                    <p className="text-2xl font-bold text-green-600">{taskReport.completionRate.toFixed(1)}%</p>
                  </div>
                  <Award className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Theo độ ưu tiên</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(taskReport.byPriority).map(([priority, count]) => (
                    <div key={priority} className="flex justify-between items-center">
                      <span className="capitalize">{priority}</span>
                      <Badge 
                        variant={priority === "high" ? "destructive" : priority === "medium" ? "default" : "secondary"}
                      >
                        {count}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Theo phòng ban</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(taskReport.byDepartment).map(([dept, count]) => (
                    <div key={dept} className="flex justify-between items-center">
                      <span>{dept}</span>
                      <Badge variant="secondary">{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Revenue Report */}
        <TabsContent value="revenue" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Báo cáo doanh thu</h3>
            <Button onClick={() => exportReport('revenue')}>
              <Download className="h-4 w-4 mr-2" />
              Xuất báo cáo
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Doanh thu tháng</p>
                    <p className="text-xl font-bold text-green-600">
                      {formatCurrency(revenueReport.monthlyRevenue)}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Doanh thu quý</p>
                    <p className="text-xl font-bold text-blue-600">
                      {formatCurrency(revenueReport.quarterlyRevenue)}
                    </p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Doanh thu năm</p>
                    <p className="text-xl font-bold text-purple-600">
                      {formatCurrency(revenueReport.yearlyRevenue)}
                    </p>
                  </div>
                  <LineChart className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Doanh thu theo phòng ban</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(revenueReport.byDepartment).map(([dept, revenue]) => (
                  <div key={dept} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                    <span className="font-medium">{dept}</span>
                    <span className="font-bold text-green-600">{formatCurrency(revenue)}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance Report */}
        <TabsContent value="performance" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Báo cáo hiệu suất</h3>
            <Button onClick={() => exportReport('performance')}>
              <Download className="h-4 w-4 mr-2" />
              Xuất báo cáo
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Hiệu suất theo phòng ban</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Object.entries(userReport.performance).map(([dept, score]) => (
                    <div key={dept} className="space-y-2">
                      <div className="flex justify-between">
                        <span>{dept}</span>
                        <span className="font-bold">{score}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all"
                          style={{ width: `${score}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Nhân viên theo phòng ban</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(userReport.byDepartment).map(([dept, count]) => (
                    <div key={dept} className="flex justify-between items-center">
                      <span>{dept}</span>
                      <Badge variant="secondary">{count} người</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
