import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import AIChatbot from "@/components/AIChatbot";
import GroupChat from "./GroupChat";
import CustomerManagement from "./CustomerManagement";
import TaskManagement from "./TaskManagement";
import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  ClipboardList,
  MessageSquare,
  Users,
  CheckCircle,
  Clock,
  AlertCircle,
  LogOut,
  Building2,
  Calendar,
  Phone,
  Mail,
  Send,
  Activity,
  TrendingUp,
  BarChart3,
} from "lucide-react";
import { DataService } from "@/services/dataService";

export default function EmployeeDashboard() {
  const { user, logout } = useAuth();
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [tasks, setTasks] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (user.role !== "employee") {
    return <Navigate to="/admin" replace />;
  }

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [tasksData, customersData] = await Promise.all([
        DataService.loadTasks(),
        DataService.loadCustomers()
      ]);

      // Filter data for current user
      const userTasks = tasksData.filter(task => 
        task.assignees.includes(user.id) || 
        task.createdBy === user.id ||
        task.relatedPersons.includes(user.id)
      );
      
      const userCustomers = customersData.filter(customer =>
        customer.assignedTo === user.id || customer.createdBy === user.id
      );

      setTasks(userTasks);
      setCustomers(userCustomers);
    } catch (error) {
      console.error("Error loading data:", error);
    }
  };

  // Calculate statistics
  const stats = {
    totalTasks: tasks.length,
    activeTasks: tasks.filter(t => t.status === "in-progress" || t.status === "pending").length,
    completedTasks: tasks.filter(t => t.status === "completed").length,
    totalCustomers: customers.length,
    activeCustomers: customers.filter(c => c.status === "potential" || c.status === "consulting").length,
    convertedCustomers: customers.filter(c => c.status === "customer").length,
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 via-blue-100 via-purple-100 to-pink-100 relative">
      {/* Nature background overlay */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-gradient-to-r from-green-400/30 via-blue-500/30 via-purple-500/30 to-pink-500/30"></div>
        <div className="absolute top-10 left-10 w-32 h-32 bg-yellow-300/40 rounded-full blur-3xl"></div>
        <div className="absolute top-32 right-20 w-40 h-40 bg-green-400/40 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-1/4 w-36 h-36 bg-blue-400/40 rounded-full blur-3xl"></div>
        <div className="absolute bottom-40 right-1/3 w-28 h-28 bg-purple-400/40 rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2Fa0178697b81a454483dcf391dc368cc9%2Fb3b4f2316e6b4f0cbaff901a9272dd93?format=webp&width=800"
                alt="CRM Logo"
                className="h-10 w-auto object-contain"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  CRM - Nhân viên
                </h1>
                <p className="text-sm text-gray-600">
                  Bảng điều khiển cá nhân
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <Badge variant="secondary" className="text-xs">
                  <Building2 className="h-3 w-3 mr-1" />
                  {user.department || "Nhân viên"}
                </Badge>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={logout}
                className="hover:bg-red-50 hover:border-red-300 hover:text-red-600"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Đăng xuất
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl hover:shadow-2xl hover:bg-white/80 transition-all duration-300 hover:scale-105">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Công việc của tôi</p>
                  <p className="text-2xl font-bold text-blue-600">{stats.totalTasks}</p>
                  <p className="text-sm text-gray-500">
                    {stats.activeTasks} đang thực hiện
                  </p>
                </div>
                <div className="p-3 rounded-full bg-gradient-to-br from-blue-100 to-cyan-100">
                  <ClipboardList className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl hover:shadow-2xl hover:bg-white/80 transition-all duration-300 hover:scale-105">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Hoàn thành</p>
                  <p className="text-2xl font-bold text-green-600">{stats.completedTasks}</p>
                  <p className="text-sm text-gray-500">
                    {stats.totalTasks > 0 ? Math.round((stats.completedTasks / stats.totalTasks) * 100) : 0}% tỷ lệ
                  </p>
                </div>
                <div className="p-3 rounded-full bg-gradient-to-br from-green-100 to-emerald-100">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl hover:shadow-2xl hover:bg-white/80 transition-all duration-300 hover:scale-105">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Khách hàng của tôi</p>
                  <p className="text-2xl font-bold text-purple-600">{stats.totalCustomers}</p>
                  <p className="text-sm text-gray-500">
                    {stats.activeCustomers} đang tương tác
                  </p>
                </div>
                <div className="p-3 rounded-full bg-gradient-to-br from-purple-100 to-violet-100">
                  <Users className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl hover:shadow-2xl hover:bg-white/80 transition-all duration-300 hover:scale-105">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Chuyển đổi</p>
                  <p className="text-2xl font-bold text-cyan-600">{stats.convertedCustomers}</p>
                  <p className="text-sm text-gray-500">
                    {stats.totalCustomers > 0 ? Math.round((stats.convertedCustomers / stats.totalCustomers) * 100) : 0}% thành công
                  </p>
                </div>
                <div className="p-3 rounded-full bg-gradient-to-br from-cyan-100 to-teal-100">
                  <TrendingUp className="h-6 w-6 text-cyan-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:w-fit bg-white/35 backdrop-blur-md border border-white/15">
            <TabsTrigger value="overview">Tổng quan</TabsTrigger>
            <TabsTrigger value="tasks">Công việc</TabsTrigger>
            <TabsTrigger value="customers">Khách hàng</TabsTrigger>
            <TabsTrigger value="chat">Chat nhóm</TabsTrigger>
            <TabsTrigger value="profile">Hồ sơ</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Tasks */}
              <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ClipboardList className="h-5 w-5 text-blue-600" />
                    Task gần đây
                  </CardTitle>
                  <CardDescription>
                    Các công việc được giao mới nhất
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {tasks.slice(0, 3).map((task) => (
                      <div key={task.id} className="p-3 bg-white/50 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-sm">{task.title}</h4>
                          <Badge variant={
                            task.status === "completed" ? "default" :
                            task.status === "in-progress" ? "secondary" : "outline"
                          }>
                            {task.status === "completed" ? "Hoàn thành" :
                             task.status === "in-progress" ? "Đang làm" : "Chờ xử lý"}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-600 mb-2">{task.description?.substring(0, 80)}...</p>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <Calendar className="h-3 w-3" />
                          <span>Hạn: {task.deadline}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button 
                    className="w-full mt-4" 
                    variant="outline"
                    onClick={() => setActiveTab("tasks")}
                  >
                    <ClipboardList className="h-4 w-4 mr-2" />
                    Xem t���t cả công việc
                  </Button>
                </CardContent>
              </Card>

              {/* Recent Customers */}
              <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-green-600" />
                    Khách hàng của tôi
                  </CardTitle>
                  <CardDescription>
                    Khách hàng được phân công cho bạn
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {customers.slice(0, 3).map((customer) => (
                      <div key={customer.id} className="p-3 bg-white/50 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-sm">{customer.name}</h4>
                          <Badge variant={
                            customer.status === "customer" ? "default" :
                            customer.status === "consulting" ? "secondary" : "outline"
                          }>
                            {customer.status === "customer" ? "Khách hàng" :
                             customer.status === "consulting" ? "Tư vấn" : "Tiềm năng"}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <Phone className="h-3 w-3" />
                          <span>{customer.phone}</span>
                          <span>•</span>
                          <span>{customer.industry}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button 
                    className="w-full mt-4" 
                    variant="outline"
                    onClick={() => setActiveTab("customers")}
                  >
                    <Users className="h-4 w-4 mr-2" />
                    Xem tất cả khách hàng
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks">
            <TaskManagement />
          </TabsContent>

          {/* Customers Tab */}
          <TabsContent value="customers">
            <CustomerManagement />
          </TabsContent>


          {/* Chat Tab */}
          <TabsContent value="chat">
            <GroupChat />
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
              <CardHeader>
                <CardTitle>Thông tin cá nhân</CardTitle>
                <CardDescription>
                  Quản lý thông tin tài khoản của bạn
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback className="text-xl">
                        {user.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">
                        {user.name}
                      </h3>
                      <p className="text-gray-600">
                        {user.department || "Nhân viên"}
                      </p>
                      <Badge variant="secondary" className="mt-1">
                        Nhân viên
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Email
                      </label>
                      <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                        <Mail className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">{user.email}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Tên đăng nhập
                      </label>
                      <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                        <Users className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">{user.username}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">
                      Quyền hạn
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {user.permissions?.map((permission) => (
                        <Badge key={permission} variant="outline">
                          {permission}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button variant="outline" className="w-full md:w-auto">
                    Cập nhật thông tin
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* AI Chatbot */}
      <AIChatbot
        isOpen={isChatbotOpen}
        onToggle={() => setIsChatbotOpen(!isChatbotOpen)}
        context="employee"
      />
    </div>
  );
}
