import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { CheckSquare, Plus, Trash2, Edit, Calendar, Clock, User, AlertCircle, Search, Filter, CheckCircle } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Task {
  id: string;
  title: string;
  description: string;
  status: "pending" | "in-progress" | "completed" | "overdue";
  priority: "low" | "medium" | "high";
  deadline: string;
  assignees: string[];
  assigneeNames: string[];
  category: string;
  createdBy: string;
  createdByName: string;
  createdAt: string;
  estimatedHours: number;
  tags: string[];
}

export default function TaskManagement() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  // Check permission
  if (!user || (user.role !== "admin" && !user.permissions?.includes("view_tasks"))) {
    return <Navigate to="/login" replace />;
  }

  // Load tasks on component mount
  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = () => {
    console.log("Loading tasks...");
    try {
      const saved = localStorage.getItem('crm_tasks');
      if (saved) {
        const data = JSON.parse(saved);
        console.log("Loaded tasks:", data.length);
        setTasks(data);
      } else {
        // Create initial sample data
        const sampleTasks: Task[] = [
          {
            id: "task-1",
            title: "Phát triển tính năng quản lý khách hàng",
            description: "Tạo module quản lý thông tin khách hàng với đầy đủ CRUD operations",
            status: "in-progress",
            priority: "high",
            deadline: "2024-02-15",
            assignees: ["admin-1"],
            assigneeNames: ["Nguyễn Văn Nam"],
            category: "Development",
            createdBy: "admin-1",
            createdByName: "Nguyễn Văn Nam",
            createdAt: "2024-01-15",
            estimatedHours: 40,
            tags: ["crm", "frontend", "urgent"],
          },
          {
            id: "task-2",
            title: "Testing hệ thống báo cáo",
            description: "Kiểm tra và đảm bảo tính chính xác của các báo cáo trong hệ thống",
            status: "pending",
            priority: "medium",
            deadline: "2024-01-25",
            assignees: ["admin-1"],
            assigneeNames: ["Nguyễn Văn Nam"],
            category: "Testing",
            createdBy: "admin-1",
            createdByName: "Nguyễn Văn Nam",
            createdAt: "2024-01-12",
            estimatedHours: 16,
            tags: ["testing", "reports"],
          }
        ];
        setTasks(sampleTasks);
        localStorage.setItem('crm_tasks', JSON.stringify(sampleTasks));
        console.log("Created sample tasks:", sampleTasks.length);
      }
    } catch (error) {
      console.error("Error loading tasks:", error);
      setTasks([]);
    }
  };

  const saveTasks = (newTasks: Task[]) => {
    try {
      localStorage.setItem('crm_tasks', JSON.stringify(newTasks));
      setTasks(newTasks);
      console.log("Saved tasks:", newTasks.length);
    } catch (error) {
      console.error("Error saving tasks:", error);
      toast({
        title: "❌ Lỗi lưu dữ liệu",
        description: "Không thể lưu thông tin công việc",
        variant: "destructive",
      });
    }
  };

  const handleCreateTask = (formData: any) => {
    console.log("Creating task:", formData);
    
    // Check permission
    if (user.role !== "admin" && !user.permissions?.includes("create_tasks")) {
      toast({
        title: "❌ Không có quyền",
        description: "Bạn không có quyền tạo công việc",
        variant: "destructive",
      });
      return;
    }

    try {
      const newTask: Task = {
        id: `task-${Date.now()}`,
        ...formData,
        assignees: [user.id],
        assigneeNames: [user.name],
        createdBy: user.id,
        createdByName: user.name,
        createdAt: new Date().toISOString().split('T')[0],
        tags: formData.tags ? formData.tags.split(',').map((tag: string) => tag.trim()) : [],
      };

      const updatedTasks = [...tasks, newTask];
      saveTasks(updatedTasks);

      toast({
        title: "✅ Thành công",
        description: `Đã tạo công việc: ${newTask.title}`,
      });

      setIsCreateDialogOpen(false);
    } catch (error) {
      console.error("Error creating task:", error);
      toast({
        title: "❌ Lỗi",
        description: "Không thể tạo công việc",
        variant: "destructive",
      });
    }
  };

  const handleEditTask = (formData: any) => {
    console.log("Editing task:", formData);
    
    if (!editingTask) return;

    // Check permission
    if (user.role !== "admin" && !user.permissions?.includes("edit_tasks")) {
      toast({
        title: "❌ Không có quyền",
        description: "Bạn không có quyền sửa công việc",
        variant: "destructive",
      });
      return;
    }

    try {
      const updatedTask = { 
        ...editingTask, 
        ...formData,
        tags: formData.tags ? formData.tags.split(',').map((tag: string) => tag.trim()) : [],
      };
      const updatedTasks = tasks.map(t => 
        t.id === editingTask.id ? updatedTask : t
      );
      
      saveTasks(updatedTasks);

      toast({
        title: "✅ Thành công",
        description: `Đã cập nhật công việc: ${updatedTask.title}`,
      });

      setIsEditDialogOpen(false);
      setEditingTask(null);
    } catch (error) {
      console.error("Error editing task:", error);
      toast({
        title: "❌ Lỗi",
        description: "Không thể cập nhật công việc",
        variant: "destructive",
      });
    }
  };

  const handleDeleteTask = (taskId: string) => {
    console.log("Deleting task:", taskId);
    
    // Check permission
    if (user.role !== "admin" && !user.permissions?.includes("delete_tasks")) {
      toast({
        title: "❌ Không có quyền",
        description: "Bạn không có quyền xóa công việc",
        variant: "destructive",
      });
      return;
    }

    try {
      const updatedTasks = tasks.filter(t => t.id !== taskId);
      saveTasks(updatedTasks);

      toast({
        title: "✅ Thành công",
        description: "Đã xóa công việc",
      });
    } catch (error) {
      console.error("Error deleting task:", error);
      toast({
        title: "❌ Lỗi",
        description: "Không thể xóa công việc",
        variant: "destructive",
      });
    }
  };

  const handleUpdateStatus = (taskId: string, newStatus: string) => {
    console.log("Updating task status:", taskId, newStatus);
    
    try {
      const updatedTasks = tasks.map(task => 
        task.id === taskId ? { ...task, status: newStatus as Task['status'] } : task
      );
      saveTasks(updatedTasks);

      toast({
        title: "✅ Cập nhật trạng thái",
        description: "Đã cập nhật trạng thái công việc",
      });
    } catch (error) {
      console.error("Error updating task status:", error);
      toast({
        title: "❌ Lỗi", 
        description: "Không thể cập nhật trạng thái",
        variant: "destructive",
      });
    }
  };

  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = 
      task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === "all" || task.status === filterStatus;
    const matchesPriority = filterPriority === "all" || task.priority === filterPriority;
    
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const stats = {
    total: tasks.length,
    pending: tasks.filter(t => t.status === "pending").length,
    inProgress: tasks.filter(t => t.status === "in-progress").length,
    completed: tasks.filter(t => t.status === "completed").length,
    overdue: tasks.filter(t => t.status === "overdue").length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Quản lý công việc</h1>
          <p className="text-gray-600">Theo dõi và quản lý các công việc trong dự án</p>
        </div>
        
        {(user.role === "admin" || user.permissions?.includes("create_tasks")) && (
          <CreateTaskDialog 
            isOpen={isCreateDialogOpen}
            onOpenChange={setIsCreateDialogOpen}
            onSubmit={handleCreateTask}
          />
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tổng công việc</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <CheckSquare className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Chờ thực hiện</p>
                <p className="text-2xl font-bold text-gray-600">{stats.pending}</p>
              </div>
              <Clock className="h-8 w-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Đang thực hiện</p>
                <p className="text-2xl font-bold text-blue-600">{stats.inProgress}</p>
              </div>
              <AlertCircle className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Hoàn thành</p>
                <p className="text-2xl font-bold text-green-600">{stats.completed}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Quá hạn</p>
                <p className="text-2xl font-bold text-red-600">{stats.overdue}</p>
              </div>
              <AlertCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Tìm kiếm công việc..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả trạng thái</SelectItem>
                <SelectItem value="pending">Chờ thực hiện</SelectItem>
                <SelectItem value="in-progress">Đang thực hiện</SelectItem>
                <SelectItem value="completed">Hoàn thành</SelectItem>
                <SelectItem value="overdue">Quá hạn</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả độ ưu tiên</SelectItem>
                <SelectItem value="high">Cao</SelectItem>
                <SelectItem value="medium">Trung bình</SelectItem>
                <SelectItem value="low">Thấp</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Task List */}
      <div className="space-y-4">
        {filteredTasks.map((task) => (
          <TaskCard
            key={task.id}
            task={task}
            onEdit={(task) => {
              setEditingTask(task);
              setIsEditDialogOpen(true);
            }}
            onDelete={handleDeleteTask}
            onUpdateStatus={handleUpdateStatus}
            canEdit={user.role === "admin" || user.permissions?.includes("edit_tasks")}
            canDelete={user.role === "admin" || user.permissions?.includes("delete_tasks")}
          />
        ))}
      </div>

      {filteredTasks.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <CheckSquare className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium mb-2">Không có công việc</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm ? "Không tìm thấy công việc phù hợp" : "Chưa có công việc nào trong hệ thống"}
            </p>
            {(user.role === "admin" || user.permissions?.includes("create_tasks")) && (
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Tạo công việc đầu tiên
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Edit Dialog */}
      {editingTask && (
        <EditTaskDialog
          task={editingTask}
          isOpen={isEditDialogOpen}
          onOpenChange={setIsEditDialogOpen}
          onSubmit={handleEditTask}
        />
      )}
    </div>
  );
}

// Task Card Component
function TaskCard({ 
  task, 
  onEdit, 
  onDelete, 
  onUpdateStatus,
  canEdit, 
  canDelete 
}: {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
  onUpdateStatus: (id: string, status: string) => void;
  canEdit: boolean;
  canDelete: boolean;
}) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800";
      case "in-progress": return "bg-blue-100 text-blue-800";
      case "pending": return "bg-gray-100 text-gray-800";
      case "overdue": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed": return "Hoàn thành";
      case "in-progress": return "Đang thực hiện";
      case "pending": return "Chờ thực hiện";
      case "overdue": return "Quá hạn";
      default: return status;
    }
  };

  const getPriorityText = (priority: string) => {
    switch (priority) {
      case "high": return "Cao";
      case "medium": return "Trung bình";
      case "low": return "Thấp";
      default: return priority;
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <h3 className="text-lg font-semibold">{task.title}</h3>
              <Badge className={getStatusColor(task.status)}>
                {getStatusText(task.status)}
              </Badge>
              <Badge className={getPriorityColor(task.priority)}>
                {getPriorityText(task.priority)}
              </Badge>
            </div>

            <p className="text-gray-600 mb-4">{task.description}</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span>Deadline: {task.deadline}</span>
                </div>
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span>Phụ trách: {task.assigneeNames.join(", ")}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span>Ước tính: {task.estimatedHours}h</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <CheckSquare className="h-4 w-4" />
                  <span>Danh mục: {task.category}</span>
                </div>
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span>Tạo bởi: {task.createdByName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span>Tạo: {task.createdAt}</span>
                </div>
              </div>
            </div>

            {task.tags && task.tags.length > 0 && (
              <div className="mt-3">
                <div className="flex flex-wrap gap-2">
                  {task.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col gap-2 ml-4">
            {/* Status Update */}
            <Select value={task.status} onValueChange={(value) => onUpdateStatus(task.id, value)}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Chờ thực hiện</SelectItem>
                <SelectItem value="in-progress">Đang thực hiện</SelectItem>
                <SelectItem value="completed">Hoàn thành</SelectItem>
                <SelectItem value="overdue">Quá hạn</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex gap-2">
              {canEdit && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onEdit(task)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
              )}
              {canDelete && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (confirm(`Bạn có chắc muốn xóa công việc "${task.title}"?`)) {
                      onDelete(task.id);
                    }
                  }}
                  className="hover:bg-red-50 hover:border-red-300"
                >
                  <Trash2 className="h-4 w-4 text-red-600" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Create Task Dialog
function CreateTaskDialog({ 
  isOpen, 
  onOpenChange, 
  onSubmit 
}: {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: any) => void;
}) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    status: "pending",
    priority: "medium",
    deadline: "",
    category: "",
    estimatedHours: "",
    tags: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim() || !formData.description.trim()) {
      toast({
        title: "❌ Lỗi",
        description: "Vui lòng điền đầy đủ thông tin bắt buộc",
        variant: "destructive",
      });
      return;
    }

    onSubmit({
      ...formData,
      estimatedHours: parseInt(formData.estimatedHours) || 0,
    });

    // Reset form
    setFormData({
      title: "",
      description: "",
      status: "pending",
      priority: "medium",
      deadline: "",
      category: "",
      estimatedHours: "",
      tags: "",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Tạo công việc
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Tạo công việc mới</DialogTitle>
          <DialogDescription>
            Điền thông tin công việc mới vào form bên dưới
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Tiêu đề công việc *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Nhập tiêu đề công việc"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Mô tả công việc *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Mô tả chi tiết công việc cần thực hiện"
              rows={4}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="priority">Độ ưu tiên</Label>
              <Select value={formData.priority} onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Thấp</SelectItem>
                  <SelectItem value="medium">Trung bình</SelectItem>
                  <SelectItem value="high">Cao</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Trạng thái</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Chờ thực hiện</SelectItem>
                  <SelectItem value="in-progress">Đang thực hiện</SelectItem>
                  <SelectItem value="completed">Hoàn thành</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="deadline">Deadline</Label>
              <Input
                id="deadline"
                type="date"
                value={formData.deadline}
                onChange={(e) => setFormData(prev => ({ ...prev, deadline: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="estimatedHours">Ước tính thời gian (giờ)</Label>
              <Input
                id="estimatedHours"
                type="number"
                value={formData.estimatedHours}
                onChange={(e) => setFormData(prev => ({ ...prev, estimatedHours: e.target.value }))}
                placeholder="0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Danh mục</Label>
            <Input
              id="category"
              value={formData.category}
              onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
              placeholder="Development, Testing, Design..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags (cách nhau bằng dấu phẩy)</Label>
            <Input
              id="tags"
              value={formData.tags}
              onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
              placeholder="urgent, frontend, bug-fix"
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Hủy
            </Button>
            <Button type="submit">
              Tạo công việc
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Edit Task Dialog
function EditTaskDialog({ 
  task,
  isOpen, 
  onOpenChange, 
  onSubmit 
}: {
  task: Task;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: any) => void;
}) {
  const [formData, setFormData] = useState({
    title: task.title,
    description: task.description,
    status: task.status,
    priority: task.priority,
    deadline: task.deadline,
    category: task.category,
    estimatedHours: task.estimatedHours.toString(),
    tags: task.tags.join(", "),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim() || !formData.description.trim()) {
      toast({
        title: "❌ Lỗi",
        description: "Vui lòng điền đầy đủ thông tin bắt buộc",
        variant: "destructive",
      });
      return;
    }

    onSubmit({
      ...formData,
      estimatedHours: parseInt(formData.estimatedHours) || 0,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Chỉnh sửa công việc</DialogTitle>
          <DialogDescription>
            Cập nhật thông tin công việc
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="edit-title">Tiêu đề công việc *</Label>
            <Input
              id="edit-title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Nhập ti��u đề công việc"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-description">Mô tả công việc *</Label>
            <Textarea
              id="edit-description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Mô tả chi tiết công việc cần thực hiện"
              rows={4}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-priority">Độ ưu tiên</Label>
              <Select value={formData.priority} onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Thấp</SelectItem>
                  <SelectItem value="medium">Trung bình</SelectItem>
                  <SelectItem value="high">Cao</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-status">Trạng thái</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Chờ thực hiện</SelectItem>
                  <SelectItem value="in-progress">Đang thực hiện</SelectItem>
                  <SelectItem value="completed">Hoàn thành</SelectItem>
                  <SelectItem value="overdue">Quá hạn</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-deadline">Deadline</Label>
              <Input
                id="edit-deadline"
                type="date"
                value={formData.deadline}
                onChange={(e) => setFormData(prev => ({ ...prev, deadline: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-estimatedHours">Ước tính thời gian (giờ)</Label>
              <Input
                id="edit-estimatedHours"
                type="number"
                value={formData.estimatedHours}
                onChange={(e) => setFormData(prev => ({ ...prev, estimatedHours: e.target.value }))}
                placeholder="0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-category">Danh mục</Label>
            <Input
              id="edit-category"
              value={formData.category}
              onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
              placeholder="Development, Testing, Design..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-tags">Tags (cách nhau bằng dấu phẩy)</Label>
            <Input
              id="edit-tags"
              value={formData.tags}
              onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
              placeholder="urgent, frontend, bug-fix"
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Hủy
            </Button>
            <Button type="submit">
              Cập nhật
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
