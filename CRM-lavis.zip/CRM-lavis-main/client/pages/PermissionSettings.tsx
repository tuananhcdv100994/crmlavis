import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Shield,
  User,
  Settings,
  Lock,
  Unlock,
  Eye,
  Edit,
  Plus,
  Trash2,
  Download,
  Upload,
  FileText,
  Users,
  ClipboardList,
  Building2,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { DataService } from "@/services/dataService";

interface Permission {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: any;
}

interface UserPermission {
  userId: string;
  permissions: string[];
  role: string;
  department: string;
}

export default function PermissionSettings() {
  const { user } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [userPermissions, setUserPermissions] = useState<UserPermission[]>([]);
  const [selectedUser, setSelectedUser] = useState<string>("");
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  // Available permissions
  const availablePermissions: Permission[] = [
    {
      id: "view_customers",
      name: "Xem khách h��ng",
      description: "Xem danh sách kh��ch hàng",
      category: "Khách hàng",
      icon: Eye
    },
    {
      id: "create_customers",
      name: "Tạo khách hàng",
      description: "Thêm khách hàng mới",
      category: "Khách hàng",
      icon: Plus
    },
    {
      id: "edit_customers",
      name: "Sửa khách hàng",
      description: "Chỉnh sửa thông tin khách hàng",
      category: "Khách hàng",
      icon: Edit
    },
    {
      id: "delete_customers",
      name: "Xóa khách hàng",
      description: "Xóa khách hàng khỏi hệ thống",
      category: "Khách hàng",
      icon: Trash2
    },
    {
      id: "view_tasks",
      name: "Xem công việc",
      description: "Xem danh sách công việc",
      category: "Công việc",
      icon: Eye
    },
    {
      id: "create_tasks",
      name: "Tạo công việc",
      description: "Tạo c��ng việc mới",
      category: "Công việc",
      icon: Plus
    },
    {
      id: "edit_tasks",
      name: "Sửa công việc",
      description: "Chỉnh sửa công việc",
      category: "Công việc",
      icon: Edit
    },
    {
      id: "delete_tasks",
      name: "Xóa công việc",
      description: "Xóa công việc",
      category: "Công việc",
      icon: Trash2
    },
    {
      id: "view_users",
      name: "Xem người dùng",
      description: "Xem danh sách người dùng",
      category: "Quản lý",
      icon: Users
    },
    {
      id: "create_users",
      name: "Tạo người dùng",
      description: "Tạo tài khoản người dùng mới",
      category: "Quản lý",
      icon: Plus
    },
    {
      id: "edit_users",
      name: "Sửa người dùng",
      description: "Chỉnh sửa thông tin người dùng",
      category: "Quản lý",
      icon: Edit
    },
    {
      id: "delete_users",
      name: "Xóa người dùng",
      description: "Xóa người dùng khỏi hệ thống",
      category: "Quản lý",
      icon: Trash2
    },
    {
      id: "view_reports",
      name: "Xem báo cáo",
      description: "Xem các báo cáo hệ thống",
      category: "Báo cáo",
      icon: FileText
    },
    {
      id: "export_data",
      name: "Xuất dữ liệu",
      description: "Xuất và tải dữ liệu",
      category: "Báo cáo",
      icon: Download
    },
    {
      id: "system_settings",
      name: "Cài đặt hệ thống",
      description: "Quản lý cài đặt hệ thống",
      category: "Hệ thống",
      icon: Settings
    }
  ];

  // Default permission sets by role
  const defaultPermissionSets = {
    admin: [
      "view_customers", "create_customers", "edit_customers", "delete_customers",
      "view_tasks", "create_tasks", "edit_tasks", "delete_tasks",
      "view_users", "create_users", "edit_users", "delete_users",
      "view_reports", "export_data", "system_settings",
      "view_departments", "create_departments", "edit_departments", "delete_departments",
      "manage_permissions", "manage_chat", "create_groups",
      "all"
    ],
    sales: [
      "view_customers", "create_customers", "edit_customers",
      "view_tasks", "create_tasks", "edit_tasks",
      "view_reports"
    ],
    marketing: [
      "view_customers", "create_customers", "edit_customers",
      "view_tasks", "view_reports"
    ],
    employee: [
      "view_customers", "view_tasks", "view_reports"
    ]
  };

  useEffect(() => {
    loadUsers();
  }, []);

  // Debug logging for admin permissions
  useEffect(() => {
    if (user) {
      console.log('PermissionSettings - Current user:', user);
      console.log('PermissionSettings - User role:', user.role);
      console.log('PermissionSettings - User permissions:', user.permissions);
      console.log('PermissionSettings - Has admin access:', user?.role === "admin" || user?.permissions?.includes("all"));
    }
  }, [user]);

  const loadUsers = async () => {
    try {
      console.log('Loading users from DataService...');
      let usersData = await DataService.loadUsers();
      console.log('Loaded users:', usersData);

      if (!Array.isArray(usersData)) {
        console.error('Invalid users data format:', usersData);
        usersData = [];
      }

      // Ensure admin user exists in the users list
      const adminExists = usersData.find((u: any) => u.role === "admin");
      if (!adminExists && user?.role === "admin") {
        console.log('Adding current admin user to users list');
        const adminUser = {
          ...user,
          permissions: defaultPermissionSets.admin
        };
        usersData = [...usersData, adminUser];
        // Save the updated list
        DataService.saveUsers(usersData);
      }

      // Ensure all admin users have full permissions
      usersData = usersData.map((u: any) => {
        if (u.role === "admin") {
          return {
            ...u,
            permissions: defaultPermissionSets.admin
          };
        }
        return u;
      });

      setUsers(usersData);

      // Initialize user permissions with proper fallback
      const permissions = usersData.map((u: any) => ({
        userId: u.id,
        permissions: Array.isArray(u.permissions) ? u.permissions : getDefaultPermissions(u.role, u.department),
        role: u.role,
        department: u.department
      }));

      console.log('Initialized user permissions:', permissions);
      setUserPermissions(permissions);
    } catch (error) {
      console.error("Error loading users:", error);
      toast({
        title: "❌ Lỗi tải dữ liệu",
        description: "Không thể tải danh sách người dùng",
        variant: "destructive",
      });
    }
  };

  const getDefaultPermissions = (role: string, department: string) => {
    if (role === "admin") return defaultPermissionSets.admin;
    if (department === "Kinh doanh") return defaultPermissionSets.sales;
    if (department === "Marketing") return defaultPermissionSets.marketing;
    return defaultPermissionSets.employee;
  };

  const getUserPermissions = (userId: string) => {
    return userPermissions.find(up => up.userId === userId)?.permissions || [];
  };

  const updateUserPermissions = async (userId: string, newPermissions: string[]) => {
    try {
      console.log('Updating permissions for user:', userId, 'with permissions:', newPermissions);

      // Validate input
      if (!userId || !Array.isArray(newPermissions)) {
        throw new Error('Invalid userId or permissions array');
      }

      // Find the user to update
      const userToUpdate = users.find(u => u.id === userId);
      if (!userToUpdate) {
        throw new Error('User not found');
      }

      // Check if current user is admin
      if (user?.role !== "admin") {
        throw new Error('Only admin can update permissions');
      }

      // For admin users, always ensure they have all permissions
      let finalPermissions = newPermissions;
      if (userToUpdate.role === "admin") {
        finalPermissions = [...new Set([
          ...defaultPermissionSets.admin,
          ...newPermissions,
          "all"
        ])];
      }

      // Update user permissions state first
      const updatedUserPermissions = userPermissions.map(up =>
        up.userId === userId
          ? { ...up, permissions: finalPermissions }
          : up
      );
      setUserPermissions(updatedUserPermissions);

      // Update users array with new permissions
      const updatedUsers = users.map(u =>
        u.id === userId
          ? { ...u, permissions: finalPermissions }
          : u
      );

      console.log('Saving updated users:', updatedUsers);

      // Save to localStorage immediately
      localStorage.setItem('crm_users', JSON.stringify(updatedUsers));

      // Also save through DataService
      try {
        DataService.saveUsers(updatedUsers);
      } catch (saveError) {
        console.warn('DataService save failed, but localStorage save succeeded:', saveError);
      }

      // Update local state
      setUsers(updatedUsers);

      // Update the current user if they updated their own permissions
      if (userId === user?.id) {
        const updatedCurrentUser = updatedUsers.find(u => u.id === user.id);
        if (updatedCurrentUser) {
          localStorage.setItem('crm_user', JSON.stringify(updatedCurrentUser));
        }
      }

      // Force reload để đảm bảo dữ liệu được cập nhật
      setTimeout(() => {
        loadUsers();
      }, 500);

      toast({
        title: "✅ Cập nhật quyền thành công",
        description: `Đã cập nhật ${finalPermissions.length} quyền cho ${userToUpdate.name}`,
      });
    } catch (error) {
      console.error('Error updating permissions:', error);
      toast({
        title: "❌ Lỗi cập nhật quyền",
        description: `Không thể lưu quyền: ${error}`,
        variant: "destructive",
      });
    }
  };

  const PermissionEditDialog = () => {
    const [tempPermissions, setTempPermissions] = useState<string[]>([]);
    const selectedUserData = users.find(u => u.id === selectedUser);

    useEffect(() => {
      if (selectedUser) {
        setTempPermissions(getUserPermissions(selectedUser));
      }
    }, [selectedUser]);

    const handlePermissionChange = (permissionId: string, checked: boolean) => {
      if (checked) {
        setTempPermissions(prev => [...prev, permissionId]);
      } else {
        setTempPermissions(prev => prev.filter(p => p !== permissionId));
      }
    };

    const handleSave = async () => {
      await updateUserPermissions(selectedUser, tempPermissions);
      setIsEditDialogOpen(false);
    };

    const applyPreset = (preset: string) => {
      const presetPermissions = (defaultPermissionSets as any)[preset] || [];
      setTempPermissions(presetPermissions);
    };

    const groupedPermissions = availablePermissions.reduce((acc, permission) => {
      if (!acc[permission.category]) acc[permission.category] = [];
      acc[permission.category].push(permission);
      return acc;
    }, {} as Record<string, Permission[]>);

    return (
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Chỉnh sửa quyền: {selectedUserData?.name}
            </DialogTitle>
            <DialogDescription>
              Ch��n các quyền phù hợp cho người dùng này
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Quick presets */}
            <div>
              <h4 className="font-medium mb-3">Bộ quyền mẫu:</h4>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => applyPreset('employee')}>
                  Nhân viên
                </Button>
                <Button variant="outline" onClick={() => applyPreset('marketing')}>
                  Marketing
                </Button>
                <Button variant="outline" onClick={() => applyPreset('sales')}>
                  Kinh doanh
                </Button>
                <Button variant="outline" onClick={() => applyPreset('admin')}>
                  Admin
                </Button>
              </div>
            </div>

            {/* Permission groups */}
            <div className="space-y-4">
              {Object.entries(groupedPermissions).map(([category, permissions]) => (
                <Card key={category} className="p-4">
                  <h4 className="font-medium mb-3 flex items-center gap-2">
                    <Shield className="h-4 w-4" />
                    {category}
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    {permissions.map((permission) => (
                      <label
                        key={permission.id}
                        className="flex items-center space-x-3 cursor-pointer p-2 rounded hover:bg-gray-50"
                      >
                        <Checkbox
                          checked={tempPermissions.includes(permission.id)}
                          onCheckedChange={(checked) =>
                            handlePermissionChange(permission.id, checked as boolean)
                          }
                        />
                        <div className="flex items-center gap-2">
                          <permission.icon className="h-4 w-4 text-gray-500" />
                          <div>
                            <div className="font-medium text-sm">{permission.name}</div>
                            <div className="text-xs text-gray-500">{permission.description}</div>
                          </div>
                        </div>
                      </label>
                    ))}
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Hủy
            </Button>
            <Button onClick={handleSave}>
              Lưu quyền
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  // Check if user has admin access (role or permission)
  const hasAdminAccess = user?.role === "admin" ||
                         user?.permissions?.includes("all") ||
                         user?.permissions?.includes("manage_permissions");

  if (!hasAdminAccess) {
    return (
      <div className="p-8 text-center">
        <Shield className="h-16 w-16 mx-auto mb-4 text-gray-400" />
        <h2 className="text-xl font-semibold mb-2">Không có quyền truy cập</h2>
        <p className="text-gray-600">Chỉ Admin mới có thể quản lý quyền hệ thống</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Debug Information for Admin */}
      {user?.role === "admin" && (
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-sm text-blue-800">Debug Information (Admin Only)</CardTitle>
          </CardHeader>
          <CardContent className="text-xs text-blue-700">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <strong>Current User:</strong> {user.name} ({user.role})
                <br />
                <strong>User ID:</strong> {user.id}
                <br />
                <strong>Total Permissions:</strong> {user.permissions?.length || 0}
              </div>
              <div>
                <strong>Loaded Users:</strong> {users.length}
                <br />
                <strong>Permission States:</strong> {userPermissions.length}
                <br />
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    console.log("Current state debug:");
                    console.log("Users:", users);
                    console.log("User Permissions:", userPermissions);
                    console.log("Current User:", user);
                  }}
                >
                  Log Debug Info
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="bg-white/35 backdrop-blur-md border border-white/15 shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-600" />
            Quản lý quyền hệ thống
          </CardTitle>
          <CardDescription>
            Cài đặt quyền truy cập cho từng người dùng trong hệ thống
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.filter(userData => userData.role !== "admin" || user?.id === userData.id).map((userData) => (
              <Card key={userData.id} className="p-4 border border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">{userData.name}</h4>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <span>{userData.department}</span>
                        <span>•</span>
                        <Badge variant={userData.role === "admin" ? "default" : "secondary"}>
                          {userData.role === "admin" ? "Admin" : "Nhân viên"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-sm font-medium">
                        {getUserPermissions(userData.id).length} quyền
                      </div>
                      <div className="text-xs text-gray-500">
                        {getUserPermissions(userData.id).includes("create_customers") && "Tạo KH "}
                        {getUserPermissions(userData.id).includes("create_tasks") && "Tạo Task "}
                      </div>
                    </div>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        console.log("=== BUTTON CÀI ĐẶT QUYỀN CLICKED ===");
                        console.log("Selected user ID:", userData.id);
                        console.log("User data:", userData);
                        console.log("Current permissions:", getUserPermissions(userData.id));
                        setSelectedUser(userData.id);
                        setIsEditDialogOpen(true);
                      }}
                    >
                      <Settings className="h-4 w-4 mr-1" />
                      Cài đặt
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      <PermissionEditDialog />
    </div>
  );
}
