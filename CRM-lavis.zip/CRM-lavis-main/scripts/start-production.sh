#!/bin/bash

# Production startup script for Lavis CRM on VPS

echo "🚀 Starting Lavis CRM Production Build..."

# Set environment
export NODE_ENV=production
export PORT=${PORT:-8080}

# Check if dist directory exists
if [ ! -d "dist" ]; then
    echo "❌ dist directory not found. Running build first..."
    npm run build
fi

# Check if server build exists
if [ ! -f "dist/server/node-build.mjs" ]; then
    echo "❌ Server build not found. Running server build..."
    npm run build:server
fi

# Check if client build exists
if [ ! -d "dist/spa" ]; then
    echo "❌ Client build not found. Running client build..."
    npm run build:client
fi

echo "✅ All builds found. Starting server..."

# Start the server
exec node dist/server/node-build.mjs
