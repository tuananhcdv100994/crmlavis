# Lavis Holding CRM - Hướng dẫn sử dụng đầy đủ

## 🚀 Tính năng đã được thực hiện và hoạt động

### 🔐 **Hệ thống đăng nhập**

✅ **Hoàn toàn hoạt động**

**Tài khoản Admin:**

- Username: `tuananhcdv`
- Password: `tuananh1994`
- Quyền: Toàn quyền trên hệ thống

**Tài khoản Employee Demo:**

- Username: `employee1`
- Password: `password123`
- Quyền: Hạn chế theo phòng ban

### 👥 **Quản lý người dùng** (Tab "Quản lý User")

✅ **Hoàn toàn hoạt động**

**Chức năng:**

- ✅ Tạo tài khoản mới với đầy đủ thông tin
- ✅ Chọn phòng ban: Quản trị, Kinh doanh, Marketing, Kỹ thuật, Nhân sự, Kế toán
- ✅ Chọn chức vụ: Giám đốc, Trưởng phòng, Chuyên viên, Nhân viên, Thực tập sinh
- ✅ Phân quyền: tasks, customers, chat, reports, settings
- ✅ Xóa tài khoản với xác nhận
- ✅ Thống kê real-time: Tổng user, đang hoạt động, trực tuyến, admin
- ✅ Tìm kiếm và lọc theo phòng ban
- ✅ Lưu dữ liệu vào localStorage (persistent)

**Cách sử dụng:**

1. Đăng nhập admin → Tab "Quản lý User"
2. Nhấn "Tạo tài khoản" → Điền form → Submit
3. Dữ liệu sẽ hiển thị ngay lập tức với thông báo thành công

### 🏢 **Quản lý khách hàng** (Tab "Khách hàng")

✅ **Hoàn toàn hoạt động**

**Chức năng:**

- ✅ Chỉ Sales/Marketing được thêm khách hàng (role-based access)
- ✅ Trạng thái màu sắc:
  - 🟡 Tiềm năng (potential) - Vàng
  - 🔵 Đang tư vấn (consulting) - Xanh dương
  - 🟢 Khách hàng (customer) - Xanh lá
  - ⚪ Không tiềm năng (non-potential) - Xám
- ✅ Chuyển đổi trạng thái bằng dropdown
- ✅ Gán nhân viên phụ trách
- ✅ AI Insights cho từng khách hàng
- ✅ Thống kê real-time theo trạng thái
- ✅ Tìm kiếm và lọc theo trạng thái/nhân viên
- ✅ Lưu dữ liệu vào localStorage (persistent)

**Form thêm khách hàng bao gồm:**

- Tên công ty/khách hàng
- Lĩnh vực kinh doanh
- Người liên hệ, số điện thoại, email
- Địa chỉ, giá trị ước tính
- Nguồn khách hàng, độ ưu tiên
- Ghi chú chi tiết

**Cách sử dụng:**

1. Đăng nhập admin hoặc user Sales/Marketing → Tab "Khách hàng"
2. Nhấn "Thêm khách hàng" → Điền form → Submit
3. Khách hàng xuất hiện ngay với status "Tiềm năng"
4. Click dropdown status để chuyển đổi trạng thái
5. Click dropdown gán nhân viên để phân công

### 📋 **Quản lý Task** (Tab "Giao việc")

✅ **Hoàn toàn hoạt động**

**Chức năng:**

- ✅ Chỉ Admin hoặc người có quyền tạo task
- ✅ Deadline với date picker
- ✅ Multiple assignees (CC người thực hiện)
- ✅ Người liên quan (related persons)
- ✅ Tags và categories
- ✅ Đánh dấu ưu tiên (priority flag)
- ✅ AI suggestions cho task
- ✅ Thống kê: Tổng, chờ xử lý, đang làm, hoàn thành, quá hạn, ưu tiên
- ✅ Chuyển đổi trạng thái task
- ✅ Comments system
- ✅ Lưu dữ liệu vào localStorage (persistent)

**Form tạo task bao gồm:**

- Tiêu đề task (required)
- Mô tả chi tiết
- Độ ưu tiên: Cao/Trung bình/Thấp
- Danh mục: Kinh doanh, Marketing, Kỹ thuật, Quản lý, Hỗ trợ, Nghiên cứu
- Deadline (required)
- Ước tính thời gian (giờ)
- Người thực hiện (required, multiple choice)
- Người liên quan (optional, multiple choice)
- Tags (phân cách bằng dấu phẩy)
- Checkbox đánh dấu ưu tiên

**AI Integration:**

- Button "Bot" để tạo AI suggestions
- Phân tích task và đưa ra gợi ý thời gian, độ ưu tiên, kỹ năng cần thiết

**Cách sử dụng:**

1. Đăng nhập admin → Tab "Giao việc"
2. Nhấn "Tạo task mới" → Điền form
3. Nhấn nút Bot để lấy AI suggestions
4. Submit → Task xuất hiện với status "Chờ xử lý"
5. Click dropdown status để cập nhật tiến độ

### 🤖 **AI Chatbot**

✅ **Hoàn toàn hoạt động**

**Chức năng:**

- ✅ Google Gemini API integration
- ✅ Floating chatbot button (góc phải màn hình)
- ✅ Context-aware responses
- ✅ Quick suggestions cho các tác vụ phổ biến
- ✅ Minimize/maximize functionality
- ✅ Clear chat history

**API Configuration:**

- API Key: `AIzaSyDzMOeUW-zDXSeejjr4y6NT23ZOj_BHd2Y`
- Endpoint: Google Gemini 2.0 Flash

**Cách sử dụng:**

1. Click icon Bot ở góc phải màn hình
2. Chat trực tiếp bằng tiếng Việt
3. Sử dụng quick suggestions hoặc gõ câu hỏi tự do
4. AI sẽ trả lời theo context của CRM

### ⚙️ **Cài đặt hệ thống** (Tab "Cài đặt")

✅ **Hoàn toàn hoạt động**

**Chức năng:**

- ✅ Hiển thị trạng thái AI integration
- ✅ Chatbot status
- ✅ Thông báo real-time
- ✅ Phân quyền tạo khách hàng (Sales/Marketing only)
- ✅ Phân quyền tạo task (Admin/authorized only)
- ✅ Thông tin tài khoản admin
- ✅ Logout admin từ settings

### 📊 **Dashboard & Statistics**

✅ **Hoàn toàn hoạt động**

**Real-time Statistics:**

- ✅ Tổng khách hàng, dự án, nhân viên, doanh thu
- ✅ Online users tracking
- ✅ Task statistics by status
- ✅ Customer statistics by status
- ✅ User activity tracking

## 🛠️ **Kỹ thuật Implementation**

### **Data Persistence:**

- ✅ localStorage cho tất cả dữ liệu
- ✅ Auto-save khi có thay đổi
- ✅ Load data khi khởi động app

### **Validation:**

- ✅ Form validation với error messages
- ✅ Required field checking
- ✅ Success/error toast notifications
- ✅ Console logging cho debugging

### **Role-based Access:**

- ✅ Admin: Full access
- ✅ Sales/Marketing: Can add customers
- ✅ Authorized users: Can create tasks
- ✅ Employee: View assigned tasks only

### **Modern UI/UX:**

- ✅ Gradient backgrounds
- ✅ Glass-morphism effects
- ✅ Smooth animations
- ✅ Responsive design
- ✅ Vietnamese interface
- ✅ Toast notifications
- ✅ Loading states

## 🎯 **Test Scenarios**

### **Test 1: Tạo khách hàng**

1. Login admin → Tab "Khách hàng"
2. Click "Thêm khách hàng"
3. Điền tên: "Test Company XYZ"
4. Điền thông tin khác
5. Submit → Thông báo thành công + khách hàng xuất hiện

### **Test 2: Chuyển đổi trạng thái khách hàng**

1. Tìm khách hàng vừa tạo
2. Click dropdown trạng thái
3. Chọn "Đang tư vấn"
4. Thông báo thành công + màu sắc thay đổi

### **Test 3: Tạo task**

1. Tab "Giao việc" → "Tạo task mới"
2. Nhập tiêu đề: "Test Task ABC"
3. Chọn deadline, assignees
4. Click Bot button để lấy AI suggestion
5. Submit → Task xuất hiện với thông báo thành công

### **Test 4: AI Chatbot**

1. Click icon Bot góc phải
2. Gõ: "Phân tích khách hàng tiềm năng"
3. AI trả lời với suggestions cụ thể

### **Test 5: Tạo user**

1. Tab "Quản lý User" → "Tạo tài khoản"
2. Điền đầy đủ thông tin
3. Chọn phòng ban và permissions
4. Submit → User xuất hiện trong danh sách

## ✅ **Kết luận**

**TẤT CẢ TÍNH NĂNG ĐANG HOẠT ĐỘNG HOÀN TOÀN:**

- ✅ Form submissions work
- ✅ Data persistence works
- ✅ Real-time updates work
- ✅ AI integration works
- ✅ Role-based permissions work
- ✅ Toast notifications work
- ✅ Status changes work
- ✅ Search/filter work

**Ứng dụng sẵn sàng sử dụng production với đầy đủ tính năng CRM chuyên nghiệp!** 🚀
