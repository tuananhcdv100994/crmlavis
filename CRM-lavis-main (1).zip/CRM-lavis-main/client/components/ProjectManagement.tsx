import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Plus,
  Edit,
  Trash2,
  Calendar,
  DollarSign,
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
  Pause,
  Play,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Project {
  id: string;
  name: string;
  description: string;
  status: "planning" | "in-progress" | "completed" | "on-hold" | "cancelled";
  startDate: string;
  endDate?: string;
  estimatedValue: number;
  actualValue?: number;
  progress: number;
  assignedTo: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

interface ProjectManagementProps {
  customerId: string;
  customerName: string;
  projects: Project[];
  onProjectsChange: (projects: Project[]) => void;
  users: any[];
}

export default function ProjectManagement({
  customerId,
  customerName,
  projects,
  onProjectsChange,
  users
}: ProjectManagementProps) {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  const ProjectForm = ({ project, isEdit = false }: { project?: Project; isEdit?: boolean }) => {
    const [formData, setFormData] = useState({
      name: project?.name || "",
      description: project?.description || "",
      status: project?.status || "planning",
      startDate: project?.startDate || "",
      endDate: project?.endDate || "",
      estimatedValue: project?.estimatedValue?.toString() || "",
      actualValue: project?.actualValue?.toString() || "",
      progress: project?.progress?.toString() || "0",
      assignedTo: project?.assignedTo || "",
      notes: project?.notes || "",
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();

      if (!formData.name.trim()) {
        toast({
          title: "Lỗi validation",
          description: "Vui lòng nhập tên dự án",
          variant: "destructive",
        });
        return;
      }

      if (isEdit && project) {
        const updatedProject: Project = {
          ...project,
          name: formData.name,
          description: formData.description,
          status: formData.status as Project["status"],
          startDate: formData.startDate,
          endDate: formData.endDate || undefined,
          estimatedValue: parseInt(formData.estimatedValue) || 0,
          actualValue: formData.actualValue ? parseInt(formData.actualValue) : undefined,
          progress: parseInt(formData.progress) || 0,
          assignedTo: formData.assignedTo,
          notes: formData.notes,
          updatedAt: new Date().toISOString(),
        };

        const updatedProjects = projects.map(p => 
          p.id === project.id ? updatedProject : p
        );
        onProjectsChange(updatedProjects);
        setEditingProject(null);

        toast({
          title: "✅ Cập nhật thành công",
          description: `Đã cập nhật dự án ${formData.name}`,
        });
      } else {
        const newProject: Project = {
          id: `proj-${Date.now()}`,
          name: formData.name,
          description: formData.description,
          status: formData.status as Project["status"],
          startDate: formData.startDate,
          endDate: formData.endDate || undefined,
          estimatedValue: parseInt(formData.estimatedValue) || 0,
          actualValue: formData.actualValue ? parseInt(formData.actualValue) : undefined,
          progress: parseInt(formData.progress) || 0,
          assignedTo: formData.assignedTo,
          notes: formData.notes,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        onProjectsChange([...projects, newProject]);
        setIsCreateDialogOpen(false);

        toast({
          title: "✅ Tạo thành công",
          description: `Đã tạo dự án ${formData.name}`,
        });
      }
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Tên dự án *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Nhập tên dự án"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="status">Trạng thái</Label>
            <Select
              value={formData.status}
              onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="planning">Lên kế hoạch</SelectItem>
                <SelectItem value="in-progress">Đang thực hiện</SelectItem>
                <SelectItem value="completed">Hoàn thành</SelectItem>
                <SelectItem value="on-hold">Tạm dừng</SelectItem>
                <SelectItem value="cancelled">Đã hủy</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Mô tả</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            placeholder="Mô tả chi tiết dự án"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="startDate">Ngày bắt đầu</Label>
            <Input
              id="startDate"
              type="date"
              value={formData.startDate}
              onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="endDate">Ngày kết thúc</Label>
            <Input
              id="endDate"
              type="date"
              value={formData.endDate}
              onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="estimatedValue">Giá trị ước tính (VNĐ)</Label>
            <Input
              id="estimatedValue"
              type="number"
              value={formData.estimatedValue}
              onChange={(e) => setFormData(prev => ({ ...prev, estimatedValue: e.target.value }))}
              placeholder="0"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="actualValue">Giá trị thực tế (VNĐ)</Label>
            <Input
              id="actualValue"
              type="number"
              value={formData.actualValue}
              onChange={(e) => setFormData(prev => ({ ...prev, actualValue: e.target.value }))}
              placeholder="0"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="progress">Tiến độ (%)</Label>
            <Input
              id="progress"
              type="number"
              min="0"
              max="100"
              value={formData.progress}
              onChange={(e) => setFormData(prev => ({ ...prev, progress: e.target.value }))}
              placeholder="0"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="assignedTo">Người phụ trách</Label>
            <Select
              value={formData.assignedTo}
              onValueChange={(value) => setFormData(prev => ({ ...prev, assignedTo: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Chọn người phụ trách" />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">Ghi chú</Label>
          <Textarea
            id="notes"
            value={formData.notes}
            onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
            placeholder="Ghi chú thêm về dự án"
          />
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              if (isEdit) {
                setEditingProject(null);
              } else {
                setIsCreateDialogOpen(false);
              }
            }}
          >
            Hủy
          </Button>
          <Button type="submit">
            {isEdit ? "Cập nhật" : "Tạo dự án"}
          </Button>
        </div>
      </form>
    );
  };

  const deleteProject = (projectId: string) => {
    const updatedProjects = projects.filter(p => p.id !== projectId);
    onProjectsChange(updatedProjects);
    toast({
      title: "Xóa thành công",
      description: "Dự án đã được xóa khỏi hệ thống",
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "planning":
        return <Calendar className="h-4 w-4" />;
      case "in-progress":
        return <Play className="h-4 w-4" />;
      case "completed":
        return <CheckCircle className="h-4 w-4" />;
      case "on-hold":
        return <Pause className="h-4 w-4" />;
      case "cancelled":
        return <XCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "planning":
        return "bg-gray-100 text-gray-800";
      case "in-progress":
        return "bg-blue-100 text-blue-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "on-hold":
        return "bg-yellow-100 text-yellow-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "planning":
        return "Lên kế hoạch";
      case "in-progress":
        return "Đang thực hiện";
      case "completed":
        return "Hoàn thành";
      case "on-hold":
        return "Tạm dừng";
      case "cancelled":
        return "Đã hủy";
      default:
        return "Không xác định";
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount);
  };

  // Calculate summary stats
  const stats = {
    total: projects.length,
    active: projects.filter(p => p.status === "in-progress").length,
    completed: projects.filter(p => p.status === "completed").length,
    totalValue: projects.reduce((sum, p) => sum + p.estimatedValue, 0),
    completedValue: projects.filter(p => p.status === "completed").reduce((sum, p) => sum + (p.actualValue || p.estimatedValue), 0),
  };

  return (
    <div className="space-y-4">
      {/* Project Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="bg-blue-50 p-3 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-600">Tổng dự án</p>
              <p className="text-xl font-bold text-blue-700">{stats.total}</p>
            </div>
            <Calendar className="h-6 w-6 text-blue-600" />
          </div>
        </div>

        <div className="bg-green-50 p-3 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-600">Đang thực hiện</p>
              <p className="text-xl font-bold text-green-700">{stats.active}</p>
            </div>
            <Play className="h-6 w-6 text-green-600" />
          </div>
        </div>

        <div className="bg-purple-50 p-3 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-purple-600">Hoàn thành</p>
              <p className="text-xl font-bold text-purple-700">{stats.completed}</p>
            </div>
            <CheckCircle className="h-6 w-6 text-purple-600" />
          </div>
        </div>

        <div className="bg-orange-50 p-3 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-orange-600">Tổng giá trị</p>
              <p className="text-lg font-bold text-orange-700">{formatCurrency(stats.totalValue)}</p>
            </div>
            <DollarSign className="h-6 w-6 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Projects List */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-lg">Dự án của {customerName}</CardTitle>
              <CardDescription>
                Quản lý các dự án và hợp đồng với khách hàng
              </CardDescription>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Thêm dự án
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Tạo dự án mới</DialogTitle>
                  <DialogDescription>
                    Thêm dự án mới cho khách hàng {customerName}
                  </DialogDescription>
                </DialogHeader>
                <ProjectForm />
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {projects.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>Chưa có dự án nào cho khách hàng này</p>
              <p className="text-sm">Nhấn "Thêm dự án" để tạo dự án đầu tiên</p>
            </div>
          ) : (
            <div className="space-y-3">
              {projects.map((project) => {
                const assignedUser = users.find(u => u.id === project.assignedTo);
                return (
                  <div key={project.id} className="border rounded-lg p-4 hover:bg-gray-50">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-medium">{project.name}</h4>
                          <Badge className={getStatusColor(project.status)}>
                            {getStatusIcon(project.status)}
                            <span className="ml-1">{getStatusText(project.status)}</span>
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">{project.description}</p>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                          <div>
                            <span className="text-gray-500">Người phụ trách:</span>
                            <p className="font-medium">{assignedUser?.name || "Chưa phân công"}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Giá trị:</span>
                            <p className="font-medium">{formatCurrency(project.estimatedValue)}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Tiến độ:</span>
                            <p className="font-medium">{project.progress}%</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Thời gian:</span>
                            <p className="font-medium">
                              {new Date(project.startDate).toLocaleDateString('vi-VN')}
                              {project.endDate && ` - ${new Date(project.endDate).toLocaleDateString('vi-VN')}`}
                            </p>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="mt-3">
                          <div className="flex justify-between text-xs text-gray-500 mb-1">
                            <span>Tiến độ</span>
                            <span>{project.progress}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full transition-all"
                              style={{ width: `${project.progress}%` }}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-1 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setEditingProject(project)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm" className="hover:bg-red-50">
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Xác nhận xóa dự án</AlertDialogTitle>
                              <AlertDialogDescription>
                                Bạn có chắc chắn muốn xóa dự án "{project.name}"? 
                                Hành động này không thể hoàn tác.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Hủy</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteProject(project.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Xóa dự án
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Project Dialog */}
      <Dialog open={!!editingProject} onOpenChange={() => setEditingProject(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Chỉnh sửa dự án</DialogTitle>
            <DialogDescription>
              Cập nhật thông tin dự án {editingProject?.name}
            </DialogDescription>
          </DialogHeader>
          {editingProject && (
            <ProjectForm project={editingProject} isEdit={true} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
