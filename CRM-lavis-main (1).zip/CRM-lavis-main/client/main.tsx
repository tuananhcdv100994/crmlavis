import "./global.css";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import CRMTestRunner from "./utils/testRunner";

// Make test runner available globally for console testing
(window as any).CRMTestRunner = CRMTestRunner;

const container = document.getElementById("root");
if (!container) throw new Error("Root element not found");

const root = createRoot(container);
root.render(
  <StrictMode>
    <App />
  </StrictMode>,
);
