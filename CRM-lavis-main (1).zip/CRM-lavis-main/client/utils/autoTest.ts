// Auto Test Script để kiểm tra toàn diện các chức năng
import { CRMTestRunner } from './testRunner';
import { DebugHelper } from './debugHelper';

export class AutoTest {
  private static log(message: string, type: 'info' | 'success' | 'error' = 'info') {
    const prefix = type === 'success' ? '✅' : type === 'error' ? '❌' : '🔍';
    console.log(`${prefix} [AUTO-TEST] ${message}`);
  }

  // Main test function
  static async runComprehensiveTest() {
    this.log('🚀 STARTING COMPREHENSIVE AUTO-TEST 🚀');
    
    try {
      // Step 1: Run diagnostic
      this.log('Step 1: Running diagnostic...', 'info');
      DebugHelper.runFullDiagnostic();
      
      // Step 2: Run CRM tests
      this.log('Step 2: Running CRM functionality tests...', 'info');
      const testResults = await CRMTestRunner.runAllTests();
      
      // Step 3: Check button functionality
      this.log('Step 3: Testing button functionality...', 'info');
      this.testButtonFunctionality();
      
      // Step 4: Check permissions
      this.log('Step 4: Verifying permissions...', 'info');
      this.verifyPermissions();
      
      // Step 5: Generate report
      this.log('Step 5: Generating final report...', 'info');
      this.generateFinalReport(testResults);
      
      this.log('🎉 COMPREHENSIVE TEST COMPLETED SUCCESSFULLY! 🎉', 'success');
      
      return {
        success: true,
        results: testResults,
        message: 'All tests passed successfully'
      };
      
    } catch (error) {
      this.log(`Test failed: ${error}`, 'error');
      return {
        success: false,
        error: error,
        message: 'Test suite encountered errors'
      };
    }
  }

  // Test button functionality
  private static testButtonFunctionality() {
    this.log('Testing button functionality...', 'info');
    
    // Get current user
    const savedUser = localStorage.getItem('crm_user');
    if (!savedUser) {
      this.log('No user logged in for button test', 'error');
      return;
    }

    const user = JSON.parse(savedUser);
    this.log(`Testing buttons for user: ${user.name}`, 'info');

    // Check if buttons exist and are clickable
    const buttonSelectors = [
      'Tạo tài khoản',
      'Thêm khách hàng',
      'Tạo công việc',
      'Cài đặt',
      'Xuất báo cáo'
    ];

    buttonSelectors.forEach(selector => {
      const buttons = Array.from(document.querySelectorAll('button')).filter(btn => 
        btn.textContent?.includes(selector)
      );
      
      if (buttons.length > 0) {
        this.log(`Button "${selector}": FOUND (${buttons.length} instances)`, 'success');
        buttons.forEach((btn, idx) => {
          const isDisabled = (btn as HTMLButtonElement).disabled;
          this.log(`  - Instance ${idx + 1}: ${isDisabled ? 'DISABLED' : 'ENABLED'}`, isDisabled ? 'error' : 'success');
        });
      } else {
        this.log(`Button "${selector}": NOT FOUND`, 'error');
      }
    });
  }

  // Verify permissions
  private static verifyPermissions() {
    this.log('Verifying user permissions...', 'info');
    
    const users = localStorage.getItem('crm_users');
    if (!users) {
      this.log('No users data found', 'error');
      return;
    }

    const usersData = JSON.parse(users);
    
    usersData.forEach((user: any) => {
      this.log(`User: ${user.name}`, 'info');
      this.log(`  - Role: ${user.role}`, 'info');
      this.log(`  - Total permissions: ${user.permissions?.length || 0}`, user.permissions?.length > 0 ? 'success' : 'error');
      
      if (user.name === 'Nguyễn Văn Nam') {
        const expectedPermissions = 25;
        const actualPermissions = user.permissions?.length || 0;
        if (actualPermissions >= expectedPermissions) {
          this.log(`  - ✅ Nguyễn Văn Nam has ${actualPermissions} permissions (expected at least ${expectedPermissions})`, 'success');
        } else {
          this.log(`  - ❌ Nguyễn Văn Nam has only ${actualPermissions} permissions (expected at least ${expectedPermissions})`, 'error');
        }
      }
    });
  }

  // Generate final report
  private static generateFinalReport(testResults: any) {
    this.log('=== FINAL TEST REPORT ===', 'info');
    
    const currentUser = JSON.parse(localStorage.getItem('crm_user') || '{}');
    const users = JSON.parse(localStorage.getItem('crm_users') || '[]');
    const customers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
    const tasks = JSON.parse(localStorage.getItem('crm_tasks') || '[]');
    
    this.log(`Current User: ${currentUser.name || 'None'} (${currentUser.role || 'N/A'})`, 'info');
    this.log(`Total Users: ${users.length}`, 'info');
    this.log(`Total Customers: ${customers.length}`, 'info');
    this.log(`Total Tasks: ${tasks.length}`, 'info');
    
    // Check Nguyễn Văn Nam specifically
    const nvnUser = users.find((u: any) => u.name === 'Nguyễn Văn Nam');
    if (nvnUser) {
      this.log(`Nguyễn Văn Nam permissions: ${nvnUser.permissions?.length || 0}`, 'info');
      this.log(`Permission list: ${nvnUser.permissions?.join(', ') || 'None'}`, 'info');
    }
    
    // Test results summary
    if (testResults) {
      this.log(`User Creation Test: ${testResults.userCreated ? 'PASS' : 'FAIL'}`, testResults.userCreated ? 'success' : 'error');
      this.log(`Customer Creation Test: ${testResults.customerCreated ? 'PASS' : 'FAIL'}`, testResults.customerCreated ? 'success' : 'error');
      this.log(`Task Creation Test: ${testResults.taskCreated ? 'PASS' : 'FAIL'}`, testResults.taskCreated ? 'success' : 'error');
    }
    
    this.log('=== END REPORT ===', 'info');
  }

  // Quick fix for common issues
  static quickFix() {
    this.log('Running quick fix for common issues...', 'info');
    
    // Fix Nguyễn Văn Nam permissions
    DebugHelper.fixUserPermissions('Nguyễn Văn Nam');
    
    // Ensure admin has full access
    const currentUser = localStorage.getItem('crm_user');
    if (currentUser) {
      const user = JSON.parse(currentUser);
      if (user.role === 'admin') {
        const fullAdminPermissions = [
          "view_customers", "create_customers", "edit_customers", "delete_customers",
          "view_tasks", "create_tasks", "edit_tasks", "delete_tasks",
          "view_users", "create_users", "edit_users", "delete_users",
          "view_reports", "export_data", "backup_system", "system_settings",
          "view_departments", "create_departments", "edit_departments", "delete_departments",
          "manage_permissions", "manage_chat", "create_groups", "attendance",
          "all"
        ];
        
        user.permissions = fullAdminPermissions;
        localStorage.setItem('crm_user', JSON.stringify(user));
        this.log('Fixed admin permissions', 'success');
      }
    }
    
    this.log('Quick fix completed', 'success');
  }
}

// Make available globally
if (typeof window !== 'undefined') {
  (window as any).AutoTest = AutoTest;
}

export default AutoTest;
