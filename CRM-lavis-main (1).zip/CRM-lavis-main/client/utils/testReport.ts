// Test Report utility để tổng hợp kết quả test

export interface TestResult {
  testName: string;
  status: 'PASS' | 'FAIL' | 'SKIP';
  message?: string;
  timestamp: string;
}

export class TestReporter {
  private static results: TestResult[] = [];

  static addResult(testName: string, status: 'PASS' | 'FAIL' | 'SKIP', message?: string) {
    this.results.push({
      testName,
      status,
      message,
      timestamp: new Date().toISOString()
    });
  }

  static generateReport(): string {
    const total = this.results.length;
    const passed = this.results.filter(r => r.status === 'PASS').length;
    const failed = this.results.filter(r => r.status === 'FAIL').length;
    const skipped = this.results.filter(r => r.status === 'SKIP').length;

    let report = `
🔍 CRM COMPREHENSIVE TEST REPORT
════════���══════════════════════════════

📊 SUMMARY:
   Total Tests: ${total}
   ✅ Passed: ${passed}
   ❌ Failed: ${failed}
   ⏭️  Skipped: ${skipped}
   📈 Success Rate: ${total > 0 ? Math.round((passed / total) * 100) : 0}%

📋 DETAILED RESULTS:
`;

    this.results.forEach((result, index) => {
      const icon = result.status === 'PASS' ? '✅' : result.status === 'FAIL' ? '❌' : '⏭️';
      report += `   ${icon} ${index + 1}. ${result.testName}`;
      if (result.message) {
        report += ` - ${result.message}`;
      }
      report += `\n`;
    });

    report += `
═══════════════════════════════════════
Generated at: ${new Date().toLocaleString('vi-VN')}
`;

    return report;
  }

  static clearResults() {
    this.results = [];
  }

  static getResults() {
    return [...this.results];
  }

  // Run comprehensive test and generate report
  static async runComprehensiveTest(): Promise<string> {
    console.log("🚀 STARTING COMPREHENSIVE CRM TEST SUITE 🚀");
    
    this.clearResults();

    // Test 1: Authentication
    try {
      const user = localStorage.getItem('crm_user');
      if (user && JSON.parse(user)) {
        this.addResult('Authentication', 'PASS', 'User is logged in');
      } else {
        this.addResult('Authentication', 'FAIL', 'No user logged in');
      }
    } catch (error) {
      this.addResult('Authentication', 'FAIL', `Auth error: ${error}`);
    }

    // Test 2: Data Persistence
    try {
      const users = localStorage.getItem('crm_users');
      const customers = localStorage.getItem('crm_customers');
      const tasks = localStorage.getItem('crm_tasks');
      
      if (users && customers && tasks) {
        this.addResult('Data Persistence', 'PASS', 'All data stores present');
      } else {
        this.addResult('Data Persistence', 'FAIL', 'Missing data stores');
      }
    } catch (error) {
      this.addResult('Data Persistence', 'FAIL', `Data error: ${error}`);
    }

    // Test 3: User Creation
    try {
      if ((window as any).CRMTestRunner) {
        const user = (window as any).CRMTestRunner.testUserCreation();
        this.addResult('User Creation', user ? 'PASS' : 'FAIL', user ? 'User created successfully' : 'Failed to create user');
      } else {
        this.addResult('User Creation', 'SKIP', 'TestRunner not available');
      }
    } catch (error) {
      this.addResult('User Creation', 'FAIL', `Error: ${error}`);
    }

    // Test 4: Customer Creation
    try {
      if ((window as any).CRMTestRunner) {
        const customer = (window as any).CRMTestRunner.testCustomerCreation();
        this.addResult('Customer Creation', customer ? 'PASS' : 'FAIL', customer ? 'Customer created successfully' : 'Failed to create customer');
      } else {
        this.addResult('Customer Creation', 'SKIP', 'TestRunner not available');
      }
    } catch (error) {
      this.addResult('Customer Creation', 'FAIL', `Error: ${error}`);
    }

    // Test 5: Task Creation
    try {
      if ((window as any).CRMTestRunner) {
        const task = (window as any).CRMTestRunner.testTaskCreation();
        this.addResult('Task Creation', task ? 'PASS' : 'FAIL', task ? 'Task created successfully' : 'Failed to create task');
      } else {
        this.addResult('Task Creation', 'SKIP', 'TestRunner not available');
      }
    } catch (error) {
      this.addResult('Task Creation', 'FAIL', `Error: ${error}`);
    }

    // Test 6: Permission Management
    try {
      if ((window as any).CRMTestRunner) {
        const permTest = (window as any).CRMTestRunner.testPermissionUpdate();
        this.addResult('Permission Management', permTest ? 'PASS' : 'FAIL', permTest ? 'Permissions updated successfully' : 'Failed to update permissions');
      } else {
        this.addResult('Permission Management', 'SKIP', 'TestRunner not available');
      }
    } catch (error) {
      this.addResult('Permission Management', 'FAIL', `Error: ${error}`);
    }

    // Test 7: UI Components
    try {
      const buttons = document.querySelectorAll('button');
      const inputs = document.querySelectorAll('input');
      const forms = document.querySelectorAll('form');
      
      this.addResult('UI Components', 'PASS', `${buttons.length} buttons, ${inputs.length} inputs, ${forms.length} forms found`);
    } catch (error) {
      this.addResult('UI Components', 'FAIL', `UI error: ${error}`);
    }

    // Test 8: Navigation
    try {
      const currentPath = window.location.pathname;
      const hasNavigation = document.querySelectorAll('[role="tablist"], nav').length > 0;
      
      this.addResult('Navigation', hasNavigation ? 'PASS' : 'FAIL', `Current path: ${currentPath}`);
    } catch (error) {
      this.addResult('Navigation', 'FAIL', `Navigation error: ${error}`);
    }

    // Generate and return report
    const report = this.generateReport();
    console.log(report);
    
    return report;
  }
}

// Make it available globally
if (typeof window !== 'undefined') {
  (window as any).TestReporter = TestReporter;
}

export default TestReporter;
