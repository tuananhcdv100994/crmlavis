// Debug helper để test buttons và quyền
export class DebugHelper {
  private static log(message: string, type: 'info' | 'success' | 'error' = 'info') {
    const prefix = type === 'success' ? '✅' : type === 'error' ? '❌' : '🔍';
    console.log(`${prefix} [DEBUG] ${message}`);
  }

  // Kiểm tra trạng thái authentication
  static checkAuthState() {
    this.log('=== KIỂM TRA TRẠNG THÁI AUTHENTICATION ===');
    
    const savedUser = localStorage.getItem('crm_user');
    if (!savedUser) {
      this.log('Không có user trong localStorage', 'error');
      return null;
    }

    const user = JSON.parse(savedUser);
    this.log(`Current user: ${user.name} (${user.role})`, 'success');
    this.log(`User ID: ${user.id}`, 'info');
    this.log(`Total permissions: ${user.permissions?.length || 0}`, 'info');
    this.log(`Permissions: ${user.permissions?.join(', ') || 'NONE'}`, 'info');
    
    return user;
  }

  // Kiểm tra quyền cụ thể
  static checkPermissions(requiredPermissions: string[]) {
    const user = this.checkAuthState();
    if (!user) return false;

    this.log('=== KIỂM TRA QUYỀN CỤ THỂ ===');
    
    requiredPermissions.forEach(permission => {
      const hasPermission = user.permissions?.includes(permission) || user.permissions?.includes('all') || user.role === 'admin';
      this.log(`Permission "${permission}": ${hasPermission ? 'CÓ' : 'KHÔNG CÓ'}`, hasPermission ? 'success' : 'error');
    });

    return true;
  }

  // Kiểm tra tất cả data trong localStorage
  static checkDataStorage() {
    this.log('=== KIỂM TRA DỮ LIỆU TRONG LOCALSTORAGE ===');
    
    const users = localStorage.getItem('crm_users');
    const customers = localStorage.getItem('crm_customers');
    const tasks = localStorage.getItem('crm_tasks');

    this.log(`Users data: ${users ? 'CÓ' : 'KHÔNG CÓ'}`, users ? 'success' : 'error');
    this.log(`Customers data: ${customers ? 'CÓ' : 'KHÔNG CÓ'}`, customers ? 'success' : 'error');
    this.log(`Tasks data: ${tasks ? 'CÓ' : 'KHÔNG CÓ'}`, tasks ? 'success' : 'error');

    if (users) {
      const usersData = JSON.parse(users);
      this.log(`Total users: ${usersData.length}`, 'info');
      
      usersData.forEach((user: any) => {
        this.log(`User: ${user.name} - Permissions: ${user.permissions?.length || 0}`, 'info');
      });
    }
  }

  // Test button click handlers
  static testButtonHandlers() {
    this.log('=== TESTING BUTTON HANDLERS ===');
    
    // Test các button chính
    const buttons = [
      'Tạo tài khoản',
      'Thêm khách hàng', 
      'Tạo công việc',
      'Cài đặt quyền'
    ];

    buttons.forEach(buttonText => {
      const button = Array.from(document.querySelectorAll('button')).find(btn => 
        btn.textContent?.includes(buttonText)
      );
      
      if (button) {
        this.log(`Button "${buttonText}": FOUND`, 'success');
        this.log(`Button disabled: ${(button as HTMLButtonElement).disabled}`, 'info');
        this.log(`Button classes: ${button.className}`, 'info');
      } else {
        this.log(`Button "${buttonText}": NOT FOUND`, 'error');
      }
    });
  }

  // Simulate button clicks để test
  static simulateButtonClicks() {
    this.log('=== SIMULATING BUTTON CLICKS ===');
    
    const user = this.checkAuthState();
    if (!user) {
      this.log('Cannot simulate clicks - no user logged in', 'error');
      return;
    }

    // Test create user button
    const createUserBtn = Array.from(document.querySelectorAll('button')).find(btn => 
      btn.textContent?.includes('Tạo tài khoản')
    );
    
    if (createUserBtn) {
      this.log('Testing "Tạo tài khoản" button click...', 'info');
      try {
        (createUserBtn as HTMLButtonElement).click();
        this.log('Button click executed successfully', 'success');
      } catch (error) {
        this.log(`Button click failed: ${error}`, 'error');
      }
    }
  }

  // Fix permissions cho user cụ thể
  static fixUserPermissions(userName: string = 'Nguyễn Văn Nam') {
    this.log('=== FIXING USER PERMISSIONS ===');
    
    const users = localStorage.getItem('crm_users');
    if (!users) {
      this.log('No users data found', 'error');
      return;
    }

    const usersData = JSON.parse(users);
    const targetUser = usersData.find((u: any) => u.name === userName);
    
    if (!targetUser) {
      this.log(`User "${userName}" not found`, 'error');
      return;
    }

    this.log(`Found user: ${targetUser.name}`, 'success');
    this.log(`Current permissions: ${targetUser.permissions?.length || 0}`, 'info');

    // Update với đầy đủ quyền
    const fullPermissions = [
      "view_customers", "create_customers", "edit_customers", "delete_customers",
      "view_tasks", "create_tasks", "edit_tasks", "delete_tasks", 
      "view_users", "create_users", "edit_users", "delete_users",
      "view_reports", "export_data", "backup_system", "system_settings",
      "view_departments", "create_departments", "edit_departments", "delete_departments", 
      "manage_permissions", "manage_chat", "create_groups", "attendance",
      "tasks", "customers", "chat", "all"
    ];

    targetUser.permissions = fullPermissions;
    
    const updatedUsers = usersData.map((u: any) => 
      u.id === targetUser.id ? targetUser : u
    );

    localStorage.setItem('crm_users', JSON.stringify(updatedUsers));
    
    this.log(`Updated permissions for ${userName}: ${fullPermissions.length} permissions`, 'success');
    
    return targetUser;
  }

  // Run comprehensive test
  static runFullDiagnostic() {
    this.log('🚀 RUNNING FULL DIAGNOSTIC 🚀');
    
    this.checkAuthState();
    this.checkDataStorage();
    this.checkPermissions([
      'create_customers', 
      'create_tasks', 
      'create_users', 
      'manage_permissions'
    ]);
    this.testButtonHandlers();
    
    // Fix permissions cho Nguyễn Văn Nam
    this.fixUserPermissions('Nguyễn Văn Nam');
    
    this.log('🎉 DIAGNOSTIC COMPLETED!', 'success');
  }

  // Force refresh current page
  static forceRefresh() {
    this.log('Force refreshing page...', 'info');
    window.location.reload();
  }
}

// Make available globally
if (typeof window !== 'undefined') {
  (window as any).DebugHelper = DebugHelper;
}

export default DebugHelper;
