// UI Test utility để test các button clicks và form submissions

export class UITestRunner {
  private static log(message: string, type: 'info' | 'success' | 'error' = 'info') {
    const prefix = type === 'success' ? '✅' : type === 'error' ? '❌' : '🔍';
    console.log(`${prefix} [UI TEST] ${message}`);
  }

  // Test if element exists and is clickable
  static testElement(selector: string): boolean {
    const element = document.querySelector(selector);
    if (!element) {
      this.log(`Element not found: ${selector}`, 'error');
      return false;
    }
    
    const isVisible = element.getBoundingClientRect().width > 0 && 
                     element.getBoundingClientRect().height > 0;
    const isClickable = !element.hasAttribute('disabled');
    
    this.log(`Element ${selector}: visible=${isVisible}, clickable=${isClickable}`, 
             isVisible && isClickable ? 'success' : 'error');
    
    return isVisible && isClickable;
  }

  // Test button click
  static testButtonClick(selector: string, buttonName: string): boolean {
    this.log(`Testing button: ${buttonName}`);
    
    try {
      const button = document.querySelector(selector) as HTMLElement;
      if (!button) {
        this.log(`Button not found: ${selector}`, 'error');
        return false;
      }

      // Check if button is disabled
      if (button.hasAttribute('disabled')) {
        this.log(`Button is disabled: ${buttonName}`, 'error');
        return false;
      }

      // Simulate click
      button.click();
      this.log(`Button clicked successfully: ${buttonName}`, 'success');
      return true;
    } catch (error) {
      this.log(`Button click failed: ${buttonName} - ${error}`, 'error');
      return false;
    }
  }

  // Test dialog opening
  static testDialogOpen(triggerSelector: string, dialogSelector: string, dialogName: string): boolean {
    this.log(`Testing dialog: ${dialogName}`);
    
    try {
      // Click trigger button
      const trigger = document.querySelector(triggerSelector) as HTMLElement;
      if (!trigger) {
        this.log(`Dialog trigger not found: ${triggerSelector}`, 'error');
        return false;
      }

      trigger.click();
      
      // Wait a bit for dialog to open
      setTimeout(() => {
        const dialog = document.querySelector(dialogSelector);
        if (dialog) {
          this.log(`Dialog opened successfully: ${dialogName}`, 'success');
          
          // Try to close dialog (ESC key or close button)
          const closeButton = dialog.querySelector('[data-dialog-close], [aria-label="Close"]') as HTMLElement;
          if (closeButton) {
            closeButton.click();
            this.log(`Dialog closed successfully: ${dialogName}`, 'success');
          }
        } else {
          this.log(`Dialog not found after trigger: ${dialogName}`, 'error');
        }
      }, 100);
      
      return true;
    } catch (error) {
      this.log(`Dialog test failed: ${dialogName} - ${error}`, 'error');
      return false;
    }
  }

  // Test all common CRM buttons
  static testAllButtons() {
    this.log('=== TESTING ALL CRM BUTTONS ===');
    
    const results = {
      userCreate: false,
      customerCreate: false,
      taskCreate: false,
      permissionEdit: false,
      aiImport: false
    };

    // Test Create User button
    if (this.testElement('button:has-text("Tạo tài khoản"), [data-testid="create-user"]')) {
      results.userCreate = this.testButtonClick('button:contains("Tạo tài khoản")', 'Create User');
    }

    // Test Create Customer button  
    if (this.testElement('button:has-text("Thêm khách hàng"), [data-testid="create-customer"]')) {
      results.customerCreate = this.testButtonClick('button:contains("Thêm khách hàng")', 'Create Customer');
    }

    // Test Create Task button
    if (this.testElement('button:has-text("Tạo task mới"), [data-testid="create-task"]')) {
      results.taskCreate = this.testButtonClick('button:contains("Tạo task")', 'Create Task');
    }

    // Test Permission Settings buttons
    if (this.testElement('button:has-text("Cài đặt"), [data-testid="edit-permissions"]')) {
      results.permissionEdit = this.testButtonClick('button:contains("Cài đặt")', 'Edit Permissions');
    }

    // Test AI Import buttons
    if (this.testElement('button:has-text("AI Import"), [data-testid="ai-import"]')) {
      results.aiImport = this.testButtonClick('button:contains("AI Import")', 'AI Import');
    }

    this.log('=== BUTTON TEST RESULTS ===');
    Object.entries(results).forEach(([key, value]) => {
      this.log(`${key}: ${value ? 'PASS' : 'FAIL'}`, value ? 'success' : 'error');
    });

    return results;
  }

  // Test navigation between tabs
  static testTabNavigation() {
    this.log('=== TESTING TAB NAVIGATION ===');
    
    const tabSelectors = [
      'button[value="overview"]',
      'button[value="users"]', 
      'button[value="customers"]',
      'button[value="tasks"]',
      'button[value="permissions"]',
      'button[value="reports"]'
    ];

    const results: { [key: string]: boolean } = {};

    tabSelectors.forEach(selector => {
      try {
        const tab = document.querySelector(selector) as HTMLElement;
        if (tab) {
          tab.click();
          this.log(`Tab clicked: ${selector}`, 'success');
          results[selector] = true;
        } else {
          this.log(`Tab not found: ${selector}`, 'error');
          results[selector] = false;
        }
      } catch (error) {
        this.log(`Tab click failed: ${selector} - ${error}`, 'error');
        results[selector] = false;
      }
    });

    return results;
  }

  // Check for JavaScript errors
  static checkJSErrors() {
    this.log('=== CHECKING FOR JAVASCRIPT ERRORS ===');
    
    // Override console.error to capture errors
    const originalError = console.error;
    const errors: string[] = [];
    
    console.error = (...args) => {
      errors.push(args.join(' '));
      originalError(...args);
    };

    // Restore after a short time
    setTimeout(() => {
      console.error = originalError;
      
      if (errors.length > 0) {
        this.log(`Found ${errors.length} JavaScript errors:`, 'error');
        errors.forEach(error => this.log(`  - ${error}`, 'error'));
      } else {
        this.log('No JavaScript errors detected', 'success');
      }
    }, 1000);
  }

  // Test form submissions
  static testFormSubmissions() {
    this.log('=== TESTING FORM SUBMISSIONS ===');
    
    // This would test actual form filling and submission
    // For now, just check if forms exist
    const forms = document.querySelectorAll('form');
    this.log(`Found ${forms.length} forms on page`, 'info');
    
    forms.forEach((form, index) => {
      const inputs = form.querySelectorAll('input, textarea, select');
      this.log(`Form ${index + 1}: ${inputs.length} input fields`, 'info');
    });
  }

  // Run comprehensive UI tests
  static runAllUITests() {
    this.log('🎮 STARTING COMPREHENSIVE UI TEST SUITE 🎮');
    
    // Check for JS errors
    this.checkJSErrors();
    
    // Test tab navigation
    const tabResults = this.testTabNavigation();
    
    // Test all buttons
    const buttonResults = this.testAllButtons();
    
    // Test forms
    this.testFormSubmissions();
    
    this.log('🎉 UI TEST SUITE COMPLETED!', 'success');
    
    return {
      tabs: tabResults,
      buttons: buttonResults,
      completed: true
    };
  }
}

// Make it available globally
if (typeof window !== 'undefined') {
  (window as any).UITestRunner = UITestRunner;
}

export default UITestRunner;
