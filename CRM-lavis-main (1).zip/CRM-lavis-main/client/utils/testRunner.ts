// Test utility để test tất cả chức năng trong hệ thống CRM

export class CRMTestRunner {
  private static log(message: string, type: 'info' | 'success' | 'error' = 'info') {
    const prefix = type === 'success' ? '✅' : type === 'error' ? '❌' : '🔍';
    console.log(`${prefix} [CRM TEST] ${message}`);
  }

  // Test authentication
  static async testAuth() {
    this.log('=== TESTING AUTHENTICATION ===');
    
    try {
      // Check current user
      const savedUser = localStorage.getItem('crm_user');
      this.log(`Current saved user: ${savedUser}`);

      if (!savedUser) {
        this.log('No user found - need to simulate login', 'error');
        return false;
      }

      const user = JSON.parse(savedUser);
      this.log(`User role: ${user.role}`, 'success');
      this.log(`User permissions: ${user.permissions?.join(', ')}`, 'info');
      
      return true;
    } catch (error) {
      this.log(`Auth test failed: ${error}`, 'error');
      return false;
    }
  }

  // Test data persistence
  static testDataPersistence() {
    this.log('=== TESTING DATA PERSISTENCE ===');
    
    const users = localStorage.getItem('crm_users');
    const customers = localStorage.getItem('crm_customers');
    const tasks = localStorage.getItem('crm_tasks');

    this.log(`Users data: ${users ? 'EXISTS' : 'MISSING'}`);
    this.log(`Customers data: ${customers ? 'EXISTS' : 'MISSING'}`);
    this.log(`Tasks data: ${tasks ? 'EXISTS' : 'MISSING'}`);

    if (users) {
      const usersData = JSON.parse(users);
      this.log(`Total users: ${usersData.length}`, 'success');
    }

    if (customers) {
      const customersData = JSON.parse(customers);
      this.log(`Total customers: ${customersData.length}`, 'success');
    }

    if (tasks) {
      const tasksData = JSON.parse(tasks);
      this.log(`Total tasks: ${tasksData.length}`, 'success');
    }
  }

  // Test user creation simulation
  static testUserCreation() {
    this.log('=== TESTING USER CREATION ===');
    
    try {
      const users = JSON.parse(localStorage.getItem('crm_users') || '[]');
      
      const newUser = {
        id: `test-user-${Date.now()}`,
        username: `testuser${Date.now()}`,
        email: `test${Date.now()}@test.com`,
        name: `Test User ${Date.now()}`,
        role: "employee",
        department: "Test Department",
        position: "Test Position",
        phone: "0123456789",
        status: "active",
        permissions: ["tasks", "customers"],
        createdAt: new Date().toISOString().split('T')[0],
      };

      const updatedUsers = [...users, newUser];
      localStorage.setItem('crm_users', JSON.stringify(updatedUsers));
      
      this.log(`Created test user: ${newUser.name}`, 'success');
      this.log(`Total users now: ${updatedUsers.length}`, 'info');
      
      return newUser;
    } catch (error) {
      this.log(`User creation test failed: ${error}`, 'error');
      return null;
    }
  }

  // Test customer creation simulation
  static testCustomerCreation() {
    this.log('=== TESTING CUSTOMER CREATION ===');
    
    try {
      const customers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
      
      const newCustomer = {
        id: `test-customer-${Date.now()}`,
        name: `Test Company ${Date.now()}`,
        industry: "Technology",
        contactPerson: "Test Contact",
        email: `test${Date.now()}@company.com`,
        phone: "0987654321",
        address: "Test Address",
        status: "potential",
        assignedTo: "admin-1",
        assignedToName: "Admin",
        estimatedValue: 1000000,
        notes: "Test customer created by automated test",
        createdAt: new Date().toISOString().split('T')[0],
        source: "Test",
        priority: "medium",
        projects: [],
        totalProjectValue: 0,
        activeProjects: 0,
        completedProjects: 0,
      };

      const updatedCustomers = [...customers, newCustomer];
      localStorage.setItem('crm_customers', JSON.stringify(updatedCustomers));
      
      this.log(`Created test customer: ${newCustomer.name}`, 'success');
      this.log(`Total customers now: ${updatedCustomers.length}`, 'info');
      
      return newCustomer;
    } catch (error) {
      this.log(`Customer creation test failed: ${error}`, 'error');
      return null;
    }
  }

  // Test task creation simulation
  static testTaskCreation() {
    this.log('=== TESTING TASK CREATION ===');
    
    try {
      const tasks = JSON.parse(localStorage.getItem('crm_tasks') || '[]');
      
      const newTask = {
        id: `test-task-${Date.now()}`,
        title: `Test Task ${Date.now()}`,
        description: "This is a test task created by automated testing",
        status: "pending",
        priority: "medium",
        isPriorityMarked: false,
        deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        assignees: ["admin-1"],
        assigneeNames: ["Admin"],
        relatedPersons: [],
        relatedPersonNames: [],
        tags: ["test", "automated"],
        category: "Test",
        createdBy: "admin-1",
        createdByName: "Admin",
        createdAt: new Date().toISOString().split('T')[0],
        estimatedHours: 8,
        attachments: [],
        canSelfApprove: true,
      };

      const updatedTasks = [...tasks, newTask];
      localStorage.setItem('crm_tasks', JSON.stringify(updatedTasks));
      
      this.log(`Created test task: ${newTask.title}`, 'success');
      this.log(`Total tasks now: ${updatedTasks.length}`, 'info');
      
      return newTask;
    } catch (error) {
      this.log(`Task creation test failed: ${error}`, 'error');
      return null;
    }
  }

  // Test permission updates
  static testPermissionUpdate() {
    this.log('=== TESTING PERMISSION UPDATE ===');
    
    try {
      const users = JSON.parse(localStorage.getItem('crm_users') || '[]');
      
      if (users.length === 0) {
        this.log('No users found to test permissions', 'error');
        return false;
      }

      const testUser = users.find((u: any) => u.role === 'employee');
      if (!testUser) {
        this.log('No employee user found to test permissions', 'error');
        return false;
      }

      // Update permissions
      const newPermissions = ['view_customers', 'create_customers', 'view_tasks', 'create_tasks'];
      testUser.permissions = newPermissions;

      const updatedUsers = users.map((u: any) => u.id === testUser.id ? testUser : u);
      localStorage.setItem('crm_users', JSON.stringify(updatedUsers));
      
      this.log(`Updated permissions for: ${testUser.name}`, 'success');
      this.log(`New permissions: ${newPermissions.join(', ')}`, 'info');
      
      return true;
    } catch (error) {
      this.log(`Permission update test failed: ${error}`, 'error');
      return false;
    }
  }

  // Simulate admin login
  static simulateAdminLogin() {
    this.log('=== SIMULATING ADMIN LOGIN ===');
    
    const adminUser = {
      id: "admin-1",
      username: "tuananhcdv",
      email: "admin@lavisholding.com",
      role: "admin",
      name: "Tuấn Anh - Admin",
      avatar: "/placeholder.svg",
      department: "Quản trị",
      permissions: [
        "view_customers", "create_customers", "edit_customers", "delete_customers",
        "view_tasks", "create_tasks", "edit_tasks", "delete_tasks",
        "view_users", "create_users", "edit_users", "delete_users",
        "view_reports", "export_data", "backup_system", "system_settings",
        "view_departments", "create_departments", "edit_departments", "delete_departments",
        "manage_permissions", "manage_chat", "create_groups", "attendance",
        "all"
      ],
    };

    localStorage.setItem('crm_user', JSON.stringify(adminUser));
    this.log(`Admin login simulated: ${adminUser.name}`, 'success');
    this.log(`Admin permissions: ${adminUser.permissions.length} total`, 'info');
    
    return adminUser;
  }

  // Run all tests
  static async runAllTests() {
    this.log('🚀 STARTING COMPREHENSIVE CRM TEST SUITE 🚀');
    
    // Simulate admin login first
    this.simulateAdminLogin();
    
    // Test auth
    await this.testAuth();
    
    // Test data persistence
    this.testDataPersistence();
    
    // Test CRUD operations
    const newUser = this.testUserCreation();
    const newCustomer = this.testCustomerCreation();
    const newTask = this.testTaskCreation();
    
    // Test permissions
    this.testPermissionUpdate();
    
    // Summary
    this.log('=== TEST SUMMARY ===');
    this.log(`User creation: ${newUser ? 'PASS' : 'FAIL'}`, newUser ? 'success' : 'error');
    this.log(`Customer creation: ${newCustomer ? 'PASS' : 'FAIL'}`, newCustomer ? 'success' : 'error');
    this.log(`Task creation: ${newTask ? 'PASS' : 'FAIL'}`, newTask ? 'success' : 'error');
    
    this.log('🎉 TEST SUITE COMPLETED! Check console logs above for details.', 'success');
    
    // Return summary
    return {
      userCreated: !!newUser,
      customerCreated: !!newCustomer,
      taskCreated: !!newTask,
      authWorking: true,
      dataPresent: true
    };
  }

  // Clean up test data
  static cleanupTestData() {
    this.log('=== CLEANING UP TEST DATA ===');
    
    try {
      // Remove test users
      const users = JSON.parse(localStorage.getItem('crm_users') || '[]');
      const cleanUsers = users.filter((u: any) => !u.id.includes('test-user'));
      localStorage.setItem('crm_users', JSON.stringify(cleanUsers));
      
      // Remove test customers
      const customers = JSON.parse(localStorage.getItem('crm_customers') || '[]');
      const cleanCustomers = customers.filter((c: any) => !c.id.includes('test-customer'));
      localStorage.setItem('crm_customers', JSON.stringify(cleanCustomers));
      
      // Remove test tasks
      const tasks = JSON.parse(localStorage.getItem('crm_tasks') || '[]');
      const cleanTasks = tasks.filter((t: any) => !t.id.includes('test-task'));
      localStorage.setItem('crm_tasks', JSON.stringify(cleanTasks));
      
      this.log('Test data cleaned up successfully', 'success');
    } catch (error) {
      this.log(`Cleanup failed: ${error}`, 'error');
    }
  }
}

// Make it available globally for browser testing
if (typeof window !== 'undefined') {
  (window as any).CRMTestRunner = CRMTestRunner;
}

export default CRMTestRunner;
