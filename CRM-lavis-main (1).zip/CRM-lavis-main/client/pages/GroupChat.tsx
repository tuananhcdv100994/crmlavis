import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  MessageSquare,
  Users,
  Plus,
  Send,
  Search,
  Hash,
  Lock,
  Globe,
  Crown,
  UserPlus,
  Settings,
  MoreVertical,
  Smile,
  Paperclip,
  Phone,
  Video,
  Info,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { DataService } from "@/services/dataService";

interface ChatRoom {
  id: string;
  name: string;
  description: string;
  type: "public" | "private";
  createdBy: string;
  createdByName: string;
  members: string[];
  memberNames: string[];
  admins: string[];
  createdAt: string;
  lastActivity: string;
  avatar?: string;
  department?: string;
  isActive: boolean;
}

interface ChatMessage {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  content: string;
  type: "text" | "file" | "image" | "system";
  timestamp: string;
  edited?: boolean;
  editedAt?: string;
  replyTo?: string;
  reactions: { [emoji: string]: string[] }; // emoji -> user IDs
}

export default function GroupChat() {
  const { user } = useAuth();
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<string>("");
  const [messageInput, setMessageInput] = useState("");
  const [isCreateRoomDialogOpen, setIsCreateRoomDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Check if user can create rooms (admin, manager roles, or specific permissions)
  const canCreateRooms = 
    user?.role === "admin" ||
    user?.permissions?.includes("create_groups") ||
    user?.permissions?.includes("manage_chat") ||
    user?.department === "Kinh doanh" && user?.permissions?.includes("chat") ||
    (user?.permissions?.includes("chat") && 
     (user?.name?.includes("Trưởng") || user?.name?.includes("Admin")));

  useEffect(() => {
    loadData();
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadData = async () => {
    try {
      const [usersData] = await Promise.all([
        DataService.loadUsers()
      ]);
      setUsers(usersData);

      // Load chat rooms and messages from localStorage
      const savedRooms = localStorage.getItem("crm_chat_rooms");
      const savedMessages = localStorage.getItem("crm_chat_messages");

      if (savedRooms) {
        setChatRooms(JSON.parse(savedRooms));
      } else {
        // Create default rooms
        const defaultRooms: ChatRoom[] = [
          {
            id: "general",
            name: "Tổng quát",
            description: "Kênh chat chung cho toàn công ty",
            type: "public",
            createdBy: "admin-1",
            createdByName: "Tuấn Anh - Admin",
            members: usersData.map((u: any) => u.id),
            memberNames: usersData.map((u: any) => u.name),
            admins: ["admin-1"],
            createdAt: new Date().toISOString(),
            lastActivity: new Date().toISOString(),
            department: "Tất cả",
            isActive: true
          },
          {
            id: "sales",
            name: "Kinh doanh",
            description: "Kênh riêng cho phòng kinh doanh",
            type: "private",
            createdBy: "admin-1",
            createdByName: "Tuấn Anh - Admin",
            members: usersData.filter((u: any) => u.department === "Kinh doanh" || u.role === "admin").map((u: any) => u.id),
            memberNames: usersData.filter((u: any) => u.department === "Kinh doanh" || u.role === "admin").map((u: any) => u.name),
            admins: ["admin-1"],
            createdAt: new Date().toISOString(),
            lastActivity: new Date().toISOString(),
            department: "Kinh doanh",
            isActive: true
          }
        ];
        setChatRooms(defaultRooms);
        localStorage.setItem("crm_chat_rooms", JSON.stringify(defaultRooms));
      }

      if (savedMessages) {
        setMessages(JSON.parse(savedMessages));
      }
    } catch (error) {
      console.error("Error loading chat data:", error);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const sendMessage = () => {
    if (!messageInput.trim() || !selectedRoom || !user) return;

    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      roomId: selectedRoom,
      userId: user.id,
      userName: user.name,
      content: messageInput.trim(),
      type: "text",
      timestamp: new Date().toISOString(),
      reactions: {}
    };

    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);
    localStorage.setItem("crm_chat_messages", JSON.stringify(updatedMessages));

    // Update room last activity
    const updatedRooms = chatRooms.map(room => 
      room.id === selectedRoom 
        ? { ...room, lastActivity: new Date().toISOString() }
        : room
    );
    setChatRooms(updatedRooms);
    localStorage.setItem("crm_chat_rooms", JSON.stringify(updatedRooms));

    setMessageInput("");
    toast({
      title: "✅ Tin nhắn đã gửi",
      description: "Tin nhắn của bạn đã được gửi thành công",
    });
  };

  const createRoom = (roomData: {
    name: string;
    description: string;
    type: "public" | "private";
    members: string[];
    department?: string;
  }) => {
    if (!user) return;

    const memberNames = roomData.members.map(id => 
      users.find(u => u.id === id)?.name || ""
    ).filter(Boolean);

    const newRoom: ChatRoom = {
      id: `room-${Date.now()}`,
      name: roomData.name,
      description: roomData.description,
      type: roomData.type,
      createdBy: user.id,
      createdByName: user.name,
      members: roomData.members,
      memberNames,
      admins: [user.id],
      createdAt: new Date().toISOString(),
      lastActivity: new Date().toISOString(),
      department: roomData.department,
      isActive: true
    };

    const updatedRooms = [...chatRooms, newRoom];
    setChatRooms(updatedRooms);
    localStorage.setItem("crm_chat_rooms", JSON.stringify(updatedRooms));

    // Send system message
    const systemMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      roomId: newRoom.id,
      userId: "system",
      userName: "Hệ thống",
      content: `${user.name} đã tạo nhóm chat "${roomData.name}"`,
      type: "system",
      timestamp: new Date().toISOString(),
      reactions: {}
    };

    const updatedMessages = [...messages, systemMessage];
    setMessages(updatedMessages);
    localStorage.setItem("crm_chat_messages", JSON.stringify(updatedMessages));

    toast({
      title: "✅ Tạo nhóm thành công",
      description: `Đã tạo nhóm chat "${roomData.name}"`,
    });
  };

  const CreateRoomForm = () => {
    const [formData, setFormData] = useState({
      name: "",
      description: "",
      type: "public" as "public" | "private",
      members: [] as string[],
      department: ""
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      
      if (!formData.name.trim()) {
        toast({
          title: "Lỗi validation",
          description: "Vui lòng nhập tên nhóm",
          variant: "destructive",
        });
        return;
      }

      if (formData.members.length === 0) {
        toast({
          title: "Lỗi validation", 
          description: "Vui lòng chọn ít nhất một thành viên",
          variant: "destructive",
        });
        return;
      }

      // Add current user to members if not already included
      const members = formData.members.includes(user?.id || "") 
        ? formData.members 
        : [...formData.members, user?.id || ""];

      createRoom({ ...formData, members });
      setIsCreateRoomDialogOpen(false);
      setFormData({
        name: "",
        description: "",
        type: "public",
        members: [],
        department: ""
      });
    };

    const departments = [...new Set(users.map(u => u.department))];

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="roomName">Tên nhóm *</Label>
            <Input
              id="roomName"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="VD: Team Marketing"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="roomType">Loại nhóm</Label>
            <Select
              value={formData.type}
              onValueChange={(value: "public" | "private") => 
                setFormData(prev => ({ ...prev, type: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="public">
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    Công khai
                  </div>
                </SelectItem>
                <SelectItem value="private">
                  <div className="flex items-center gap-2">
                    <Lock className="h-4 w-4" />
                    Riêng tư
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="roomDescription">Mô tả</Label>
          <Textarea
            id="roomDescription"
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            placeholder="Mô tả ngắn về mục đích của nhóm..."
            rows={3}
          />
        </div>

        <div className="space-y-2">
          <Label>Thành viên *</Label>
          <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
            {users.map((userData) => (
              <label
                key={userData.id}
                className="flex items-center space-x-2 cursor-pointer p-2 rounded hover:bg-gray-50"
              >
                <Checkbox
                  checked={formData.members.includes(userData.id)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFormData(prev => ({ 
                        ...prev, 
                        members: [...prev.members, userData.id] 
                      }));
                    } else {
                      setFormData(prev => ({ 
                        ...prev, 
                        members: prev.members.filter(id => id !== userData.id) 
                      }));
                    }
                  }}
                />
                <div className="flex items-center gap-2">
                  <Avatar className="h-6 w-6">
                    <AvatarFallback className="text-xs">
                      {userData.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="text-sm font-medium">{userData.name}</div>
                    <div className="text-xs text-gray-500">{userData.department}</div>
                  </div>
                </div>
              </label>
            ))}
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => setIsCreateRoomDialogOpen(false)}
          >
            Hủy
          </Button>
          <Button type="submit">
            <Plus className="h-4 w-4 mr-2" />
            Tạo nhóm
          </Button>
        </div>
      </form>
    );
  };

  // Filter rooms based on user permissions
  const userRooms = chatRooms.filter(room => 
    room.members.includes(user?.id || "") ||
    user?.role === "admin"
  );

  const selectedRoomData = userRooms.find(room => room.id === selectedRoom);
  const roomMessages = messages.filter(msg => msg.roomId === selectedRoom);

  return (
    <div className="h-[calc(100vh-12rem)] flex gap-4">
      {/* Sidebar - Room List */}
      <div className="w-80 bg-white/35 backdrop-blur-md border border-white/15 shadow-xl rounded-lg flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Nhóm chat
            </h2>
            {canCreateRooms && (
              <Dialog open={isCreateRoomDialogOpen} onOpenChange={setIsCreateRoomDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Tạo nhóm chat mới</DialogTitle>
                    <DialogDescription>
                      Tạo nhóm chat để giao tiếp với team
                    </DialogDescription>
                  </DialogHeader>
                  <CreateRoomForm />
                </DialogContent>
              </Dialog>
            )}
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Tìm kiếm nhóm..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-2">
          {userRooms
            .filter(room => 
              room.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
              room.description.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .map((room) => (
            <div
              key={room.id}
              onClick={() => setSelectedRoom(room.id)}
              className={`p-3 rounded-lg cursor-pointer transition-colors mb-2 ${
                selectedRoom === room.id 
                  ? "bg-blue-100 border border-blue-300" 
                  : "hover:bg-gray-100"
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    room.type === "public" ? "bg-green-100" : "bg-blue-100"
                  }`}>
                    {room.type === "public" ? (
                      <Hash className="h-5 w-5 text-green-600" />
                    ) : (
                      <Lock className="h-5 w-5 text-blue-600" />
                    )}
                  </div>
                  {room.admins.includes(user?.id || "") && (
                    <Crown className="absolute -top-1 -right-1 h-3 w-3 text-yellow-500" />
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium truncate">{room.name}</h3>
                    <Badge variant="outline" className="text-xs">
                      {room.members.length}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 truncate">{room.description}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(room.lastActivity).toLocaleDateString("vi-VN")}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 bg-white/35 backdrop-blur-md border border-white/15 shadow-xl rounded-lg flex flex-col">
        {selectedRoomData ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    selectedRoomData.type === "public" ? "bg-green-100" : "bg-blue-100"
                  }`}>
                    {selectedRoomData.type === "public" ? (
                      <Hash className="h-5 w-5 text-green-600" />
                    ) : (
                      <Lock className="h-5 w-5 text-blue-600" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold">{selectedRoomData.name}</h3>
                    <p className="text-sm text-gray-600">{selectedRoomData.description}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Badge variant="outline">
                    {selectedRoomData.members.length} thành viên
                  </Badge>
                  <Button variant="outline" size="sm">
                    <Info className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {roomMessages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${
                    message.type === "system" ? "justify-center" : ""
                  }`}
                >
                  {message.type === "system" ? (
                    <div className="text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                      {message.content}
                    </div>
                  ) : (
                    <>
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-sm">
                          {message.userName.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{message.userName}</span>
                          <span className="text-xs text-gray-500">
                            {new Date(message.timestamp).toLocaleString("vi-VN")}
                          </span>
                        </div>
                        <div className="bg-gray-100 rounded-lg px-3 py-2 text-sm">
                          {message.content}
                        </div>
                      </div>
                    </>
                  )}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-gray-200">
              <div className="flex gap-2">
                <Input
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder={`Nhắn tin trong ${selectedRoomData.name}...`}
                  onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                  className="flex-1"
                />
                <Button onClick={sendMessage} disabled={!messageInput.trim()}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <MessageSquare className="h-16 w-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-lg font-medium mb-2">Chọn một nhóm để bắt đầu chat</h3>
              <p className="text-gray-600">Chọn nhóm từ danh s��ch bên trái để xem tin nhắn</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
