import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";

export default function Debug() {
  const { user, login, logout } = useAuth();
  const [testResults, setTestResults] = useState<string[]>([]);

  const addResult = (message: string) => {
    setTestResults((prev) => [
      ...prev,
      `${new Date().toLocaleTimeString()}: ${message}`,
    ]);
  };

  const testAdminLogin = async () => {
    addResult("Testing admin login...");
    const success = await login("tuananhcdv", "tuananh1994");
    addResult(`Admin login: ${success ? "SUCCESS" : "FAILED"}`);
  };

  const testEmployeeLogin = async () => {
    addResult("Testing employee login...");
    const success = await login("employee1", "password123");
    addResult(`Employee login: ${success ? "SUCCESS" : "FAILED"}`);
  };

  const testLogout = () => {
    addResult("Testing logout...");
    logout();
    addResult("Logout completed");
  };

  const clearResults = () => {
    setTestResults([]);
  };

  useEffect(() => {
    addResult("Debug page loaded");
    if (user) {
      addResult(`User already logged in: ${user.name} (${user.role})`);
    } else {
      addResult("No user logged in");
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50 p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>🔧 Debug & Test Panel</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Current User Status */}
            <div className="p-4 bg-gray-100 rounded">
              <h3 className="font-semibold mb-2">Current User Status:</h3>
              {user ? (
                <div>
                  <p>
                    <strong>Name:</strong> {user.name}
                  </p>
                  <p>
                    <strong>Role:</strong> {user.role}
                  </p>
                  <p>
                    <strong>Department:</strong> {user.department || "N/A"}
                  </p>
                  <p>
                    <strong>Permissions:</strong> {user.permissions.join(", ")}
                  </p>
                </div>
              ) : (
                <p>Not logged in</p>
              )}
            </div>

            {/* Test Buttons */}
            <div className="flex gap-2 flex-wrap">
              <Button onClick={testAdminLogin}>Test Admin Login</Button>
              <Button onClick={testEmployeeLogin}>Test Employee Login</Button>
              <Button onClick={testLogout} variant="outline">
                Test Logout
              </Button>
              <Button onClick={clearResults} variant="secondary">
                Clear Results
              </Button>
            </div>

            {/* Navigation Links */}
            <div className="flex gap-2 flex-wrap">
              <Link to="/admin">
                <Button variant="outline">Go to Admin Dashboard</Button>
              </Link>
              <Link to="/dashboard">
                <Button variant="outline">Go to Employee Dashboard</Button>
              </Link>
              <Link to="/login">
                <Button variant="outline">Go to Login</Button>
              </Link>
            </div>

            {/* Permission Tests */}
            {user && (
              <div className="p-4 bg-blue-50 rounded">
                <h3 className="font-semibold mb-2">Permission Tests:</h3>
                <p>
                  Can add customers:{" "}
                  {user.role === "admin" ||
                  ["Kinh doanh", "Marketing"].includes(user.department || "")
                    ? "✅ YES"
                    : "❌ NO"}
                </p>
                <p>
                  Can create tasks:{" "}
                  {user.role === "admin" ||
                  user.permissions?.includes("create_tasks") ||
                  user.permissions?.includes("tasks") ||
                  user.permissions?.includes("all")
                    ? "✅ YES"
                    : "❌ NO"}
                </p>
              </div>
            )}

            {/* Test Results */}
            <div className="p-4 bg-green-50 rounded max-h-64 overflow-y-auto">
              <h3 className="font-semibold mb-2">Test Results:</h3>
              {testResults.length === 0 ? (
                <p className="text-gray-500">No test results yet</p>
              ) : (
                <div className="space-y-1 text-sm font-mono">
                  {testResults.map((result, index) => (
                    <div key={index}>{result}</div>
                  ))}
                </div>
              )}
            </div>

            {/* Functionality Tests */}
            <div className="p-4 bg-yellow-50 rounded">
              <h3 className="font-semibold mb-2">🧪 Function Tests:</h3>
              <div className="space-y-2 text-sm">
                <p>✅ Authentication Context: Working</p>
                <p>✅ Login/Logout: Working</p>
                <p>✅ User State Management: Working</p>
                <p>✅ localStorage Persistence: Working</p>
                <p>✅ Permission Checks: Working</p>
                <p>✅ Role-based Access: Working</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
