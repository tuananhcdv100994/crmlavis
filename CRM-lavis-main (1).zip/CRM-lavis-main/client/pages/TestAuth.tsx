import { useAuth } from "@/contexts/AuthContext";

export default function TestAuth() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Authentication Test</h1>

      <div className="bg-gray-100 p-4 rounded">
        <h2 className="text-lg font-semibold mb-2">Current User:</h2>
        <pre>{JSON.stringify(user, null, 2)}</pre>
      </div>

      <div className="mt-4">
        <p>User exists: {user ? "Yes" : "No"}</p>
        <p>User role: {user?.role || "N/A"}</p>
        <p>User department: {user?.department || "N/A"}</p>
        <p>Is loading: {isLoading ? "Yes" : "No"}</p>
      </div>

      <div className="mt-4">
        <h3 className="font-semibold">Can add customers?</h3>
        <p>
          {user?.role === "admin" ||
          ["Kinh doanh", "Marketing"].includes(user?.department || "")
            ? "Yes"
            : "No"}
        </p>
      </div>
    </div>
  );
}
